import React, { useState, useMemo } from "react";
import {
  Search,
  Filter,
  ArrowUpDown,
  Eye,
  Edit,
  Trash2,
  Download,
  Upload,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
  Sparkles,
  Award
} from "lucide-react";
import { ProductionLog, Product, Factor } from "../types";
import { calculateDurationMinutes } from "../supabaseClient";

interface LogsTableProps {
  logs: ProductionLog[];
  unfilteredLogs: ProductionLog[];
  products: Product[];
  factors?: Factor[];
  isDarkMode: boolean;
  onView: (log: ProductionLog) => void;
  onEdit: (log: ProductionLog) => void;
  onDelete: (id: string) => void;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
  onImportLogs?: (importedLogs: ProductionLog[]) => void;
  onImportProducts?: (importedProducts: Product[]) => void;
  onImportFactors?: (importedFactors: Factor[]) => void;
  onImportDowntimes?: (importedDowntimes: { batch: number; factor_id: number; downtime_min: number }[]) => void;
  onRestoreDefaults?: () => Promise<void>;
  onClearAll?: () => Promise<void> | void;

  // Shared Filter Props
  search: string;
  setSearch: (s: string) => void;
  selectedOperator: string;
  setSelectedOperator: (s: string) => void;
  selectedProduct: string;
  setSelectedProduct: (s: string) => void;
  selectedShift: string;
  setSelectedShift: (s: string) => void;
  selectedStatus: string;
  setSelectedStatus: (s: string) => void;
  selectedFactor: string;
  setSelectedFactor: (s: string) => void;
  startDate: string;
  setStartDate: (s: string) => void;
  endDate: string;
  setEndDate: (s: string) => void;
  selectedBatch: string;
  setSelectedBatch: (s: string) => void;
}

type SortField = "batch" | "date" | "duration" | "downtime_min" | "status";
type SortOrder = "asc" | "desc";

export default function LogsTable({
  logs,
  unfilteredLogs = [],
  products,
  factors = [],
  isDarkMode,
  onView,
  onEdit,
  onDelete,
  addToast,
  onImportLogs,
  onImportProducts,
  onImportFactors,
  onImportDowntimes,
  onRestoreDefaults,
  onClearAll,

  search,
  setSearch,
  selectedOperator,
  setSelectedOperator,
  selectedProduct,
  setSelectedProduct,
  selectedShift,
  setSelectedShift,
  selectedStatus,
  setSelectedStatus,
  selectedFactor,
  setSelectedFactor,
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  selectedBatch,
  setSelectedBatch,
}: LogsTableProps) {
  // Erase all confirmation states
  const [confirmClearActive, setConfirmClearActive] = useState(false);
  const [confirmTimer, setConfirmTimer] = useState<NodeJS.Timeout | null>(null);

  React.useEffect(() => {
    return () => {
      if (confirmTimer) clearTimeout(confirmTimer);
    };
  }, [confirmTimer]);

  const handleClearClick = () => {
    if (!confirmClearActive) {
      setConfirmClearActive(true);
      const timer = setTimeout(() => {
        setConfirmClearActive(false);
      }, 3000);
      setConfirmTimer(timer);
      addToast("Click again within 3 seconds to confirm erasing all data.", "warning");
    } else {
      if (confirmTimer) clearTimeout(confirmTimer);
      setConfirmClearActive(false);
      if (onClearAll) onClearAll();
    }
  };

  // Sorting
  const [sortField, setSortField] = useState<SortField>("batch");
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc");

  // Pagination
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  // All distinct operators list
  const operatorsList = useMemo(() => {
    return Array.from(new Set(unfilteredLogs.map((l) => l.operator_name))).sort();
  }, [unfilteredLogs]);

  // Unique flavor categories
  const productsList = useMemo(() => {
    return Array.from(new Set(unfilteredLogs.map((l) => l.flavor))).sort();
  }, [unfilteredLogs]);

  // Distinct batch numbers
  const batchesList = useMemo(() => {
    return Array.from(new Set(unfilteredLogs.map((l) => l.batch))).sort((a, b) => a - b);
  }, [unfilteredLogs]);

  // Distinct downtime factors from original factors list or logs
  const factorsList = useMemo(() => {
    const fromFactors = factors.map(f => f.description);
    const fromLogs: string[] = [];
    unfilteredLogs.forEach(l => {
      if (l.downtime_entries) {
        l.downtime_entries.forEach(e => {
          if (e.downtime_reason) fromLogs.push(e.downtime_reason);
        });
      } else if (l.downtime_reason) {
        fromLogs.push(l.downtime_reason);
      }
    });
    return Array.from(new Set([...fromFactors, ...fromLogs])).filter(Boolean).sort();
  }, [unfilteredLogs, factors]);

  // Filter & Sort Logic
  const processedLogs = useMemo(() => {
    let result = [...logs];

    // Sorting
    result.sort((a, b) => {
      let valA: any = a[sortField];
      let valB: any = b[sortField];

      // fallback defaults for nulls
      if (sortField === "downtime_min") {
        valA = a.downtime_min || 0;
        valB = b.downtime_min || 0;
      }

      if (valA === undefined) valA = "";
      if (valB === undefined) valB = "";

      if (typeof valA === "string") {
        return sortOrder === "asc"
          ? valA.localeCompare(valB)
          : valB.localeCompare(valA);
      } else {
        return sortOrder === "asc" ? valA - valB : valB - valA;
      }
    });

    return result;
  }, [logs, sortField, sortOrder]);

  // Paginated View logs
  const paginatedLogs = useMemo(() => {
    const startIndex = (page - 1) * rowsPerPage;
    return processedLogs.slice(startIndex, startIndex + rowsPerPage);
  }, [processedLogs, page, rowsPerPage]);

  const totalPages = Math.ceil(processedLogs.length / rowsPerPage);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("desc");
    }
    setPage(1);
  };

  // Export handlers
  const handleExportCSV = () => {
    if (processedLogs.length === 0) {
      addToast("No data to export.", "warning");
      return;
    }
    const headers = ["Batch", "Date", "Product ID", "Flavor", "Size", "Operator", "Start Time", "End Time", "Duration (mins)", "Shift", "Status", "Downtime (mins)", "Reason", "Operator Error"];
    const csvRows = [headers.join(",")];

    processedLogs.forEach((l) => {
      let isOpErrStr = "N/A";
      if (l.downtime_min && l.downtime_min > 0) {
        if (l.downtime_entries && l.downtime_entries.length > 0) {
          const hasOpErr = l.downtime_entries.some(e => 
            e.operator_error !== undefined ? e.operator_error : (factors?.find(f => f.factor_id === e.factor_id)?.operator_error || false)
          );
          isOpErrStr = hasOpErr ? "Yes" : "No";
        } else if (l.factor_id !== undefined) {
          const hasOpErr = factors?.find(f => f.factor_id === l.factor_id)?.operator_error || false;
          isOpErrStr = hasOpErr ? "Yes" : "No";
        } else {
          isOpErrStr = "No";
        }
      }

      const row = [
        l.batch,
        l.date,
        l.product_id,
        `"${l.flavor}"`,
        l.size,
        `"${l.operator_name}"`,
        l.start_time,
        l.end_time,
        l.duration,
        l.shift,
        l.status,
        l.downtime_min || 0,
        `"${l.downtime_reason || 'None'}"`,
        isOpErrStr,
      ];
      csvRows.push(row.join(","));
    });

    const blob = new Blob([csvRows.join("\n")], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", `manufacturing_line_report_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast("CSV Report Downloaded Successfully.", "success");
  };

  const handleExportJSON = () => {
    if (processedLogs.length === 0) {
      addToast("No data to export.", "warning");
      return;
    }
    const blob = new Blob([JSON.stringify(processedLogs, null, 2)], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", `manufacturing_line_report_${new Date().toISOString().split("T")[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast("JSON Database Export Completed Successfully.", "success");
  };

  const handleResetFilters = () => {
    setSearch("");
    setSelectedOperator("All");
    setSelectedProduct("All");
    setSelectedShift("All");
    setSelectedStatus("All");
    setPage(1);
    addToast("Filters cleared.", "info");
  };

  // Helper to parse a single CSV line handling quoted strings with commas
  const parseCsvLine = (line: string): string[] => {
    const result: string[] = [];
    let current = "";
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = "";
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  };

  // Maps fuzzy case-insensitive headers to key property names
  const mapCsvHeaders = (headers: string[]) => {
    const mapping: Record<string, number> = {};
    headers.forEach((h, index) => {
      const clean = h.trim().toLowerCase().replace(/[\s_\(\)]+/g, "");
      if (clean === "batch" || clean === "batch#" || clean === "batchid" || clean === "batchnumber" || clean === "id") {
        mapping["batch"] = index;
      } else if (clean === "date") {
        mapping["date"] = index;
      } else if (clean === "productid" || clean === "product" || clean === "prodid") {
        mapping["product_id"] = index;
      } else if (clean === "flavor" || clean === "productflavor" || clean === "flavorprofile" || clean === "productname" || clean === "productlineflavor") {
        mapping["flavor"] = index;
      } else if (clean === "size" || clean === "productsize") {
        mapping["size"] = index;
      } else if (clean === "operator" || clean === "operatorname" || clean === "operator_name") {
        mapping["operator_name"] = index;
      } else if (clean === "starttime" || clean === "start" || clean === "start_time") {
        mapping["start_time"] = index;
      } else if (clean === "endtime" || clean === "end" || clean === "end_time") {
        mapping["end_time"] = index;
      } else if (clean === "duration" || clean === "durationmins" || clean === "durationminutes" || clean === "duration(mins)") {
        mapping["duration"] = index;
      } else if (clean === "shift") {
        mapping["shift"] = index;
      } else if (clean === "status" || clean === "productionstatus" || clean === "production_status") {
        mapping["status"] = index;
      } else if (clean === "downtime" || clean === "downtimemins" || clean === "downtimeminutes" || clean === "downtime_min" || clean === "downtime(mins)") {
        mapping["downtime_min"] = index;
      } else if (clean === "reason" || clean === "downtimereason" || clean === "factor" || clean === "reasonexplanation" || clean === "downtime_reason") {
        mapping["downtime_reason"] = index;
      } else if (clean === "factorid" || clean === "factid" || clean === "factor_id") {
        mapping["factor_id"] = index;
      }
    });
    return mapping;
  };

  const handleImportCSVClick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;

    const files = Array.from(fileList);
    addToast(`Reading ${files.length} file(s)...`, "info");

    const readAndParseFile = (file: File): Promise<{
      type: "logs" | "products" | "factors" | "downtimes" | "unknown";
      fileName: string;
      logs: ProductionLog[];
      products: Product[];
      factors: Factor[];
      downtimes?: { batch: number; factor_id: number; downtime_min: number }[];
    }> => {
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (event) => {
          const text = event.target?.result as string;
          if (!text) {
            resolve({ type: "unknown", fileName: file.name, logs: [], products: [], factors: [], downtimes: [] });
            return;
          }

          try {
            const lines = text.split(/\r?\n/).filter((line) => line.trim().length > 0);
            if (lines.length < 2) {
              resolve({ type: "unknown", fileName: file.name, logs: [], products: [], factors: [], downtimes: [] });
              return;
            }

            const headers = parseCsvLine(lines[0]);
            const cleanHeaders = headers.map(h => h.trim().toLowerCase().replace(/[\s_\(\)]+/g, ""));

            // Determine table type
            const isDowntimesTable = cleanHeaders.includes("downtimeid") || 
              (cleanHeaders.includes("batch") && (cleanHeaders.includes("factid") || cleanHeaders.includes("factorid")) && (cleanHeaders.includes("downtimemin") || cleanHeaders.includes("minutes") || cleanHeaders.includes("downtime_min") || cleanHeaders.includes("downtime_m_in")));

            let isProductsTable = !isDowntimesTable && (cleanHeaders.includes("productid") || cleanHeaders.includes("prodid") || 
              (cleanHeaders.includes("flavor") && cleanHeaders.includes("size") && (cleanHeaders.includes("minbatchtime") || cleanHeaders.includes("targettime") || cleanHeaders.includes("min_batch_time"))));
            
            let isFactorsTable = !isDowntimesTable && (cleanHeaders.includes("factorid") || cleanHeaders.includes("factid") || 
              (cleanHeaders.includes("operatorerror") && cleanHeaders.includes("description")) ||
              (cleanHeaders.includes("stoppagereason") && cleanHeaders.includes("operatorerror")));

            let isLogsTable = !isDowntimesTable && (cleanHeaders.includes("batch") || cleanHeaders.includes("batchid") || cleanHeaders.includes("batchnumber") || cleanHeaders.includes("batch#") ||
              (cleanHeaders.includes("operatorname") && cleanHeaders.includes("starttime") && cleanHeaders.includes("endtime")));

            // Resolve conflicts/priority
            if (isLogsTable && isProductsTable) {
              if (cleanHeaders.includes("batch") || cleanHeaders.includes("batchid") || cleanHeaders.includes("batch#")) {
                isProductsTable = false;
              }
            }

            if (isProductsTable) {
              // Parse Products
              const productHeaderMap: Record<string, number> = {};
              headers.forEach((h, index) => {
                const clean = h.trim().toLowerCase().replace(/[\s_\(\)]+/g, "");
                if (clean === "productid" || clean === "id" || clean === "code" || clean === "productcode") {
                  productHeaderMap["product_id"] = index;
                } else if (clean === "flavor" || clean === "flavorprofile" || clean === "productflavor" || clean === "name" || clean === "productname") {
                  productHeaderMap["flavor"] = index;
                } else if (clean === "size" || clean === "productsize" || clean === "volume") {
                  productHeaderMap["size"] = index;
                } else if (clean === "minbatchtime" || clean === "targettime" || clean === "min_batch_time" || clean === "targetduration") {
                  productHeaderMap["min_batch_time"] = index;
                }
              });

              const parsedProducts: Product[] = [];
              for (let i = 1; i < lines.length; i++) {
                const rowValues = parseCsvLine(lines[i]);
                if (rowValues.length === 0 || (rowValues.length === 1 && rowValues[0] === "")) {
                  continue;
                }
                const getVal = (field: string): string => {
                  const idx = productHeaderMap[field];
                  let val = idx !== undefined ? rowValues[idx] || "" : "";
                  if (val.startsWith('"') && val.endsWith('"')) {
                    val = val.substring(1, val.length - 1);
                  }
                  return val.trim();
                };

                const prodId = getVal("product_id");
                if (!prodId) continue;

                parsedProducts.push({
                  product_id: prodId,
                  flavor: getVal("flavor") || "Unknown Flavor",
                  size: getVal("size") || "600 ML",
                  min_batch_time: parseInt(getVal("min_batch_time"), 10) || 60,
                });
              }
              resolve({ type: "products", fileName: file.name, logs: [], products: parsedProducts, factors: [] });

            } else if (isFactorsTable) {
              // Parse Factors
              const factorHeaderMap: Record<string, number> = {};
              headers.forEach((h, index) => {
                const clean = h.trim().toLowerCase().replace(/[\s_\(\)]+/g, "");
                if (clean === "factorid" || clean === "id" || clean === "code" || clean === "factor_id") {
                  factorHeaderMap["factor_id"] = index;
                } else if (clean === "description" || clean === "reason" || clean === "stoppagereason" || clean === "cause") {
                  factorHeaderMap["description"] = index;
                } else if (clean === "operatorerror" || clean === "error" || clean === "isoperatorerror") {
                  factorHeaderMap["operator_error"] = index;
                }
              });

              const parsedFactors: Factor[] = [];
              for (let i = 1; i < lines.length; i++) {
                const rowValues = parseCsvLine(lines[i]);
                if (rowValues.length === 0 || (rowValues.length === 1 && rowValues[0] === "")) {
                  continue;
                }
                const getVal = (field: string): string => {
                  const idx = factorHeaderMap[field];
                  let val = idx !== undefined ? rowValues[idx] || "" : "";
                  if (val.startsWith('"') && val.endsWith('"')) {
                    val = val.substring(1, val.length - 1);
                  }
                  return val.trim();
                };

                const factId = parseInt(getVal("factor_id"), 10);
                if (isNaN(factId)) continue;

                const opErrRaw = getVal("operator_error").toLowerCase();
                const isErr = opErrRaw === "true" || 
                              opErrRaw === "1" || 
                              opErrRaw === "yes" || 
                              opErrRaw === "operator" || 
                              (opErrRaw.includes("operator") && !opErrRaw.includes("non"));

                parsedFactors.push({
                  factor_id: factId,
                  description: getVal("description") || `Reason ${factId}`,
                  operator_error: isErr,
                });
              }
              resolve({ type: "factors", fileName: file.name, logs: [], products: [], factors: parsedFactors });

            } else if (isDowntimesTable) {
              // Parse Downtimes
              const downtimeHeaderMap: Record<string, number> = {};
              headers.forEach((h, index) => {
                const clean = h.trim().toLowerCase().replace(/[\s_\(\)]+/g, "");
                if (clean === "batch" || clean === "batchid" || clean === "batchnum") {
                  downtimeHeaderMap["batch"] = index;
                } else if (clean === "factorid" || clean === "factid" || clean === "factor_id") {
                  downtimeHeaderMap["factor_id"] = index;
                } else if (clean === "downtimemin" || clean === "minutes" || clean === "downtime_min" || clean === "downtimeminutes" || clean === "downtime_m_in" || clean === "downtime_m_i_n" || clean === "downtimem_in") {
                  downtimeHeaderMap["downtime_min"] = index;
                }
              });

              const parsedDowntimes: { batch: number; factor_id: number; downtime_min: number }[] = [];
              for (let i = 1; i < lines.length; i++) {
                const rowValues = parseCsvLine(lines[i]);
                if (rowValues.length === 0 || (rowValues.length === 1 && rowValues[0] === "")) {
                  continue;
                }
                const getVal = (field: string): string => {
                  const idx = downtimeHeaderMap[field];
                  let val = idx !== undefined ? rowValues[idx] || "" : "";
                  if (val.startsWith('"') && val.endsWith('"')) {
                    val = val.substring(1, val.length - 1);
                  }
                  return val.trim();
                };

                const batchNum = parseInt(getVal("batch"), 10);
                const factorId = parseInt(getVal("factor_id"), 10);
                const minutes = parseInt(getVal("downtime_min"), 10);

                if (!isNaN(batchNum) && !isNaN(factorId) && !isNaN(minutes)) {
                  parsedDowntimes.push({
                    batch: batchNum,
                    factor_id: factorId,
                    downtime_min: minutes
                  });
                }
              }
              resolve({ type: "downtimes", fileName: file.name, logs: [], products: [], factors: [], downtimes: parsedDowntimes });

            } else {
              // Default to Production Logs
              const headerMap = mapCsvHeaders(headers);
              if (headerMap["batch"] === undefined) {
                resolve({ type: "unknown", fileName: file.name, logs: [], products: [], factors: [] });
                return;
              }

              const parsedLogs: ProductionLog[] = [];
              const newlyCreatedFactors: Factor[] = [];
              const tempFactors = [...(factors || [])];

              for (let i = 1; i < lines.length; i++) {
                const rowValues = parseCsvLine(lines[i]);
                if (rowValues.length === 0 || (rowValues.length === 1 && rowValues[0] === "")) {
                  continue;
                }

                const getVal = (field: string): string => {
                  const idx = headerMap[field];
                  let val = idx !== undefined ? rowValues[idx] || "" : "";
                  if (val.startsWith('"') && val.endsWith('"')) {
                    val = val.substring(1, val.length - 1);
                  }
                  return val.trim();
                };

                const batchStr = getVal("batch");
                const batchNum = parseInt(batchStr, 10);
                if (isNaN(batchNum)) {
                  continue;
                }

                const dateVal = getVal("date") || new Date().toISOString().split("T")[0];
                const prodIdVal = getVal("product_id") || "CO-600";
                
                const product = products.find((p) => p.product_id.toLowerCase() === prodIdVal.toLowerCase()) || 
                                products.find((p) => p.flavor.toLowerCase() === getVal("flavor").toLowerCase() && p.size.toLowerCase() === getVal("size").toLowerCase()) ||
                                products[0];

                const prodId = product ? product.product_id : prodIdVal;
                const flavor = product ? product.flavor : (getVal("flavor") || "Unknown Flavor");
                const size = product ? product.size : (getVal("size") || "N/A");
                const minBatchTime = product ? product.min_batch_time : 60;

                const operatorName = getVal("operator_name") || getVal("operator") || "Mac";
                const startTimeVal = getVal("start_time") || "08:00";
                const endTimeVal = getVal("end_time") || "09:00";

                let durationVal = parseInt(getVal("duration"), 10);
                if (isNaN(durationVal)) {
                  durationVal = calculateDurationMinutes(startTimeVal, endTimeVal);
                }

                let shiftVal = getVal("shift");
                if (!shiftVal) {
                  const [hour] = startTimeVal.split(":").map(Number);
                  if (!isNaN(hour)) {
                    if (hour >= 6 && hour < 14) shiftVal = "Morning";
                    else if (hour >= 14 && hour < 22) shiftVal = "Afternoon";
                    else shiftVal = "Night";
                  } else {
                    shiftVal = "Morning";
                  }
                }

                const statusVal = durationVal > minBatchTime ? "Downtime Delay" : "Optimal";

                let downtimeMinVal = parseInt(getVal("downtime_min"), 10);
                if (isNaN(downtimeMinVal)) {
                  downtimeMinVal = statusVal === "Downtime Delay" ? Math.max(0, durationVal - minBatchTime) : 0;
                }

                const downtimeReasonRaw = getVal("downtime_reason") || getVal("reason");
                const downtimeReasonVal = downtimeReasonRaw || (downtimeMinVal > 0 ? "Other" : undefined);
                
                let factorIdVal = parseInt(getVal("factor_id"), 10);
                let finalReasonStr = downtimeReasonVal;

                if (downtimeMinVal > 0) {
                  if (isNaN(factorIdVal) && downtimeReasonVal) {
                    const matchedFactor = tempFactors.find((f) => f.description.toLowerCase() === downtimeReasonVal.toLowerCase());
                    if (matchedFactor) {
                      factorIdVal = matchedFactor.factor_id;
                      finalReasonStr = matchedFactor.description;
                    } else if (downtimeReasonVal.trim() !== "" && downtimeReasonVal.toLowerCase() !== "other") {
                      // Dynamically register new factor to prevent mapping loss
                      const maxId = tempFactors.length > 0 ? Math.max(...tempFactors.map((f) => f.factor_id)) : 0;
                      const nextId = maxId >= 12 ? maxId + 1 : 13;
                      const newFactor: Factor = {
                        factor_id: nextId,
                        description: downtimeReasonVal,
                        operator_error: false,
                      };
                      tempFactors.push(newFactor);
                      newlyCreatedFactors.push(newFactor);
                      factorIdVal = nextId;
                      finalReasonStr = downtimeReasonVal;
                    } else {
                      factorIdVal = 12;
                      finalReasonStr = "Other";
                    }
                  } else if (!isNaN(factorIdVal)) {
                    const matchedFactor = tempFactors.find((f) => f.factor_id === factorIdVal);
                    if (matchedFactor) {
                      finalReasonStr = matchedFactor.description;
                    } else {
                      finalReasonStr = downtimeReasonVal || "Other";
                    }
                  } else {
                    factorIdVal = 12;
                    finalReasonStr = "Other";
                  }
                }

                parsedLogs.push({
                  id: `B-${batchNum}`,
                  batch: batchNum,
                  date: dateVal,
                  product_id: prodId,
                  flavor: flavor,
                  size: size,
                  min_batch_time: minBatchTime,
                  operator_name: operatorName,
                  start_time: startTimeVal,
                  end_time: endTimeVal,
                  duration: durationVal,
                  shift: shiftVal,
                  status: statusVal,
                  downtime_min: downtimeMinVal > 0 ? downtimeMinVal : undefined,
                  factor_id: downtimeMinVal > 0 ? factorIdVal : undefined,
                  downtime_reason: downtimeMinVal > 0 ? finalReasonStr : undefined,
                });
              }
              resolve({ type: "logs", fileName: file.name, logs: parsedLogs, products: [], factors: newlyCreatedFactors });
            }
          } catch (err) {
            resolve({ type: "unknown", fileName: file.name, logs: [], products: [], factors: [], downtimes: [] });
          }
        };
        reader.onerror = () => {
          resolve({ type: "unknown", fileName: file.name, logs: [], products: [], factors: [], downtimes: [] });
        };
        reader.readAsText(file);
      });
    };

    try {
      const results = await Promise.all(files.map(readAndParseFile));

      let totalLogsImported: ProductionLog[] = [];
      let totalProductsImported: Product[] = [];
      let totalFactorsImported: Factor[] = [];
      let totalDowntimesImported: { batch: number; factor_id: number; downtime_min: number }[] = [];
      let skippedFiles: string[] = [];

      results.forEach((res) => {
        if (res.type === "logs" && res.logs.length > 0) {
          totalLogsImported = [...totalLogsImported, ...res.logs];
          if (res.factors && res.factors.length > 0) {
            totalFactorsImported = [...totalFactorsImported, ...res.factors];
          }
        } else if (res.type === "products" && res.products.length > 0) {
          totalProductsImported = [...totalProductsImported, ...res.products];
        } else if (res.type === "factors" && res.factors.length > 0) {
          totalFactorsImported = [...totalFactorsImported, ...res.factors];
        } else if (res.type === "downtimes" && res.downtimes && res.downtimes.length > 0) {
          totalDowntimesImported = [...totalDowntimesImported, ...res.downtimes];
        } else {
          skippedFiles.push(res.fileName);
        }
      });

      if (totalLogsImported.length > 0) {
        if (onImportLogs) {
          onImportLogs(totalLogsImported);
          addToast(`Loaded ${totalLogsImported.length} batches from CSV.`, "success");
        } else {
          addToast("CSV import callback not configured in parent view.", "error");
        }
      }
      if (totalProductsImported.length > 0) {
        if (onImportProducts) {
          onImportProducts(totalProductsImported);
          addToast(`Successfully imported ${totalProductsImported.length} flavors/products.`, "success");
        } else {
          addToast("Product import callback not configured in parent view.", "error");
        }
      }
      if (totalFactorsImported.length > 0) {
        if (onImportFactors) {
          onImportFactors(totalFactorsImported);
          addToast(`Successfully imported ${totalFactorsImported.length} downtime factors.`, "success");
        } else {
          addToast("Factor import callback not configured in parent view.", "error");
        }
      }
      if (totalDowntimesImported.length > 0) {
        if (onImportDowntimes) {
          onImportDowntimes(totalDowntimesImported);
          addToast(`Successfully imported ${totalDowntimesImported.length} downtime details.`, "success");
        } else {
          addToast("Downtime import callback not configured in parent view.", "error");
        }
      }

      if (skippedFiles.length > 0) {
        addToast(`Skipped or failed to identify columns for: ${skippedFiles.join(", ")}`, "warning");
      }
    } catch (err: any) {
      addToast(`Error importing files: ${err.message}`, "error");
    }

    e.target.value = ""; // reset file input
  };

  return (
    <div
      className={`p-6 rounded-3xl border shadow-xl flex flex-col gap-6 ${
        isDarkMode ? "bg-[#0F1115]/80 border-[#22242D] backdrop-blur-md" : "bg-white border-slate-200"
      }`}
      id="logs-table"
    >
      {/* Title block */}
      <div className="flex flex-col gap-1 border-b border-slate-800/10 dark:border-slate-800/30 pb-4">
        <h2 className={`text-[22px] font-extrabold tracking-tight ${isDarkMode ? "text-white" : "text-slate-900"}`}>
          Conveyor Production Logs Database
        </h2>
        <p className="text-xs text-gray-400">
          Browse, search, audit, and export high resolution batch execution statistics
        </p>
      </div>

      {/* FILTER & ACTIONS ROW - FLEX LAYOUT MOVED CLOSE TO TABLE */}
      <div className="flex flex-col xl:flex-row justify-between items-stretch xl:items-center gap-4">
        
        {/* Left Side: Search and Dropdowns (aligned left, specific sizes) */}
        <div className="flex flex-wrap items-center gap-3 w-full xl:w-auto">
          {/* Search */}
          <div className="relative w-full sm:w-[320px]">
            <Search className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
            <input
              type="text"
              placeholder="Search sequential batch..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              className={`w-full h-[40px] pl-10 pr-4 rounded-xl text-xs font-medium border outline-none transition-all hover:scale-[1.01] focus:scale-[1.01] ${
                isDarkMode
                  ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500/80 shadow-inner"
                  : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500 shadow-sm"
              }`}
            />
          </div>

          {/* Operator Select */}
          <div className="w-full sm:w-[220px]">
            <select
              value={selectedOperator}
              onChange={(e) => {
                setSelectedOperator(e.target.value);
                setPage(1);
              }}
              className={`w-full h-[40px] px-3 rounded-xl text-xs font-medium border outline-none transition-all hover:scale-[1.01] ${
                isDarkMode 
                  ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500/80" 
                  : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
              }`}
            >
              <option value="All">All Operators</option>
              {operatorsList.map((op) => (
                <option key={op} value={op}>
                  {op}
                </option>
              ))}
            </select>
          </div>

          {/* Product Flavor Select */}
          <div className="w-full sm:w-[220px]">
            <select
              value={selectedProduct}
              onChange={(e) => {
                setSelectedProduct(e.target.value);
                setPage(1);
              }}
              className={`w-full h-[40px] px-3 rounded-xl text-xs font-medium border outline-none transition-all hover:scale-[1.01] ${
                isDarkMode 
                  ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500/80" 
                  : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
              }`}
            >
              <option value="All">All Flavors</option>
              {productsList.map((flavor) => (
                <option key={flavor} value={flavor}>
                  {flavor}
                </option>
              ))}
            </select>
          </div>

          {/* Shift Select */}
          <div className="w-full sm:w-[220px]">
            <select
              value={selectedShift}
              onChange={(e) => {
                setSelectedShift(e.target.value);
                setPage(1);
              }}
              className={`w-full h-[40px] px-3 rounded-xl text-xs font-medium border outline-none transition-all hover:scale-[1.01] ${
                isDarkMode 
                  ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500/80" 
                  : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
              }`}
            >
              <option value="All">All Shifts</option>
              <option value="Morning">Morning Shift</option>
              <option value="Afternoon">Afternoon Shift</option>
              <option value="Evening">Evening Shift</option>
              <option value="Night">Night Shift</option>
            </select>
          </div>

          {/* Status Select */}
          <div className="w-full sm:w-[220px]">
            <select
              value={selectedStatus}
              onChange={(e) => {
                setSelectedStatus(e.target.value);
                setPage(1);
              }}
              className={`w-full h-[40px] px-3 rounded-xl text-xs font-medium border outline-none transition-all hover:scale-[1.01] ${
                isDarkMode 
                  ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500/80" 
                  : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
              }`}
            >
              <option value="All">All Statuses</option>
              <option value="Optimal">Optimal Run</option>
              <option value="Downtime Delay">Downtime Delay</option>
            </select>
          </div>

          {/* Batch Filter */}
          <div className="w-full sm:w-[150px]">
            <select
              value={selectedBatch}
              onChange={(e) => {
                setSelectedBatch(e.target.value);
                setPage(1);
              }}
              className={`w-full h-[40px] px-3 rounded-xl text-xs font-medium border outline-none transition-all hover:scale-[1.01] ${
                isDarkMode 
                  ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500/80" 
                  : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
              }`}
            >
              <option value="All">All Batches</option>
              {batchesList.map((b) => (
                <option key={b} value={b.toString()}>
                  Batch #{b}
                </option>
              ))}
            </select>
          </div>

          {/* Downtime Factor Filter */}
          <div className="w-full sm:w-[220px]">
            <select
              value={selectedFactor}
              onChange={(e) => {
                setSelectedFactor(e.target.value);
                setPage(1);
              }}
              className={`w-full h-[40px] px-3 rounded-xl text-xs font-medium border outline-none transition-all hover:scale-[1.01] ${
                isDarkMode 
                  ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500/80" 
                  : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
              }`}
            >
              <option value="All">All Downtime Factors</option>
              {factorsList.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
          </div>

          {/* Date Range: Start Date */}
          <div className="w-full sm:w-[160px]">
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setPage(1);
              }}
              className={`w-full h-[40px] px-3 rounded-xl text-xs font-medium border outline-none transition-all hover:scale-[1.01] ${
                isDarkMode 
                  ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500/80" 
                  : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
              }`}
              placeholder="Start Date"
            />
          </div>

          {/* Date Range: End Date */}
          <div className="w-full sm:w-[160px]">
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setPage(1);
              }}
              className={`w-full h-[40px] px-3 rounded-xl text-xs font-medium border outline-none transition-all hover:scale-[1.01] ${
                isDarkMode 
                  ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500/80" 
                  : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
              }`}
              placeholder="End Date"
            />
          </div>
        </div>

        {/* Right Side: Import/Export Operations (aligned consistently to the right, secondary 40px buttons with glow/hover scale) */}
        <div className="flex flex-wrap items-center gap-2 justify-start sm:justify-end xl:self-center">
          <label
            htmlFor="csv-upload"
            className={`h-[40px] px-4 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer hover:scale-[1.02] hover:shadow-sm active:scale-[0.98] ${
              isDarkMode
                ? "bg-slate-900 border-slate-800 hover:bg-slate-800 text-cyan-400 hover:shadow-cyan-500/5"
                : "bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700"
            }`}
          >
            <Upload className="h-3.5 w-3.5" />
            <span>Import CSV</span>
          </label>
          <input
            type="file"
            id="csv-upload"
            accept=".csv"
            multiple
            onChange={handleImportCSVClick}
            className="hidden"
          />

          {onRestoreDefaults && (
            <button
              onClick={onRestoreDefaults}
              className={`h-[40px] px-4 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer hover:scale-[1.02] hover:shadow-sm active:scale-[0.98] ${
                isDarkMode 
                  ? "bg-[#101F20] border-emerald-500/20 text-emerald-400 hover:bg-[#152B2C]" 
                  : "bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-700"
              }`}
              title="Restore default 12-factor stoppages and detailed records in database and browser cache"
            >
              <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
              <span>Restore Sample Data</span>
            </button>
          )}

          {onClearAll && (
            <button
              onClick={handleClearClick}
              className={`h-[40px] px-4 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer hover:scale-[1.02] hover:shadow-sm active:scale-[0.98] ${
                confirmClearActive
                  ? "bg-rose-500 border-rose-600 text-white animate-pulse"
                  : isDarkMode
                    ? "bg-[#2A1015] border-rose-500/20 text-rose-400 hover:bg-[#3C151C]"
                    : "bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-700"
              }`}
              title="Delete all production logs permanently"
            >
              <Trash2 className={`h-3.5 w-3.5 ${confirmClearActive ? "text-white" : "text-rose-400"}`} />
              <span>{confirmClearActive ? "Confirm Erase?" : "Erase All Data"}</span>
            </button>
          )}

          <button
            onClick={handleExportCSV}
            className={`h-[40px] px-4 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer hover:scale-[1.02] hover:shadow-sm active:scale-[0.98] ${
              isDarkMode 
                ? "bg-slate-900 border-slate-800 hover:bg-slate-800 text-gray-300" 
                : "bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700"
            }`}
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleExportJSON}
            className={`h-[40px] px-4 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer hover:scale-[1.02] hover:shadow-sm active:scale-[0.98] ${
              isDarkMode 
                ? "bg-slate-900 border-slate-800 hover:bg-slate-800 text-gray-300" 
                : "bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700"
            }`}
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export JSON</span>
          </button>
          {(search || selectedOperator !== "All" || selectedProduct !== "All" || selectedShift !== "All" || selectedStatus !== "All") && (
            <button
              onClick={handleResetFilters}
              className="h-[40px] px-4 rounded-xl text-xs font-semibold text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 hover:scale-[1.02] transition-all cursor-pointer active:scale-[0.98]"
            >
              Clear Filters
            </button>
          )}
        </div>
      </div>

      {/* CORE DATA TABLE CONTAINER WITH MAX HEIGHT AND SCROLLBAR FOR STICKY HEADER SUPPORT */}
      <div className="overflow-x-auto border rounded-2xl border-slate-200 dark:border-slate-800/80 bg-slate-950/20 max-h-[640px] overflow-y-auto relative shadow-inner">
        <table className="w-full text-left border-collapse min-w-[1000px] table-fixed">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800">
              <th 
                className={`sticky top-0 z-20 py-4.5 px-5 font-bold cursor-pointer hover:text-cyan-400 select-none border-b border-slate-200 dark:border-slate-800 text-[12px] font-mono tracking-widest uppercase w-[110px] ${
                  isDarkMode ? "bg-[#0B0C10] text-gray-500" : "bg-slate-50 text-slate-500"
                }`}
                onClick={() => toggleSort("batch")}
              >
                <div className="flex items-center gap-1.5">
                  <span>Batch #</span>
                  <ArrowUpDown className="h-3 w-3" />
                </div>
              </th>
              <th 
                className={`sticky top-0 z-20 py-4.5 px-5 font-bold cursor-pointer hover:text-cyan-400 select-none border-b border-slate-200 dark:border-slate-800 text-[12px] font-mono tracking-widest uppercase w-[125px] ${
                  isDarkMode ? "bg-[#0B0C10] text-gray-500" : "bg-slate-50 text-slate-500"
                }`}
                onClick={() => toggleSort("date")}
              >
                <div className="flex items-center gap-1.5">
                  <span>Date</span>
                  <ArrowUpDown className="h-3 w-3" />
                </div>
              </th>
              <th className={`sticky top-0 z-20 py-4.5 px-5 font-bold border-b border-slate-200 dark:border-slate-800 text-[12px] font-mono tracking-widest uppercase w-[220px] ${
                isDarkMode ? "bg-[#0B0C10] text-gray-500" : "bg-slate-50 text-slate-500"
              }`}>
                Product Run
              </th>
              <th className={`sticky top-0 z-20 py-4.5 px-5 font-bold border-b border-slate-200 dark:border-slate-800 text-[12px] font-mono tracking-widest uppercase w-[150px] ${
                isDarkMode ? "bg-[#0B0C10] text-gray-500" : "bg-slate-50 text-slate-500"
              }`}>
                Operator
              </th>
              <th className={`sticky top-0 z-20 py-4.5 px-5 font-bold border-b border-slate-200 dark:border-slate-800 text-[12px] font-mono tracking-widest uppercase w-[180px] ${
                isDarkMode ? "bg-[#0B0C10] text-gray-500" : "bg-slate-50 text-slate-500"
              }`}>
                Time Window
              </th>
              <th 
                className={`sticky top-0 z-20 py-4.5 px-5 font-bold cursor-pointer hover:text-cyan-400 select-none border-b border-slate-200 dark:border-slate-800 text-[12px] font-mono tracking-widest uppercase w-[190px] ${
                  isDarkMode ? "bg-[#0B0C10] text-gray-500" : "bg-slate-50 text-slate-500"
                }`}
                onClick={() => toggleSort("duration")}
              >
                <div className="flex items-center gap-1.5">
                  <span>Actual Duration</span>
                  <ArrowUpDown className="h-3 w-3" />
                </div>
              </th>
              <th 
                className={`sticky top-0 z-20 py-4.5 px-5 font-bold cursor-pointer hover:text-cyan-400 select-none border-b border-slate-200 dark:border-slate-800 text-[12px] font-mono tracking-widest uppercase w-[230px] ${
                  isDarkMode ? "bg-[#0B0C10] text-gray-500" : "bg-slate-50 text-slate-500"
                }`}
                onClick={() => toggleSort("downtime_min")}
              >
                <div className="flex items-center gap-1.5">
                  <span>Loss / Downtime</span>
                  <ArrowUpDown className="h-3 w-3" />
                </div>
              </th>
              <th 
                className={`sticky top-0 z-20 py-4.5 px-5 font-bold cursor-pointer hover:text-cyan-400 select-none border-b border-slate-200 dark:border-slate-800 text-[12px] font-mono tracking-widest uppercase w-[115px] ${
                  isDarkMode ? "bg-[#0B0C10] text-gray-500" : "bg-slate-50 text-slate-500"
                }`}
                onClick={() => toggleSort("status")}
              >
                <div className="flex items-center gap-1.5">
                  <span>Status</span>
                  <ArrowUpDown className="h-3 w-3" />
                </div>
              </th>
              <th className={`sticky top-0 z-20 py-4.5 px-5 text-right font-bold pr-6 border-b border-slate-200 dark:border-slate-800 text-[12px] font-mono tracking-widest uppercase w-[150px] ${
                isDarkMode ? "bg-[#0B0C10] text-gray-500" : "bg-slate-50 text-slate-500"
              }`}>
                MES Actions
              </th>
            </tr>
          </thead>
          <tbody className={`divide-y text-[14px] font-medium ${isDarkMode ? "divide-slate-800/60" : "divide-slate-150"}`}>
            {paginatedLogs.length > 0 ? (
              paginatedLogs.map((log) => {
                const isOptimal = log.status === "Optimal";
                return (
                  <tr
                    key={log.id}
                    className={`h-[58px] hover:bg-cyan-500/[0.02] dark:hover:bg-cyan-400/[0.02] transition-colors ${
                      isDarkMode ? "text-gray-300 border-slate-800" : "text-slate-800 border-slate-150"
                    }`}
                  >
                    <td className="py-2 px-5 font-mono font-bold text-gray-400 dark:text-gray-500">
                      {log.batch}
                    </td>
                    <td className="py-2 px-5 text-gray-500 font-mono text-[11px]">{log.date}</td>
                    <td className="py-2 px-5 truncate">
                      <div className="flex flex-col">
                        <span className={`font-semibold truncate ${isDarkMode ? "text-gray-200" : "text-slate-900"}`}>{log.flavor}</span>
                        <span className="text-[10px] text-gray-500 font-mono uppercase truncate">{log.size} &bull; target {log.min_batch_time}m</span>
                      </div>
                    </td>
                    <td className="py-2 px-5 font-semibold text-[13px] truncate">{log.operator_name}</td>
                    <td className="py-2 px-5 font-mono text-[11px] text-gray-500">
                      <span>{log.start_time} - {log.end_time}</span>
                      <span className="block text-[9px] uppercase tracking-wider text-slate-500 mt-0.5">{log.shift} Shift</span>
                    </td>
                    <td className="py-2 px-5">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-gray-300 font-semibold">{log.duration}m</span>
                        <span className={`text-[10px] font-semibold ${
                          log.duration < log.min_batch_time 
                            ? "text-emerald-400 font-bold" 
                            : log.duration === log.min_batch_time 
                              ? "text-teal-400 font-semibold" 
                              : "text-rose-400"
                        }`}>
                          ({log.duration > log.min_batch_time 
                            ? `+${log.duration - log.min_batch_time}m` 
                            : log.duration < log.min_batch_time 
                              ? `-${log.min_batch_time - log.duration}m` 
                              : "Target"}
                          )
                        </span>
                      </div>
                    </td>
                    <td className="py-2 px-5 font-mono text-gray-400">
                      {log.downtime_min && log.downtime_min > 0 ? (
                        <div className="flex flex-col justify-center">
                          <span className="text-rose-400 font-bold text-xs">{log.downtime_min} mins</span>
                          {log.downtime_entries && log.downtime_entries.length > 0 ? (
                            <div className="flex flex-col gap-0.5 mt-0.5 max-w-[210px]">
                              {log.downtime_entries.map((entry, idx) => {
                                const isOpErr = entry.operator_error !== undefined
                                  ? entry.operator_error
                                  : (factors?.find((f) => f.factor_id === entry.factor_id)?.operator_error || false);
                                return (
                                  <div key={idx} className="flex flex-col gap-0.5 border-l-2 pl-1.5 border-rose-500/20 py-0.2">
                                    <span className="text-[9px] text-rose-400/80 font-bold leading-none block truncate" title={`${entry.downtime_reason || 'Other'}: ${entry.downtime_min}m`}>
                                      {entry.downtime_reason || "Other"}: {entry.downtime_min}m
                                    </span>
                                    <span className={`inline-block self-start px-1 py-0.1 rounded-[2px] text-[7px] font-bold uppercase tracking-wider ${
                                      isOpErr 
                                        ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" 
                                        : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                                    }`}>
                                      {isOpErr ? "Operator" : "System"}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          ) : (
                            <div className="flex flex-col gap-0.5 mt-0.5">
                              <span className="text-[10px] text-rose-400/80 max-w-[210px] truncate" title={log.downtime_reason}>
                                {log.downtime_reason}
                              </span>
                              {log.factor_id !== undefined && (
                                <span className={`inline-block self-start px-1 py-0.1 rounded-[2px] text-[7px] font-bold uppercase tracking-wider ${
                                  factors?.find((f) => f.factor_id === log.factor_id)?.operator_error
                                    ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" 
                                    : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                                }`}>
                                  {factors?.find((f) => f.factor_id === log.factor_id)?.operator_error ? "Operator" : "System"}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-500">—</span>
                      )}
                    </td>
                    <td className="py-2 px-5">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide uppercase ${
                        isOptimal
                          ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
                          : "bg-rose-500/10 border border-rose-500/20 text-rose-400"
                      }`}>
                        {isOptimal ? "Optimal" : "Delay"}
                      </span>
                    </td>
                    <td className="py-2 px-5 text-right pr-6">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onView(log)}
                          className={`w-[32px] h-[32px] flex items-center justify-center rounded-lg border transition-all hover:scale-110 active:scale-95 cursor-pointer ${
                            isDarkMode ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-cyan-400" : "bg-slate-50 border-slate-200 hover:bg-slate-100 text-blue-600"
                          }`}
                          title="View Gemini Diagnostics"
                        >
                          <Sparkles className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => onEdit(log)}
                          className={`w-[32px] h-[32px] flex items-center justify-center rounded-lg border transition-all hover:scale-110 active:scale-95 cursor-pointer ${
                            isDarkMode ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-amber-400" : "bg-slate-50 border-slate-200 hover:bg-slate-100 text-amber-600"
                          }`}
                          title="Edit Batch"
                        >
                          <Edit className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => onDelete(log.id)}
                          className={`w-[32px] h-[32px] flex items-center justify-center rounded-lg border transition-all hover:scale-110 active:scale-95 cursor-pointer ${
                            isDarkMode ? "bg-slate-800 border-slate-700 hover:bg-red-950 hover:text-red-400 text-gray-500" : "bg-slate-50 border-slate-200 hover:bg-rose-50 hover:text-rose-600 text-slate-500"
                          }`}
                          title="Delete Record"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={9} className="text-center py-10 text-gray-500 font-mono text-xs">
                  <AlertTriangle className="h-6 w-6 text-amber-400 mx-auto mb-2 animate-bounce" />
                  No sequential batch logs found matching filter criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-semibold text-gray-400 border-t border-slate-800/10 dark:border-slate-800/30 pt-4">
        <div className="flex items-center gap-2">
          <span>Rows per page:</span>
          <select
            value={rowsPerPage}
            onChange={(e) => {
              setRowsPerPage(Number(e.target.value));
              setPage(1);
            }}
            className={`px-2 py-1.5 rounded-lg border outline-none ${
              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-100 border-slate-200 text-slate-800"
            }`}
          >
            <option value={5}>5</option>
            <option value={10}>10</option>
            <option value={25}>25</option>
          </select>
          <span className="ml-2 font-mono">
            Showing {(page - 1) * rowsPerPage + 1} - {Math.min(page * rowsPerPage, processedLogs.length)} of {processedLogs.length} batches
          </span>
        </div>

        {totalPages > 1 && (
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                page === 1
                  ? "opacity-40 cursor-not-allowed"
                  : isDarkMode
                  ? "bg-slate-900 border-slate-800 hover:bg-slate-800 text-white"
                  : "bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-800"
              }`}
            >
              <ChevronLeft className="h-3.5 w-3.5" />
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                className={`w-8 h-8 rounded-lg border font-mono transition-colors cursor-pointer ${
                  page === p
                    ? isDarkMode
                      ? "bg-cyan-500/10 border-cyan-400 text-cyan-400 font-bold"
                      : "bg-blue-600 border-blue-600 text-white font-bold"
                    : isDarkMode
                    ? "bg-slate-900 border-slate-800 hover:bg-slate-800 text-white"
                    : "bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-800"
                }`}
              >
                {p}
              </button>
            ))}
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                page === totalPages
                  ? "opacity-40 cursor-not-allowed"
                  : isDarkMode
                  ? "bg-slate-900 border-slate-800 hover:bg-slate-800 text-white"
                  : "bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-800"
              }`}
            >
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
      </div>

    </div>
  );
}
