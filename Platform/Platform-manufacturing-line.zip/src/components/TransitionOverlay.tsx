import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Cpu, ShieldAlert, Sparkles, Server, Check } from "lucide-react";

interface TransitionOverlayProps {
  onComplete: () => void;
  isDarkMode: boolean;
}

export default function TransitionOverlay({ onComplete, isDarkMode }: TransitionOverlayProps) {
  const [progress, setProgress] = useState(0);
  const [activeStep, setActiveStep] = useState(0);
  const [statusLogs, setStatusLogs] = useState<string[]>([
    "CRITICAL PROTOCOL: INITIALIZING SECURE MES SHIELDED SYSTEM CORES...",
    "COUPLING LOCALSTORAGE EDGE PERSISTENCE ENGINE...",
    "HANDSHAKING CLOUD CONTAINER & SUPABASE SECURE LINK...",
    "DECRYPTING MULTI-BATCH TELEMETRY REPLICATOR...",
    "BINDING COGNITIVE GEMINI AI AGENT ANALYTICS CORE...",
    "ESTABLISHING AUTHORIZED OPERATOR HANDSHAKE v4.2...",
    "MES OPERATIONAL WORKSPACE LOADED successfully."
  ]);

  const [currentLogs, setCurrentLogs] = useState<string[]>([]);

  // Telemetry code stream simulating live edge calculations
  const [randomHex, setRandomHex] = useState<string>("");

  useEffect(() => {
    // Progress incrementer
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        // Organic irregular progress pacing
        const step = Math.floor(Math.random() * 8) + 3;
        return Math.min(100, prev + step);
      });
    }, 80);

    return () => clearInterval(interval);
  }, []);

  // Update step and log sequence based on progress
  useEffect(() => {
    const step = Math.floor((progress / 100) * statusLogs.length);
    if (step !== activeStep && step < statusLogs.length) {
      setActiveStep(step);
    }

    // Add log entries sequentially
    const expectedLogsCount = Math.min(statusLogs.length, Math.floor((progress / 100) * (statusLogs.length + 1)) + 1);
    if (currentLogs.length < expectedLogsCount) {
      setCurrentLogs(statusLogs.slice(0, expectedLogsCount));
    }
  }, [progress, activeStep, statusLogs, currentLogs.length]);

  // Hex matrix code generator
  useEffect(() => {
    const hexInterval = setInterval(() => {
      const hexChars = "0123456789ABCDEFX▸▫▪█▰▱";
      let res = "";
      for (let i = 0; i < 60; i++) {
        res += hexChars[Math.floor(Math.random() * hexChars.length)];
        if (i % 12 === 0) res += " ";
      }
      setRandomHex(res);
    }, 60);

    return () => clearInterval(hexInterval);
  }, []);

  // Finish trigger
  useEffect(() => {
    if (progress === 100) {
      const timeout = setTimeout(() => {
        onComplete();
      }, 600);
      return () => clearTimeout(timeout);
    }
  }, [progress, onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#07080a] text-white overflow-hidden font-mono px-4">
      {/* High-tech matrix scanning laser grid lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b12_1px,transparent_1px),linear-gradient(to_bottom,#1e293b12_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none"></div>
      
      {/* Glowing atmospheric circles */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-cyan-500/10 blur-[100px] animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-indigo-500/10 blur-[100px] animate-pulse delay-1000"></div>

      {/* Futuristic Scanline bar sweeping top to bottom */}
      <motion.div 
        initial={{ y: "-10%" }}
        animate={{ y: "110vh" }}
        transition={{ duration: 2.2, repeat: Infinity, ease: "linear" }}
        className="absolute left-0 right-0 h-[4px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-60 shadow-[0_0_20px_#22d3ee] pointer-events-none z-10"
      />

      {/* Animated Vignette border lines */}
      <div className="absolute inset-6 border border-cyan-500/20 rounded-3xl pointer-events-none">
        <div className="absolute top-0 left-10 w-32 h-[1px] bg-cyan-400"></div>
        <div className="absolute bottom-0 right-10 w-32 h-[1px] bg-cyan-400"></div>
        <div className="absolute left-0 top-10 w-[1px] h-32 bg-cyan-400"></div>
        <div className="absolute right-0 bottom-10 w-[1px] h-32 bg-cyan-400"></div>
      </div>

      <div className="w-full max-w-2xl relative z-20 flex flex-col gap-8 text-center sm:text-left">
        {/* Holographic system authorization header */}
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 border-b border-cyan-500/20 pb-6">
          <div className="p-3.5 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 shadow-[0_0_25px_rgba(6,182,212,0.15)] animate-bounce">
            <Cpu className="h-8 w-8" />
          </div>
          <div className="flex-1 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <span className="text-[10px] tracking-widest text-cyan-400 uppercase font-bold animate-pulse">MES GATEWAY SECURITY KEY</span>
              <span className="px-1.5 py-0.5 rounded text-[8px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">VERIFIED</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1 uppercase">
              Decrypting Operator Core
            </h2>
            <p className="text-xs text-slate-400 mt-1 font-mono tracking-wide">
              Connecting to secure line servers at europe-west2.run.app...
            </p>
          </div>
        </div>

        {/* Dynamic Telemetry Code stream */}
        <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 text-left h-20 flex flex-col justify-center font-mono text-[10px] text-cyan-500/80 overflow-hidden relative shadow-inner">
          <div className="absolute top-2 right-4 flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-ping"></span>
            <span className="text-[8px] text-cyan-400 uppercase font-bold">EDGE CALCS</span>
          </div>
          <p className="font-bold text-slate-400 mb-1">▸ TELEMETRY PACKET DECODING STRUCT:</p>
          <p className="truncate text-cyan-400 tracking-wider font-semibold">{randomHex || "0XF3E7A912FF880E919D94C ▫ ▪ ALL SYSTEMS SYNCED"}</p>
        </div>

        {/* High-tech Circular OEE Calibration and loader */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6 p-6 rounded-2xl bg-slate-950/40 border border-slate-900 shadow-xl">
          <div className="relative flex items-center justify-center h-28 w-28 shrink-0">
            {/* Outer spinning dash border */}
            <svg className="absolute inset-0 w-full h-full rotate-[-90deg]">
              <circle
                cx="56"
                cy="56"
                r="48"
                className="stroke-slate-800 fill-none"
                strokeWidth="4"
              />
              <circle
                cx="56"
                cy="56"
                r="48"
                className="stroke-cyan-500 fill-none"
                strokeWidth="4"
                strokeDasharray={`${2 * Math.PI * 48}`}
                strokeDashoffset={`${2 * Math.PI * 48 * (1 - progress / 100)}`}
                strokeLinecap="round"
                style={{ transition: "stroke-dashoffset 0.1s ease" }}
              />
            </svg>
            <div className="text-center flex flex-col items-center">
              <span className="text-2xl font-black text-cyan-400 tracking-tighter">{progress}%</span>
              <span className="text-[8px] text-slate-500 tracking-wider font-semibold uppercase">SECURE SYNC</span>
            </div>
          </div>

          <div className="flex-1 text-left w-full">
            <div className="flex justify-between items-center text-xs mb-1.5">
              <span className="text-slate-400 font-bold tracking-wide">MES SYSTEM MODULE DEPLOYMENT</span>
              <span className="text-cyan-400 font-bold font-mono">{progress}% Complete</span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800 p-0.5">
              <motion.div
                className="bg-gradient-to-r from-cyan-500 to-indigo-500 h-full rounded-full shadow-[0_0_10px_#06b6d4]"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex items-center gap-4 mt-3 text-[10px] text-slate-400">
              <div className="flex items-center gap-1.5">
                <Server className="h-3 w-3 text-cyan-400" />
                <span>API: <strong className="text-white">Active</strong></span>
              </div>
              <div className="flex items-center gap-1.5">
                <Sparkles className="h-3 w-3 text-cyan-400" />
                <span>AI Core: <strong className="text-white">Ready</strong></span>
              </div>
            </div>
          </div>
        </div>

        {/* Loading diagnostic state log stream */}
        <div className="flex flex-col gap-2 text-left bg-slate-950/30 border border-slate-900 p-5 rounded-2xl max-h-[160px] overflow-y-auto font-mono text-[10px] leading-relaxed scrollbar-thin scrollbar-thumb-slate-800">
          <AnimatePresence>
            {currentLogs.map((log, index) => {
              const isLast = index === currentLogs.length - 1 && progress < 100;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.2 }}
                  className={`flex items-start gap-2 ${
                    index === statusLogs.length - 1 ? "text-emerald-400 font-bold" : "text-slate-400"
                  }`}
                >
                  {index < currentLogs.length - 1 || progress === 100 ? (
                    <span className="text-emerald-400 shrink-0 font-bold">✓</span>
                  ) : (
                    <span className="text-cyan-400 shrink-0 font-bold animate-ping">▸</span>
                  )}
                  <div className="flex-1">
                    <span>{log}</span>
                    {isLast && (
                      <span className="inline-block w-1.5 h-3 bg-cyan-400 animate-pulse ml-1.5"></span>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
