import React, { useState, useMemo, useEffect } from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  ComposedChart
} from "recharts";
import { motion } from "motion/react";
import { 
  TrendingUp, 
  Clock, 
  Activity, 
  Layers, 
  User, 
  Gauge, 
  AlertTriangle, 
  CheckCircle,
  HelpCircle,
  Sparkles,
  Zap,
  Tag,
  Users,
  ShieldAlert
} from "lucide-react";
import { ProductionLog, Factor } from "../types";
import { PRODUCTS } from "../initialData";

interface ChartsSectionProps {
  logs: ProductionLog[];
  factors: Factor[];
  isDarkMode: boolean;
  activeTab?: string;
  setActiveTab?: (tab: string) => void;
  currentDashboard?: "overview" | "analysis";
  selectedFactor?: string;
}

export default function ChartsSection({ 
  logs, 
  factors, 
  isDarkMode, 
  activeTab, 
  setActiveTab,
  currentDashboard: propDashboard,
  selectedFactor = "All"
}: ChartsSectionProps) {
  
  // Dashboard view selection state: 'overview' | 'analysis'
  const [currentDashboard, setCurrentDashboard] = useState<"overview" | "analysis">("overview");

  // Synchronize internal dashboard view state with App's activeTab selections or direct prop
  useEffect(() => {
    if (propDashboard) {
      setCurrentDashboard(propDashboard);
    } else if (activeTab === "analytics") {
      setCurrentDashboard("analysis");
    } else if (activeTab === "dashboard") {
      setCurrentDashboard("overview");
    }
  }, [activeTab, propDashboard]);

  const handleDashboardChange = (view: "overview" | "analysis") => {
    setCurrentDashboard(view);
  };

  // Modern Palette Colors (Forest Greens & Soft Sages for light, Cyber Emeralds & Teals for dark)
  const LIGHT_THEME_COLORS = ["#1B432C", "#2E6F40", "#4E925F", "#72B683", "#9AD9AB", "#C5FCD6", "#5C8B68", "#1E4D2B"];
  const DARK_THEME_COLORS = ["#10B981", "#06B6D4", "#3B82F6", "#8B5CF6", "#F59E0B", "#EF4444", "#14B8A6", "#EC4899"];
  const themeColors = isDarkMode ? DARK_THEME_COLORS : LIGHT_THEME_COLORS;

  // Formatting date helper "29-Aug-24"
  const formatDateLabel = (dateStr: string) => {
    if (!dateStr) return "";
    const parts = dateStr.split("-");
    if (parts.length < 3) return dateStr;
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const year = parts[0].substring(2);
    const month = months[parseInt(parts[1], 10) - 1] || parts[1];
    const day = parts[2];
    return `${day}-${month}-${year}`;
  };

  // --- COMPUTE GLOBAL METRICS ---
  const stats = useMemo(() => {
    // Gather all downtime events/records from the logs
    const downtimeEvents: { factor_id: number; downtime_min: number; downtime_reason: string; operator_error?: boolean }[] = [];
    
    logs.forEach(l => {
      if (l.downtime_entries && l.downtime_entries.length > 0) {
        l.downtime_entries.forEach(entry => {
          if (entry.downtime_min > 0) {
            const f = factors.find(fac => fac.factor_id === entry.factor_id);
            const reason = entry.downtime_reason || (f ? f.description : "Other");
            if (selectedFactor && selectedFactor !== "All" && reason !== selectedFactor) {
              return;
            }
            downtimeEvents.push({
              factor_id: entry.factor_id,
              downtime_min: entry.downtime_min,
              downtime_reason: reason,
              operator_error: entry.operator_error !== undefined ? entry.operator_error : f?.operator_error
            });
          }
        });
      } else if (l.downtime_min && l.downtime_min > 0) {
        const f = factors.find(fac => fac.factor_id === l.factor_id);
        const reason = l.downtime_reason || (f ? f.description : "Other");
        if (selectedFactor && selectedFactor !== "All" && reason !== selectedFactor) {
          return;
        }
        downtimeEvents.push({
          factor_id: l.factor_id || 0,
          downtime_min: l.downtime_min,
          downtime_reason: reason,
          operator_error: f?.operator_error
        });
      }
    });

    const totalDowntime = downtimeEvents.reduce((sum, e) => sum + e.downtime_min, 0);
    const countDowntimeEvents = downtimeEvents.length;
    const avgDowntime = countDowntimeEvents > 0 ? (totalDowntime / countDowntimeEvents).toFixed(1) : "0";

    if (logs.length === 0) {
      return {
        totalBatches: 0,
        totalOperators: 0,
        totalProducts: 0,
        totalDuration: 0,
        productivityScore: 0,
        totalDowntime: 0,
        downtimePercentage: 0,
        avgDowntime: "0.0",
        downtimeFactorsCount: factors.length,
        popularDowntime: "None"
      };
    }

    const totalBatches = logs.length;
    const uniqueOperators = new Set(logs.map(l => l.operator_name)).size;
    const uniqueProducts = new Set(logs.map(l => l.product_id)).size;
    const totalDuration = logs.reduce((sum, l) => sum + (l.duration || 0), 0);

    // Productivity Score = ratio of active run time vs elapsed duration
    const runTimeOnly = totalDuration - totalDowntime;
    const productivityScore = Math.round((runTimeOnly / (totalDuration || 1)) * 100);

    // Downtime Percentage of entire elapsed line run time
    const downtimePercentage = Math.round((totalDowntime / (totalDuration || 1)) * 100);

    // Find most popular downtime reason
    const factorMins: Record<string, number> = {};
    downtimeEvents.forEach(e => {
      factorMins[e.downtime_reason] = (factorMins[e.downtime_reason] || 0) + e.downtime_min;
    });
    
    let popularDowntime = "None";
    let maxMins = 0;
    Object.entries(factorMins).forEach(([desc, mins]) => {
      if (mins > maxMins) {
        maxMins = mins;
        popularDowntime = desc;
      }
    });

    return {
      totalBatches,
      totalOperators: uniqueOperators,
      totalProducts: uniqueProducts,
      totalDuration,
      productivityScore,
      totalDowntime,
      downtimePercentage,
      avgDowntime,
      downtimeFactorsCount: factors.length,
      popularDowntime
    };
  }, [logs, factors, selectedFactor]);


  // ==========================================
  // DASHBOARD 1: OVERVIEW COMPILATIONS
  // ==========================================

  // Daily Batch Performance (Area Chart)
  const dailyBatchPerformanceData = useMemo(() => {
    const counts: Record<string, number> = {};
    logs.forEach(l => {
      if (l.date) {
        counts[l.date] = (counts[l.date] || 0) + 1;
      }
    });
    return Object.entries(counts)
      .map(([date, count]) => ({
        dateRaw: date,
        date: formatDateLabel(date),
        Batches: count
      }))
      .sort((a, b) => a.dateRaw.localeCompare(b.dateRaw));
  }, [logs]);

  // On-Time vs Delayed Status (Pie Chart)
  const onTimeVsDelayedData = useMemo(() => {
    let onTimeBatches = 0;
    let delayedBatches = 0;
    logs.forEach(l => {
      if (l.status === "Downtime Delay") {
        delayedBatches += 1;
      } else {
        onTimeBatches += 1;
      }
    });
    const total = (onTimeBatches + delayedBatches) || 1;
    return [
      { name: "On Time", value: onTimeBatches, percentage: ((onTimeBatches / total) * 100).toFixed(2) },
      { name: "Delayed", value: delayedBatches, percentage: ((delayedBatches / total) * 100).toFixed(2) }
    ];
  }, [logs]);

  // Comparative Shift Efficiency (Horizontal Bar Chart)
  const shiftEfficiencyData = useMemo(() => {
    const counts: Record<string, number> = { Morning: 0, Afternoon: 0, Night: 0 };
    logs.forEach(l => {
      const sh = l.shift || "Morning";
      if (counts[sh] !== undefined) {
        counts[sh]++;
      }
    });
    return Object.entries(counts).map(([name, value]) => ({ name, Batches: value }));
  }, [logs]);

  // # of Batches per Operator (Vertical Bar Chart)
  const batchesPerOperatorData = useMemo(() => {
    const counts: Record<string, number> = {};
    logs.forEach(l => {
      counts[l.operator_name] = (counts[l.operator_name] || 0) + 1;
    });
    return Object.entries(counts).map(([name, Batches]) => ({ name, Batches }))
      .sort((a, b) => b.Batches - a.Batches);
  }, [logs]);

  // # of Batch per Product (Horizontal Bar Chart)
  const batchesPerProductData = useMemo(() => {
    const counts: Record<string, number> = {};
    logs.forEach(l => {
      counts[l.product_id] = (counts[l.product_id] || 0) + 1;
    });
    return Object.entries(counts).map(([name, Batches]) => ({ name, Batches }))
      .sort((a, b) => b.Batches - a.Batches);
  }, [logs]);

  // Production Time vs Benchmark (Bar / Line chart for 15 recent runs)
  const productionVsBenchmarkData = useMemo(() => {
    return [...logs].reverse().slice(-15).map(l => ({
      batch: `B-${l.batch}`,
      "Actual Duration": l.duration,
      "Benchmark": l.min_batch_time || 60
    }));
  }, [logs]);


  // ==========================================
  // DASHBOARD 2: DOWNTIME ANALYSIS COMPILATIONS
  // ==========================================

  // Operator vs Non-Operator Downtime (Pie Chart)
  const operatorVsNonOperatorDowntimeData = useMemo(() => {
    let operatorMins = 0;
    let systemicMins = 0;
    logs.forEach(l => {
      if (l.downtime_entries && l.downtime_entries.length > 0) {
        l.downtime_entries.forEach(entry => {
          const f = factors.find(fac => fac.factor_id === entry.factor_id);
          const isOpErr = entry.operator_error !== undefined ? entry.operator_error : (f?.operator_error || false);
          if (isOpErr) {
            operatorMins += entry.downtime_min || 0;
          } else {
            systemicMins += entry.downtime_min || 0;
          }
        });
      } else if (l.downtime_min) {
        const f = factors.find(fac => fac.factor_id === l.factor_id);
        const isOpErr = f?.operator_error || false;
        if (isOpErr) {
          operatorMins += l.downtime_min;
        } else {
          systemicMins += l.downtime_min;
        }
      }
    });
    const total = (operatorMins + systemicMins) || 1;
    return [
      { name: "Operator", value: operatorMins, percentage: Math.round((operatorMins / total) * 100) },
      { name: "Non Operator", value: systemicMins, percentage: Math.round((systemicMins / total) * 100) }
    ];
  }, [logs, factors]);

  // Downtime Trend (min) (Area Chart)
  const dailyDowntimeData = useMemo(() => {
    const mins: Record<string, number> = {};
    logs.forEach(l => {
      if (l.date) {
        mins[l.date] = (mins[l.date] || 0) + (l.downtime_min || 0);
      }
    });
    return Object.entries(mins)
      .map(([date, downtime]) => ({
        dateRaw: date,
        date: formatDateLabel(date),
        Downtime: downtime
      }))
      .sort((a, b) => a.dateRaw.localeCompare(b.dateRaw));
  }, [logs]);

  // Downtime per Shift (min) (Horizontal Bar Chart)
  const shiftDowntimeData = useMemo(() => {
    const mins: Record<string, number> = { Morning: 0, Afternoon: 0, Night: 0 };
    logs.forEach(l => {
      const sh = l.shift || "Morning";
      mins[sh] = (mins[sh] || 0) + (l.downtime_min || 0);
    });
    return Object.entries(mins).map(([name, Downtime]) => ({ name, Downtime }));
  }, [logs]);

  // Downtime Product (min) (Vertical Bar Chart)
  const productDowntimeData = useMemo(() => {
    const mins: Record<string, number> = {};
    logs.forEach(l => {
      mins[l.product_id] = (mins[l.product_id] || 0) + (l.downtime_min || 0);
    });
    return Object.entries(mins).map(([name, Downtime]) => ({ name, Downtime }))
      .sort((a, b) => b.Downtime - a.Downtime);
  }, [logs]);

  // Downtime Factors (min) (Vertical Bar Chart)
  const factorDowntimeData = useMemo(() => {
    const mins: Record<string, number> = {};
    factors.forEach(f => {
      mins[f.description] = 0;
    });
    logs.forEach(l => {
      if (l.downtime_entries && l.downtime_entries.length > 0) {
        l.downtime_entries.forEach(entry => {
          const f = factors.find(fac => fac.factor_id === entry.factor_id);
          const desc = f ? f.description : "Other";
          mins[desc] = (mins[desc] || 0) + (entry.downtime_min || 0);
        });
      } else if (l.downtime_min) {
        const f = factors.find(fac => fac.factor_id === l.factor_id);
        const desc = f ? f.description : "Other";
        mins[desc] = (mins[desc] || 0) + l.downtime_min;
      }
    });
    return Object.entries(mins).map(([name, Downtime]) => ({ name, Downtime }))
      .sort((a, b) => b.Downtime - a.Downtime);
  }, [logs, factors]);

  // Downtime Operator (min) (Pie/Donut Chart)
  const operatorDowntimeData = useMemo(() => {
    const mins: Record<string, number> = {};
    logs.forEach(l => {
      let opMins = 0;
      if (l.downtime_entries && l.downtime_entries.length > 0) {
        l.downtime_entries.forEach(entry => {
          opMins += entry.downtime_min || 0;
        });
      } else if (l.downtime_min) {
        opMins += l.downtime_min;
      }
      mins[l.operator_name] = (mins[l.operator_name] || 0) + opMins;
    });
    return Object.entries(mins).map(([name, value]) => ({ name, value }));
  }, [logs, factors]);

  const totalOperatorDowntime = useMemo(() => {
    return operatorDowntimeData.reduce((sum, item) => sum + item.value, 0);
  }, [operatorDowntimeData]);


  // ==========================================
  // DASHBOARD 3: DOWNTIME CAUSES COMPILATIONS (PARETO ETC)
  // ==========================================

  // Pareto Chart Data
  const paretoChartData = useMemo(() => {
    const sorted = [...factorDowntimeData].sort((a, b) => b.Downtime - a.Downtime);
    const total = sorted.reduce((sum, item) => sum + item.Downtime, 0) || 1;
    let runningSum = 0;
    return sorted.map(item => {
      runningSum += item.Downtime;
      const cumulativePercent = Math.min(100, Math.round((runningSum / total) * 100));
      return {
        name: item.name,
        "Downtime Minutes": item.Downtime,
        "Cumulative %": cumulativePercent
      };
    });
  }, [factorDowntimeData]);

  // Production vs Downtime Trend (Area / Line Chart)
  const productionVsDowntimeTrendData = useMemo(() => {
    const data: Record<string, { Production: number; Downtime: number }> = {};
    logs.forEach(l => {
      if (l.date) {
        if (!data[l.date]) {
          data[l.date] = { Production: 0, Downtime: 0 };
        }
        data[l.date].Production += l.duration || 0;
        data[l.date].Downtime += l.downtime_min || 0;
      }
    });
    return Object.entries(data)
      .map(([date, val]) => ({
        dateRaw: date,
        date: formatDateLabel(date),
        Production: val.Production,
        Downtime: val.Downtime
      }))
      .sort((a, b) => a.dateRaw.localeCompare(b.dateRaw));
  }, [logs]);

  // Operator-attributable factors (Horizontal Bar Chart)
  const operatorFactorsData = useMemo(() => {
    const mins: Record<string, number> = {};
    logs.forEach(l => {
      if (l.downtime_entries && l.downtime_entries.length > 0) {
        l.downtime_entries.forEach(entry => {
          const f = factors.find(fac => fac.factor_id === entry.factor_id);
          const isOpErr = entry.operator_error !== undefined ? entry.operator_error : (f?.operator_error || false);
          if (isOpErr && f) {
            mins[f.description] = (mins[f.description] || 0) + (entry.downtime_min || 0);
          }
        });
      } else if (l.downtime_min) {
        const f = factors.find(fac => fac.factor_id === l.factor_id);
        const isOpErr = f?.operator_error || false;
        if (isOpErr && f) {
          mins[f.description] = (mins[f.description] || 0) + l.downtime_min;
        }
      }
    });
    return Object.entries(mins).map(([name, Downtime]) => ({ name, Downtime }))
      .sort((a, b) => b.Downtime - a.Downtime);
  }, [logs, factors]);

  // Shift factors breakdown for the highest-downtime shift
  const shiftFactorsData = useMemo(() => {
    const shiftDowntimes: Record<string, number> = {};
    logs.forEach(l => {
      const sh = l.shift || "Morning";
      shiftDowntimes[sh] = (shiftDowntimes[sh] || 0) + (l.downtime_min || 0);
    });
    const highestShift = Object.entries(shiftDowntimes).sort((a, b) => b[1] - a[1])[0]?.[0] || "Night";

    const mins: Record<string, number> = {};
    logs.forEach(l => {
      if (l.shift === highestShift) {
        if (l.downtime_entries && l.downtime_entries.length > 0) {
          l.downtime_entries.forEach(entry => {
            const f = factors.find(fac => fac.factor_id === entry.factor_id);
            const desc = f ? f.description : "Other";
            mins[desc] = (mins[desc] || 0) + (entry.downtime_min || 0);
          });
        } else if (l.downtime_min) {
          const f = factors.find(fac => fac.factor_id === l.factor_id);
          const desc = f ? f.description : "Other";
          mins[desc] = (mins[desc] || 0) + l.downtime_min;
        }
      }
    });

    return {
      shift: highestShift,
      data: Object.entries(mins).map(([name, Downtime]) => ({ name, Downtime }))
        .sort((a, b) => b.Downtime - a.Downtime)
    };
  }, [logs, factors]);

  // Product factors breakdown for the highest-downtime product
  const productFactorsData = useMemo(() => {
    const prodDowntimes: Record<string, number> = {};
    logs.forEach(l => {
      prodDowntimes[l.product_id] = (prodDowntimes[l.product_id] || 0) + (l.downtime_min || 0);
    });
    const highestProdId = Object.entries(prodDowntimes).sort((a, b) => b[1] - a[1])[0]?.[0] || "CO-600";
    const prodFlavor = PRODUCTS.find(p => p.product_id === highestProdId)?.flavor || highestProdId;

    const mins: Record<string, number> = {};
    logs.forEach(l => {
      if (l.product_id === highestProdId) {
        if (l.downtime_entries && l.downtime_entries.length > 0) {
          l.downtime_entries.forEach(entry => {
            const f = factors.find(fac => fac.factor_id === entry.factor_id);
            const desc = f ? f.description : "Other";
            mins[desc] = (mins[desc] || 0) + (entry.downtime_min || 0);
          });
        } else if (l.downtime_min) {
          const f = factors.find(fac => fac.factor_id === l.factor_id);
          const desc = f ? f.description : "Other";
          mins[desc] = (mins[desc] || 0) + l.downtime_min;
        }
      }
    });

    return {
      productId: highestProdId,
      flavor: prodFlavor,
      data: Object.entries(mins).map(([name, Downtime]) => ({ name, Downtime }))
        .sort((a, b) => b.Downtime - a.Downtime)
    };
  }, [logs, factors]);

  return (
    <div className="flex flex-col gap-[28px] w-full">
      
      {/* ======================================================================
          DASHBOARD 1: OVERVIEW DASHBOARD VIEW
          ====================================================================== */}
      {currentDashboard === "overview" && (
        <div className="flex flex-col gap-6">
          
          {/* Main heading row */}
          <div className="flex items-center gap-3 border-b pb-3 border-gray-800/10 dark:border-slate-800">
            <div className={`p-2 rounded-xl ${isDarkMode ? "bg-cyan-500/10 text-cyan-400" : "bg-[#FAF9F5] text-[#1B432C] border border-[#E6E5DF]"}`}>
              <Layers className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-[22px] font-bold tracking-tight">Manufacture Line | Overview</h2>
              <p className="text-[12px] text-gray-500 font-medium">Enterprise Manufacturing Execution System (MES) summary dashboard</p>
            </div>
          </div>

          {/* Split Layout: Sub-KPI Column + Charts Grid */}
          <div className="flex flex-col xl:flex-row gap-6 items-stretch w-full">
            
            {/* Left side: Vertical Column of 5 Sub-KPIs */}
            <div className="flex flex-col gap-3 w-full xl:w-64 shrink-0">
              <div className={`h-[68px] p-3 rounded-[12px] border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-[#FAF9F5] border-blue-100"} flex flex-col justify-between shadow-sm`}>
                <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-wider leading-none"># of Batch</span>
                <strong className="text-[18px] font-black text-blue-500 dark:text-cyan-400 leading-none">{stats.totalBatches}</strong>
              </div>
              <div className={`h-[68px] p-3 rounded-[12px] border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-[#FAF9F5] border-blue-100"} flex flex-col justify-between shadow-sm`}>
                <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-wider leading-none"># of Operator</span>
                <strong className="text-[18px] font-black text-blue-500 dark:text-cyan-400 leading-none">{stats.totalOperators}</strong>
              </div>
              <div className={`h-[68px] p-3 rounded-[12px] border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-[#FAF9F5] border-blue-100"} flex flex-col justify-between shadow-sm`}>
                <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-wider leading-none"># of Product</span>
                <strong className="text-[18px] font-black text-blue-500 dark:text-cyan-400 leading-none">{stats.totalProducts}</strong>
              </div>
              <div className={`h-[68px] p-3 rounded-[12px] border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-[#FAF9F5] border-blue-100"} flex flex-col justify-between shadow-sm`}>
                <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-wider leading-none">Total Duration</span>
                <strong className="text-[18px] font-black text-blue-500 dark:text-cyan-400 leading-none">{stats.totalDuration} <span className="text-[9px] font-normal text-gray-400">min</span></strong>
              </div>
              <div className={`h-[68px] p-3 rounded-[12px] border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-[#FAF9F5] border-blue-100"} flex flex-col justify-between shadow-sm`}>
                <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-wider leading-none">Productivity Score</span>
                <strong className="text-[18px] font-black text-blue-500 dark:text-cyan-400 leading-none">{stats.productivityScore}%</strong>
              </div>

              {/* Dark Factory Conveyor Image */}
              <div className="flex-1 min-h-[140px] xl:min-h-0 xl:h-0 w-full rounded-[12px] border border-slate-200/60 dark:border-slate-800/80 overflow-hidden relative group shadow-sm flex flex-col justify-end bg-slate-950">
                <img
                  src="/src/assets/images/dark_factory_conveyor_1783059222941.jpg"
                  alt="Industrial conveyor automated line"
                  className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent flex flex-col justify-end p-3 pointer-events-none">
                  <div className="flex items-center gap-1.5 text-[8.5px] font-mono text-cyan-400 bg-slate-900/95 backdrop-blur px-1.5 py-0.5 rounded border border-cyan-500/20 w-fit">
                    <span className="h-1.5 w-1.5 rounded-full bg-cyan-500 animate-ping"></span>
                    MONITORING ACTIVE
                  </div>
                </div>
              </div>
            </div>

            {/* Right side: 6 Grid Charts block */}
            <div className="flex-1 w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              
              {/* Chart 1: Daily Batch Performance */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"}`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Daily Batch Performance</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Quantity of batches processed per day</p>
              </div>
              <div className="h-[170px] w-full mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={dailyBatchPerformanceData} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
                    <defs>
                      <linearGradient id="batchesGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={isDarkMode ? "#06B6D4" : "#1B432C"} stopOpacity={0.25} />
                        <stop offset="95%" stopColor={isDarkMode ? "#06B6D4" : "#1B432C"} stopOpacity={0.01} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"} strokeWidth={0.5} />
                    <XAxis dataKey="date" stroke="#64748b" fontSize={9} tickLine={false} />
                    <YAxis stroke="#64748b" fontSize={9} tickLine={false} allowDecimals={false} />
                    <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    <Area type="monotone" dataKey="Batches" stroke={isDarkMode ? "#06B6D4" : "#1B432C"} strokeWidth={1.5} fill="url(#batchesGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: On-Time vs Delayed Status (20% smaller donut) */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"}`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">On-Time vs. Delayed Status</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Proportion of prompt vs late batches</p>
              </div>
              <div className="h-[170px] w-full flex flex-col justify-between mt-2">
                <div className="relative flex-1 flex items-center justify-center min-h-0">
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center px-1">
                    <strong className={`text-[18px] font-black leading-none ${isDarkMode ? "text-white" : "text-slate-800"}`}>{stats.totalBatches}</strong>
                    <span className="text-[8.5px] font-bold text-gray-500 uppercase tracking-wider mt-1 block"># of Batches</span>
                  </div>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={onTimeVsDelayedData} innerRadius={48} outerRadius={70} paddingAngle={4} dataKey="value" cx="50%" cy="50%">
                        <Cell fill={isDarkMode ? "#10B981" : "#1B432C"} />
                        <Cell fill={isDarkMode ? "#EF4444" : "#8B0000"} />
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center flex-wrap gap-x-2 text-[9px] font-mono text-gray-400 mt-1">
                  {onTimeVsDelayedData.map((d, idx) => (
                    <div key={idx} className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: idx === 0 ? (isDarkMode ? "#10B981" : "#1B432C") : (isDarkMode ? "#EF4444" : "#8B0000") }}></span>
                      <span>{d.name}: {d.value} ({d.percentage}%)</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Chart 3: Comparative Shift Efficiency */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"}`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Shift Efficiency</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Comparative batch count per work shift</p>
              </div>
              <div className="h-[170px] w-full mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={shiftEfficiencyData} layout="vertical" margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"} strokeWidth={0.5} />
                    <XAxis type="number" stroke="#64748b" fontSize={9} tickLine={false} allowDecimals={false} />
                    <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={9} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    <Bar dataKey="Batches" fill={isDarkMode ? "#3B82F6" : "#4E925F"} radius={[0, 4, 4, 0]} barSize={10} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 4: # of batches per operator */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"}`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Batches per Operator</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Total batches processed by each crew member</p>
              </div>
              <div className="h-[170px] w-full mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={batchesPerOperatorData} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"} strokeWidth={0.5} />
                    <XAxis dataKey="name" stroke="#64748b" fontSize={9} tickLine={false} />
                    <YAxis stroke="#64748b" fontSize={9} tickLine={false} allowDecimals={false} />
                    <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    <Bar dataKey="Batches" fill={isDarkMode ? "#8B5CF6" : "#2E6F40"} radius={[3, 3, 0, 0]} barSize={12}>
                      {batchesPerOperatorData.map((_, idx) => (
                        <Cell key={`cell-${idx}`} fill={themeColors[idx % themeColors.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 5: # of batch per product */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"}`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Batches per Product</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Distribution of output types</p>
              </div>
              <div className="h-[170px] w-full mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={batchesPerProductData} layout="vertical" margin={{ top: 5, right: 10, left: -15, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"} strokeWidth={0.5} />
                    <XAxis type="number" stroke="#64748b" fontSize={9} tickLine={false} allowDecimals={false} />
                    <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={8} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    <Bar dataKey="Batches" fill={isDarkMode ? "#EC4899" : "#5C8B68"} radius={[0, 3, 3, 0]} barSize={10} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 6: Production Time vs. Benchmark */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"}`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Production vs. Benchmark</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Actual batch runtime against design cycle targets</p>
              </div>
              <div className="h-[170px] w-full mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={productionVsBenchmarkData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"} strokeWidth={0.5} />
                    <XAxis dataKey="batch" stroke="#64748b" fontSize={8} tickLine={false} />
                    <YAxis stroke="#64748b" fontSize={9} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    <Bar dataKey="Actual Duration" fill={isDarkMode ? "#3B82F6" : "#2E6F40"} radius={[2, 2, 0, 0]} barSize={10} />
                    <Line type="monotone" dataKey="Benchmark" stroke={isDarkMode ? "#F59E0B" : "#FF6347"} strokeWidth={1.2} dot={false} strokeDasharray="4 4" />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </div>

          </div> {/* Ends the overview grid */}
        </div> {/* Ends the overview split layout container */}
      </div>
    )}

      {/* ======================================================================
          DASHBOARD 2: DOWNTIME ANALYSIS VIEW
          ====================================================================== */}
      {currentDashboard === "analysis" && (
        <div className="flex flex-col gap-6">
          
          {/* Main heading row */}
          <div className="flex items-center gap-3 border-b pb-3 border-gray-800/10 dark:border-slate-800">
            <div className={`p-2 rounded-xl ${isDarkMode ? "bg-cyan-500/10 text-cyan-400" : "bg-[#FAF9F5] text-[#1B432C] border border-[#E6E5DF]"}`}>
              <TrendingUp className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-[22px] font-bold tracking-tight">Manufacture Line | Downtime Analysis</h2>
              <p className="text-[12px] text-gray-500 font-medium">Detailed breakdown of total operational line stoppage events</p>
            </div>
          </div>

          {/* Unified CSS Grid Layout */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-[256px_1fr_1fr_1fr] gap-4 items-start w-full">
            
            {/* Left side: Vertical Column of 3 Sub-KPIs */}
            <div className="flex flex-col gap-3 w-full md:col-span-2 lg:col-span-3 xl:col-span-1 xl:col-start-1 xl:col-end-2 xl:row-start-1 xl:row-end-2 shrink-0">
              <div className={`h-[68px] p-3 rounded-[12px] border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-[#FAF9F5] border-blue-100"} flex flex-col justify-between shadow-sm`}>
                <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-wider leading-none">Total Downtime</span>
                <strong className="text-[18px] font-black text-blue-500 dark:text-cyan-400 leading-none">
                  {stats.totalDowntime} <span className="text-[10px] font-semibold text-gray-400">min</span>
                </strong>
              </div>
              <div className={`h-[68px] p-3 rounded-[12px] border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-[#FAF9F5] border-blue-100"} flex flex-col justify-between shadow-sm`}>
                <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-wider leading-none">AVG Downtime</span>
                <strong className="text-[18px] font-black text-blue-500 dark:text-cyan-400 leading-none">
                  {stats.avgDowntime} <span className="text-[10px] font-semibold text-gray-400">min</span>
                </strong>
              </div>
              <div className={`h-[68px] p-3 rounded-[12px] border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-[#FAF9F5] border-blue-100"} flex flex-col justify-between shadow-sm`}>
                <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-wider leading-none">Downtime Factors</span>
                <strong className="text-[18px] font-black text-blue-500 dark:text-cyan-400 leading-none">{stats.downtimeFactorsCount}</strong>
              </div>
            </div>

            {/* Chart 1: Operator vs. Non-Operator Downtime (20% smaller donut) */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"} xl:col-start-2 xl:col-end-3 xl:row-start-1 xl:row-end-2`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Operator vs. Non-Operator</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Line stoppage causes division</p>
              </div>
              <div className="h-[170px] w-full flex flex-col justify-between mt-2">
                <div className="relative flex-1 flex items-center justify-center min-h-0">
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center px-1">
                    <strong className={`text-[18px] font-black leading-none ${isDarkMode ? "text-white" : "text-slate-800"}`}>{totalOperatorDowntime}m</strong>
                    <span className="text-[8.5px] font-bold text-gray-500 uppercase tracking-wider mt-1 block">Total Downtime</span>
                  </div>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={operatorVsNonOperatorDowntimeData} innerRadius={48} outerRadius={70} paddingAngle={4} dataKey="value" cx="50%" cy="50%">
                        <Cell fill={isDarkMode ? "#F59E0B" : "#2E6F40"} />
                        <Cell fill={isDarkMode ? "#3B82F6" : "#5C8B68"} />
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center flex-wrap gap-x-2 text-[9px] font-mono text-gray-400 mt-1">
                  {operatorVsNonOperatorDowntimeData.map((d, idx) => (
                    <div key={idx} className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: idx === 0 ? (isDarkMode ? "#F59E0B" : "#2E6F40") : (isDarkMode ? "#3B82F6" : "#5C8B68") }}></span>
                      <span>{d.name}: {d.value}m ({d.percentage}%)</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Chart 2: Downtime Trend (min) */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"} xl:col-start-3 xl:col-end-4 xl:row-start-1 xl:row-end-2`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Downtime Trend</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Daily accumulated line stoppages in minutes</p>
              </div>
              <div className="h-[170px] w-full mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={dailyDowntimeData} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
                    <defs>
                      <linearGradient id="downtimeAreaGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={isDarkMode ? "#EF4444" : "#1B432C"} stopOpacity={0.25} />
                        <stop offset="95%" stopColor={isDarkMode ? "#EF4444" : "#1B432C"} stopOpacity={0.01} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"} strokeWidth={0.5} />
                    <XAxis dataKey="date" stroke="#64748b" fontSize={9} tickLine={false} />
                    <YAxis stroke="#64748b" fontSize={9} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    <Area type="monotone" dataKey="Downtime" stroke={isDarkMode ? "#EF4444" : "#1B432C"} strokeWidth={1.5} fill="url(#downtimeAreaGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 3: Downtime per shift (min) */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"} xl:col-start-4 xl:col-end-5 xl:row-start-1 xl:row-end-2`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Downtime per Shift</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Stoppages experienced during each shift</p>
              </div>
              <div className="h-[170px] w-full mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={shiftDowntimeData} layout="vertical" margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"} strokeWidth={0.5} />
                    <XAxis type="number" stroke="#64748b" fontSize={9} tickLine={false} />
                    <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={9} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    <Bar dataKey="Downtime" fill={isDarkMode ? "#F59E0B" : "#2E6F40"} radius={[0, 3, 3, 0]} barSize={10} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 4: Downtime_Factors (min) */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"} xl:col-span-2 xl:col-start-1 xl:col-end-3 xl:row-start-2 xl:row-end-3`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Downtime by Factor</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Total minutes lost by primary root cause</p>
              </div>
              <div className="h-[170px] w-full mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={factorDowntimeData} margin={{ top: 5, right: 5, left: -25, bottom: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"} strokeWidth={0.5} />
                    <XAxis dataKey="name" stroke="#64748b" fontSize={7} angle={-15} textAnchor="end" interval={0} height={25} />
                    <YAxis stroke="#64748b" fontSize={9} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    <Bar dataKey="Downtime" fill={isDarkMode ? "#EF4444" : "#1B432C"} radius={[2, 2, 0, 0]} barSize={10}>
                      {factorDowntimeData.map((_, idx) => (
                        <Cell key={`cell-${idx}`} fill={themeColors[idx % themeColors.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 5: Downtime_Product (min) */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"} xl:col-start-3 xl:col-end-4 xl:row-start-2 xl:row-end-3`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Downtime by Product</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Total loss time allocated per product type</p>
              </div>
              <div className="h-[170px] w-full mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={productDowntimeData} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"} strokeWidth={0.5} />
                    <XAxis dataKey="name" stroke="#64748b" fontSize={8} tickLine={false} />
                    <YAxis stroke="#64748b" fontSize={9} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    <Bar dataKey="Downtime" fill={isDarkMode ? "#3B82F6" : "#4E925F"} radius={[3, 3, 0, 0]} barSize={12}>
                      {productDowntimeData.map((_, idx) => (
                        <Cell key={`cell-${idx}`} fill={themeColors[idx % themeColors.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 6: Downtime Operator (min) (20% smaller donut) */}
            <div className={`p-3.5 rounded-[12px] border shadow-sm flex flex-col justify-between h-[250px] ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"} xl:col-start-4 xl:col-end-5 xl:row-start-2 xl:row-end-3`}>
              <div>
                <h3 className="text-[13px] font-bold tracking-tight text-slate-900 dark:text-white leading-none">Downtime by Operator</h3>
                <p className="text-[10px] text-gray-500 font-medium mt-1 leading-none">Loss time logged under each operator</p>
              </div>
              <div className="h-[170px] w-full flex flex-col justify-between relative mt-2">
                <div className="relative flex-1 flex items-center justify-center min-h-0">
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center px-1">
                    <strong className={`text-[18px] font-black leading-none ${isDarkMode ? "text-white" : "text-slate-800"}`}>{totalOperatorDowntime}m</strong>
                    <span className="text-[8.5px] font-bold text-gray-500 uppercase tracking-wider mt-1 block">Total Downtime</span>
                  </div>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={operatorDowntimeData} innerRadius={48} outerRadius={70} paddingAngle={4} dataKey="value" cx="50%" cy="50%">
                        {operatorDowntimeData.map((_, idx) => (
                          <Cell key={`cell-${idx}`} fill={themeColors[idx % themeColors.length]} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: isDarkMode ? "#0B0D12" : "#FFF", border: "1px solid #334155", fontSize: 10 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex flex-wrap justify-center gap-x-2 text-[9px] font-mono text-gray-400 mt-1">
                  {operatorDowntimeData.map((d, idx) => (
                    <div key={idx} className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: themeColors[idx % themeColors.length] }}></span>
                      <span>{d.name}: {d.value}m</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div> {/* Ends the analysis split layout container */}
      </div>
    )}

      {/* Modern Heatmap Ribbon representing conveyor line historical runs (40% smaller) */}
      <div className={`p-3.5 rounded-[12px] border ${isDarkMode ? "bg-slate-950/50 border-slate-800" : "bg-[#FAF9F5] border-slate-200"}`}>
        <span className="text-[10px] font-mono text-gray-400 flex items-center gap-1.5 mb-2 font-bold uppercase tracking-wider">
          <Activity className="h-3.5 w-3.5 text-cyan-400 animate-pulse" />
          Conveyor Batch Chronological Health Ribbon (Optimal vs Delayed)
        </span>
        <div className="flex flex-wrap gap-[4px] p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/50 justify-start">
          {logs.slice(0, 36).reverse().map((log) => {
            const isOptimal = log.status === "Optimal";
            return (
              <div
                key={log.id}
                className={`w-[10px] h-[18px] rounded-[3px] transition-all cursor-help relative group ${
                  isOptimal
                    ? "bg-emerald-500/80 hover:bg-emerald-400 shadow-sm"
                    : "bg-rose-500/80 hover:bg-rose-400 shadow-sm"
                }`}
              >
                {/* Hover Details Box */}
                <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 bg-[#12141C] border border-slate-700/60 text-white text-[10px] rounded-lg p-2 font-mono hidden group-hover:block whitespace-nowrap z-50 shadow-2xl">
                  <div className="font-bold border-b border-slate-700 pb-1 mb-1">Batch #{log.batch} ({log.status})</div>
                  <div>Product: {log.flavor} {log.size}</div>
                  <div>Operator: {log.operator_name}</div>
                  <div>Duration: {log.duration} mins</div>
                  {log.downtime_min && <div className="text-rose-400 font-semibold">Downtime: {log.downtime_min}m ({log.downtime_reason})</div>}
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex justify-between items-center text-[10px] text-gray-500 font-mono mt-2">
          <span>&larr; Chronological Past</span>
          <div className="flex gap-4">
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-emerald-500"></span>Optimal Cycle</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-rose-500"></span>Downtime Delay</span>
          </div>
          <span>Most Recent Run &rarr;</span>
        </div>
      </div>

    </div>
  );
}
