import React from "react";
import { Factory, Layers, TrendingUp, FileSpreadsheet, Settings, Database } from "lucide-react";

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  isDbSynced: boolean;
  operator: string;
}

export default function Navigation({
  activeTab,
  setActiveTab,
  isDarkMode,
  setIsDarkMode,
  isDbSynced,
  operator,
}: NavigationProps) {
  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: Layers },
    { id: "reports", label: "Reports", icon: FileSpreadsheet },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .slice(0, 2)
      .toUpperCase();
  };

  return (
    <>
      {/* DESKTOP LEFT FLOATING CAPSULE SIDEBAR (Hidden on Mobile) */}
      <aside
        className={`hidden md:flex fixed left-4 top-4 bottom-4 w-24 bg-[#07080B]/95 border border-slate-800/80 rounded-[24px] flex-col justify-between py-8 px-2 z-50 shadow-2xl transition-all duration-300`}
      >
        {/* Top: Brand logo */}
        <div className="flex flex-col items-center gap-1 text-center">
          <div className="w-10 h-10 bg-gradient-to-tr from-cyan-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white hover:rotate-12 transition-transform duration-300">
            <Factory className="w-5 h-5" />
          </div>
          <div className="flex flex-col mt-2">
            <span className="text-[11px] font-extrabold tracking-tight text-white leading-none">Smart MES</span>
            <span className="text-[7px] font-mono tracking-widest text-cyan-400 font-extrabold uppercase leading-none mt-1">Terminal</span>
          </div>
        </div>

        {/* Center: Vertical Navigation Buttons */}
        <nav className="flex flex-col items-center gap-5 w-full">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-16 h-16 rounded-[16px] flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer group relative ${
                  isActive
                    ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-[0_0_15px_rgba(6,182,212,0.15)]"
                    : "text-gray-400 hover:text-gray-200 hover:bg-slate-900/40 border border-transparent"
                }`}
                title={tab.label}
              >
                <Icon className="w-5 h-5 transition-transform group-hover:scale-105" />
                <span className="text-[8px] font-bold uppercase tracking-wider leading-none mt-0.5">{tab.label}</span>
                {isActive && (
                  <span className="absolute left-0 top-1/4 bottom-1/4 w-[3px] bg-cyan-400 rounded-r-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom: Empty footer/spacing to match pill symmetry */}
        <div className="flex flex-col items-center gap-4 text-slate-600 text-[8px] font-mono uppercase tracking-widest font-bold">
          v1.4.0
        </div>
      </aside>

      {/* MOBILE TOP NAVIGATION BAR (Hidden on Desktop) */}
      <header
        className={`md:hidden h-16 border-b flex items-center justify-between px-4 z-50 sticky top-0 backdrop-blur-md transition-all duration-300 ${
          isDarkMode
            ? "border-slate-800/80 bg-[#0A0B0E]/90 text-[#E4E6EB]"
            : "border-slate-200 bg-white/90 text-slate-800"
        }`}
      >
        {/* Left: Brand logo */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-gradient-to-tr from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white">
            <Factory className="w-5 h-5" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-extrabold tracking-tight">Smart MES</span>
            <span className="text-[9px] font-mono tracking-widest text-cyan-400 font-extrabold uppercase leading-none">Terminal</span>
          </div>
        </div>

        {/* Right: Actions & User Operator initials */}
        <div className="flex items-center gap-4">
          {/* Cloud Sync Status Icon */}
          <div
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 border text-[10px] font-mono uppercase font-bold tracking-wider transition-all cursor-pointer relative group ${
              isDbSynced
                ? isDarkMode
                  ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                  : "bg-emerald-50 border-emerald-200 text-emerald-600"
                : isDarkMode
                ? "bg-amber-500/10 border-amber-500/20 text-amber-400"
                : "bg-amber-50 border-amber-200 text-amber-600"
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isDbSynced ? "Live Sync" : "Buffer"}</span>
            <span className="flex h-1.5 w-1.5">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isDbSynced ? "bg-emerald-400" : "bg-amber-400"}`}></span>
              <span className={`relative inline-flex rounded-full h-1.5 w-1.5 ${isDbSynced ? "bg-emerald-500" : "bg-amber-500"}`}></span>
            </span>
          </div>

          {/* User initials bubble */}
          <div className="flex items-center gap-2 border-l pl-4 border-slate-800/10 dark:border-slate-800/30">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border transition-all ${
                isDarkMode ? "bg-slate-800 border-slate-700 text-white" : "bg-slate-200 border-slate-300 text-slate-800"
              }`}
            >
              {getInitials(operator)}
            </div>
            <span className="hidden lg:inline text-xs font-semibold">{operator}</span>
          </div>
        </div>
      </header>

      {/* MOBILE BOTTOM NAVIGATION BAR */}
      <div
        className={`md:hidden fixed bottom-0 left-0 right-0 h-[56px] border-t z-50 px-4 flex items-center justify-between transition-all ${
          isDarkMode ? "border-slate-800 bg-[#0A0B0E]/95 text-[#E4E6EB]" : "border-slate-200 bg-white/95 text-slate-800"
        } backdrop-blur-md shadow-2xl pb-safe`}
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-1 flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                isActive
                  ? isDarkMode
                    ? "text-cyan-400 font-bold"
                    : "text-blue-600 font-bold"
                  : isDarkMode
                  ? "text-gray-500 hover:text-gray-300"
                  : "text-slate-400 hover:text-slate-700"
              }`}
            >
              <Icon className="w-4.5 h-4.5" />
              <span className="text-[9px] font-mono tracking-wider uppercase">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </>
  );
}
