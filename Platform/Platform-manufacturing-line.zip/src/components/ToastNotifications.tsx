import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { CheckCircle2, AlertTriangle, Info, X } from "lucide-react";

export interface Toast {
  id: string;
  message: string;
  type: "success" | "warning" | "error" | "info";
}

interface ToastNotificationsProps {
  toasts: Toast[];
  removeToast: (id: string) => void;
}

export default function ToastNotifications({ toasts, removeToast }: ToastNotificationsProps) {
  return (
    <div className="fixed top-4 right-4 z-[9999] flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => {
          let bgColor = "bg-slate-900/90 text-white border-slate-700/50";
          let icon = <Info className="h-5 w-5 text-cyan-400" />;

          if (toast.type === "success") {
            bgColor = "bg-emerald-950/90 text-emerald-100 border-emerald-500/30";
            icon = <CheckCircle2 className="h-5 w-5 text-emerald-400" />;
          } else if (toast.type === "warning") {
            bgColor = "bg-amber-950/90 text-amber-100 border-amber-500/30";
            icon = <AlertTriangle className="h-5 w-5 text-amber-400" />;
          } else if (toast.type === "error") {
            bgColor = "bg-rose-950/90 text-rose-100 border-rose-500/30";
            icon = <AlertTriangle className="h-5 w-5 text-rose-400" />;
          }

          return (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              onClick={() => removeToast(toast.id)}
              className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl border backdrop-blur-md shadow-lg relative cursor-pointer select-none hover:opacity-90 transition-all ${bgColor}`}
              id={`toast-${toast.id}`}
            >
              <div className="flex-shrink-0 mt-0.5">{icon}</div>
              <div className="flex-1 text-sm font-medium pr-2">{toast.message}</div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  removeToast(toast.id);
                }}
                className="flex-shrink-0 text-gray-400 hover:text-gray-200 transition-colors p-1 rounded-lg hover:bg-white/10 cursor-pointer pointer-events-auto relative z-20"
                aria-label="Close notification"
              >
                <X className="h-4 w-4 pointer-events-none" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
