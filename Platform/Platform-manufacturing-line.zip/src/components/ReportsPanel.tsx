import React, { useMemo, useState } from "react";
import { Download, FileText, ChevronRight, BarChart3, TrendingUp, Award, Calendar, AlertTriangle } from "lucide-react";
import { ProductionLog, Factor } from "../types";

interface ReportsPanelProps {
  logs: ProductionLog[];
  factors: Factor[];
  isDarkMode: boolean;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
}

export default function ReportsPanel({ logs, factors, isDarkMode, addToast }: ReportsPanelProps) {
  const [reportType, setReportType] = useState<"operators" | "products" | "downtime">("operators");

  // 1. Operators scorecard report calculation
  const operatorsReport = useMemo(() => {
    const map: Record<string, { count: number; totalDuration: number; totalDowntime: number; optimalCount: number; opErrors: number }> = {};
    
    logs.forEach((l) => {
      if (!map[l.operator_name]) {
        map[l.operator_name] = { count: 0, totalDuration: 0, totalDowntime: 0, optimalCount: 0, opErrors: 0 };
      }
      const item = map[l.operator_name];
      item.count += 1;
      item.totalDuration += l.duration;
      item.totalDowntime += l.downtime_min || 0;
      if (l.status === "Optimal") {
        item.optimalCount += 1;
      }

      // Check operator errors
      if (l.downtime_min && l.downtime_min > 0) {
        const fac = factors.find((f) => f.description === l.downtime_reason);
        if (fac && fac.operator_error) {
          item.opErrors += 1;
        }
      }
    });

    return Object.entries(map).map(([name, data]) => {
      const avgDuration = Math.round(data.totalDuration / data.count);
      const efficiency = Math.round((data.optimalCount / data.count) * 100);
      return {
        name,
        batches: data.count,
        avgDuration,
        totalDowntime: data.totalDowntime,
        efficiency,
        operatorErrors: data.opErrors,
        score: Math.max(10, Math.min(100, 100 - (data.opErrors * 15) - (Math.round(data.totalDowntime / data.count) * 0.5))),
      };
    }).sort((a, b) => b.score - a.score);
  }, [logs, factors]);

  // 2. Product line summary reports
  const productsReport = useMemo(() => {
    const map: Record<string, { count: number; totalDuration: number; totalDowntime: number; optimalCount: number; targetTime: number }> = {};
    
    logs.forEach((l) => {
      const key = `${l.flavor} (${l.size})`;
      if (!map[key]) {
        map[key] = { count: 0, totalDuration: 0, totalDowntime: 0, optimalCount: 0, targetTime: l.min_batch_time };
      }
      const item = map[key];
      item.count += 1;
      item.totalDuration += l.duration;
      item.totalDowntime += l.downtime_min || 0;
      if (l.status === "Optimal") {
        item.optimalCount += 1;
      }
    });

    return Object.entries(map).map(([name, data]) => {
      const avgDuration = Math.round(data.totalDuration / data.count);
      const avgDowntime = Math.round(data.totalDowntime / data.count);
      const oee = Math.round((data.optimalCount / data.count) * 100);
      return {
        name,
        batches: data.count,
        avgDuration,
        avgDowntime,
        targetTime: data.targetTime,
        deviation: avgDuration - data.targetTime,
        oee,
      };
    }).sort((a, b) => b.oee - a.oee);
  }, [logs]);

  // Export handlers
  const handleCSVExport = () => {
    let headers: string[] = [];
    let rows: string[][] = [];
    let title = "";

    if (reportType === "operators") {
      title = "Operator_Performance_Scorecard";
      headers = ["Operator Name", "Total Batches", "Avg Duration (mins)", "Total Downtime (mins)", "Optimal Ratio (%)", "Attributed Errors", "Performance Score"];
      rows = operatorsReport.map((op) => [
        op.name,
        op.batches.toString(),
        op.avgDuration.toString(),
        op.totalDowntime.toString(),
        `${op.efficiency}%`,
        op.operatorErrors.toString(),
        op.score.toFixed(1),
      ]);
    } else if (reportType === "products") {
      title = "Product_Line_Downtime_Analysis";
      headers = ["Product Line flavor", "Batches Run", "Avg Duration (mins)", "Avg Downtime (mins)", "Target Time (mins)", "Avg Deviation (mins)", "OEE Rate (%)"];
      rows = productsReport.map((p) => [
        p.name,
        p.batches.toString(),
        p.avgDuration.toString(),
        p.avgDowntime.toString(),
        p.targetTime.toString(),
        p.deviation.toString(),
        `${p.oee}%`,
      ]);
    } else {
      title = "Downtime_Stoppage_Factors";
      headers = ["Downtime Description", "Operator Error Flag", "Total Incident Minutes"];
      
      const counts: Record<string, { opError: boolean; mins: number }> = {};
      logs.forEach((l) => {
        if (l.downtime_reason) {
          if (!counts[l.downtime_reason]) {
            const f = factors.find((fac) => fac.description === l.downtime_reason);
            counts[l.downtime_reason] = {
              opError: f ? f.operator_error : false,
              mins: 0,
            };
          }
          counts[l.downtime_reason].mins += l.downtime_min || 0;
        }
      });
      rows = Object.entries(counts).map(([name, data]) => [
        name,
        data.opError ? "Yes" : "No",
        data.mins.toString(),
      ]);
    }

    const csvRows = [headers.join(",")];
    rows.forEach((r) => csvRows.push(r.join(",")));

    const blob = new Blob([csvRows.join("\n")], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", `${title}_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast(`${reportType.toUpperCase()} report exported successfully.`, "success");
  };

  const handlePrintPDF = () => {
    window.print();
    addToast("Print spool request triggered successfully.", "success");
  };

  return (
    <div
      className={`p-6 rounded-3xl border shadow-xl flex flex-col gap-6 ${
        isDarkMode ? "bg-[#0F1115]/80 border-[#22242D] backdrop-blur-md" : "bg-white border-slate-200"
      }`}
    >
      {/* Header operations */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b pb-4 border-gray-800/10 dark:border-slate-800">
        <div>
          <h2 className={`text-base font-bold tracking-tight ${isDarkMode ? "text-white" : "text-slate-900"}`}>
            Executive Operational Reports Builder
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Aggregate data metrics to generate formal production compliance or operator OEE scorecards
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={handleCSVExport}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-colors cursor-pointer ${
              isDarkMode ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-cyan-400" : "bg-slate-100 border-slate-200 hover:bg-slate-200 text-blue-600"
            }`}
          >
            <Download className="h-4 w-4" />
            <span>Download CSV</span>
          </button>
          <button
            onClick={handlePrintPDF}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-colors cursor-pointer ${
              isDarkMode ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-gray-200" : "bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-700"
            }`}
          >
            <FileText className="h-4 w-4" />
            <span>Print Report (PDF)</span>
          </button>
        </div>
      </div>

      {/* Tabs list inside the reports */}
      <div className="flex border-b border-slate-800/30 dark:border-slate-800 max-w-md">
        <button
          onClick={() => setReportType("operators")}
          className={`flex-1 py-3 text-xs font-bold transition-all text-center border-b-2 cursor-pointer ${
            reportType === "operators"
              ? "border-cyan-400 text-cyan-400 font-bold"
              : "border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          Operator Efficiency Scorecard
        </button>
        <button
          onClick={() => setReportType("products")}
          className={`flex-1 py-3 text-xs font-bold transition-all text-center border-b-2 cursor-pointer ${
            reportType === "products"
              ? "border-cyan-400 text-cyan-400 font-bold"
              : "border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          Product Line Delays
        </button>
        <button
          onClick={() => setReportType("downtime")}
          className={`flex-1 py-3 text-xs font-bold transition-all text-center border-b-2 cursor-pointer ${
            reportType === "downtime"
              ? "border-cyan-400 text-cyan-400 font-bold"
              : "border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          Incidents Matrix
        </button>
      </div>

      {/* Content Render Grid */}
      <div className="overflow-x-auto border rounded-2xl border-slate-200 dark:border-slate-800 bg-slate-950/20">
        {reportType === "operators" && (
          <table className="w-full text-left border-collapse min-w-[650px]">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/40 text-[10px] font-mono tracking-widest text-gray-500">
                <th className="py-4 px-5">Shift Operator</th>
                <th className="py-4 px-5">Cycles Run</th>
                <th className="py-4 px-5">Average Cycle Duration</th>
                <th className="py-4 px-5">Total Downtime Minutes</th>
                <th className="py-4 px-5">Optimal Runs Ratio</th>
                <th className="py-4 px-5">Operator Error Incidents</th>
                <th className="py-4 px-5 text-right pr-6">Efficiency Rank Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-xs">
              {operatorsReport.map((op, i) => (
                <tr key={op.name} className="hover:bg-cyan-500/[0.01]">
                  <td className="py-3 px-5 font-bold flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] text-gray-300">
                      {i + 1}
                    </span>
                    <span>{op.name}</span>
                  </td>
                  <td className="py-3 px-5 font-mono">{op.batches} batches</td>
                  <td className="py-3 px-5 font-mono">{op.avgDuration} mins</td>
                  <td className="py-3 px-5 font-mono text-rose-400">{op.totalDowntime}m</td>
                  <td className="py-3 px-5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold">{op.efficiency}%</span>
                      <div className="w-16 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div className="bg-emerald-400 h-full rounded-full" style={{ width: `${op.efficiency}%` }}></div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-5 font-mono text-amber-500">{op.operatorErrors}</td>
                  <td className="py-3 px-5 text-right pr-6 font-bold font-mono">
                    <span className={`px-2 py-1 rounded text-xs font-bold ${
                      op.score >= 80 ? "text-emerald-400 bg-emerald-500/10" : op.score >= 50 ? "text-amber-400 bg-amber-500/10" : "text-rose-400 bg-rose-500/10"
                    }`}>
                      {op.score.toFixed(1)} / 100
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {reportType === "products" && (
          <table className="w-full text-left border-collapse min-w-[650px]">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/40 text-[10px] font-mono tracking-widest text-gray-500">
                <th className="py-4 px-5">Product SKU Flavor</th>
                <th className="py-4 px-5">Batches Completed</th>
                <th className="py-4 px-5">Avg Duration</th>
                <th className="py-4 px-5">Standard Target Time</th>
                <th className="py-4 px-5">Average Cycle Loss</th>
                <th className="py-4 px-5">OEE Availability</th>
                <th className="py-4 px-5 text-right pr-6">Performance Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-xs">
              {productsReport.map((p) => (
                <tr key={p.name} className="hover:bg-cyan-500/[0.01]">
                  <td className="py-3 px-5 font-bold text-gray-200">{p.name}</td>
                  <td className="py-3 px-5 font-mono">{p.batches} completed</td>
                  <td className="py-3 px-5 font-mono font-semibold">{p.avgDuration}m</td>
                  <td className="py-3 px-5 font-mono text-gray-500">{p.targetTime}m</td>
                  <td className="py-3 px-5 font-mono text-rose-400">+{p.avgDowntime}m</td>
                  <td className="py-3 px-5 font-bold font-mono text-cyan-400">{p.oee}% OEE</td>
                  <td className="py-3 px-5 text-right pr-6 font-semibold">
                    <span className={`px-2 py-1 rounded text-[10px] font-bold ${
                      p.oee >= 25 ? "text-amber-400 bg-amber-500/10" : "text-rose-400 bg-rose-500/10"
                    }`}>
                      {p.oee >= 25 ? "OPERATIONAL DEVIATION" : "CRITICAL STOPPAGE"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {reportType === "downtime" && (
          <table className="w-full text-left border-collapse min-w-[650px]">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/40 text-[10px] font-mono tracking-widest text-gray-500">
                <th className="py-4 px-5">Stoppage Factor description</th>
                <th className="py-4 px-5">Incident Category</th>
                <th className="py-4 px-5">Total Delayed Minutes</th>
                <th className="py-4 px-5">Share of Total Stoppage</th>
                <th className="py-4 px-5 text-right pr-6">Mechanical Threat Level</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-xs">
              {Object.entries(
                logs.reduce((acc, l) => {
                  if (l.downtime_reason) {
                    const f = factors.find((fac) => fac.description === l.downtime_reason);
                    if (!acc[l.downtime_reason]) {
                      acc[l.downtime_reason] = { mins: 0, opError: f ? f.operator_error : false };
                    }
                    acc[l.downtime_reason].mins += l.downtime_min || 0;
                  }
                  return acc;
                }, {} as Record<string, { mins: number; opError: boolean }>)
              ).sort((a, b) => b[1].mins - a[1].mins).map(([name, data]) => {
                const totalDowntimeSum = logs.reduce((acc, l) => acc + (l.downtime_min || 0), 0);
                const percentShare = Math.round((data.mins / totalDowntimeSum) * 100);

                return (
                  <tr key={name} className="hover:bg-cyan-500/[0.01]">
                    <td className="py-3 px-5 font-bold">{name}</td>
                    <td className="py-3 px-5 font-semibold text-gray-400">
                      {data.opError ? (
                        <span className="text-amber-500">Human Operator Error</span>
                      ) : (
                        <span className="text-cyan-400">Mechanical/Systemic Line Fail</span>
                      )}
                    </td>
                    <td className="py-3 px-5 font-bold font-mono text-rose-400">{data.mins} mins</td>
                    <td className="py-3 px-5 font-mono">{percentShare}% of delays</td>
                    <td className="py-3 px-5 text-right pr-6 font-semibold">
                      <span className={`px-2 py-1 rounded text-[10px] font-bold ${
                        percentShare >= 20 ? "text-rose-400 bg-rose-500/10" : "text-amber-400 bg-amber-500/10"
                      }`}>
                        {percentShare >= 20 ? "CRITICAL THREAT" : "STANDARD VARIANCE"}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Footer statistics breakdown alert block */}
      <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row gap-4 items-center justify-between text-xs font-semibold ${
        isDarkMode ? "bg-slate-950/60 border-slate-800 text-gray-400" : "bg-slate-50 border-slate-200 text-slate-700"
      }`}>
        <div className="flex items-center gap-2">
          <Award className="h-5 w-5 text-cyan-400 animate-bounce" />
          <span>Best Performing Operator of this run: <strong>
            {operatorsReport.length > 0 ? operatorsReport[0].name : "Mac"}
          </strong></span>
        </div>
        <div className="flex items-center gap-2 text-rose-400">
          <AlertTriangle className="h-4.5 w-4.5" />
          <span>Major Bottleneck: <strong>Machine adjustment &amp; failures</strong></span>
        </div>
      </div>

    </div>
  );
}
