import React from "react";
import { Gauge, Layers, Clock, Cpu, HelpCircle } from "lucide-react";
import { ProductionLog } from "../types";

interface KPIStatsProps {
  logs: ProductionLog[];
  isDarkMode: boolean;
  vertical?: boolean;
}

export default function KPIStats({ logs, isDarkMode, vertical = false }: KPIStatsProps) {
  // Compute key production metrics
  const stats = React.useMemo(() => {
    if (logs.length === 0) {
      return {
        totalBatches: 0,
        totalDowntime: 0,
        performance: 0,
        productivity: 0,
        topFactor: "None",
        maxDowntime: 0,
      };
    }

    const totalBatches = logs.length;
    const totalDuration = logs.reduce((acc, l) => acc + (l.duration || 0), 0);
    const totalDowntime = logs.reduce((acc, l) => acc + (l.downtime_min || 0), 0);

    // Performance = (Sum of optimal min_batch_times / Sum of actual durations) * 100
    const sumMinTimes = logs.reduce((acc, l) => acc + (l.min_batch_time || 60), 0);
    const performance = Math.min(100, Math.round((sumMinTimes / totalDuration) * 100));

    // Productivity = (Total Run time without delay / Total elapsed time) * 100
    const runTimeOnly = totalDuration - totalDowntime;
    const productivity = Math.round((runTimeOnly / totalDuration) * 100);

    // Find top downtime factor (the one with the most cumulative downtime)
    const factorMins: Record<string, number> = {};
    logs.forEach(l => {
      if (l.downtime_entries && l.downtime_entries.length > 0) {
        l.downtime_entries.forEach(entry => {
          const desc = entry.downtime_reason || "Other";
          factorMins[desc] = (factorMins[desc] || 0) + (entry.downtime_min || 0);
        });
      } else if (l.downtime_min) {
        const desc = l.downtime_reason || "Other";
        factorMins[desc] = (factorMins[desc] || 0) + l.downtime_min;
      }
    });

    let topFactor = "None";
    let maxDowntime = 0;
    Object.entries(factorMins).forEach(([desc, mins]) => {
      if (mins > maxDowntime) {
        maxDowntime = mins;
        topFactor = desc;
      }
    });

    return {
      totalBatches,
      totalDowntime,
      performance,
      productivity,
      topFactor,
      maxDowntime,
    };
  }, [logs]);

  const cards = [
    {
      label: "Productivity Score",
      value: `${stats.productivity}%`,
      icon: Gauge,
      color: "from-cyan-500/20 to-blue-500/20",
      glowColor: "shadow-[0_0_15px_rgba(6,182,212,0.25)]",
      textColor: "text-cyan-400",
      desc: "Conveyor active runtime ratio",
    },
    {
      label: "Batch Throughput",
      value: stats.totalBatches,
      icon: Layers,
      color: "from-blue-500/20 to-indigo-500/20",
      glowColor: "shadow-[0_0_15px_rgba(59,130,246,0.25)]",
      textColor: "text-blue-400",
      desc: "Total sequential cycles completed",
    },
    {
      label: "Stoppage Loss",
      value: `${Math.floor(stats.totalDowntime / 60)}h ${stats.totalDowntime % 60}m`,
      icon: Clock,
      color: "from-sky-500/20 to-cyan-500/20",
      glowColor: "shadow-[0_0_15px_rgba(14,165,233,0.25)]",
      textColor: "text-sky-400",
      desc: "Total downtime stoppage elapsed",
    },
    {
      label: "Top Downtime Factor",
      value: stats.topFactor,
      icon: Cpu,
      color: "from-indigo-500/20 to-blue-500/20",
      glowColor: "shadow-[0_0_15px_rgba(99,102,241,0.25)]",
      textColor: "text-indigo-400",
      desc: stats.topFactor !== "None" ? `Responsible for ${stats.maxDowntime}m of delay` : "No stoppage delay logged",
    },
  ];

  return (
    <div className={`grid gap-3 w-full ${
      vertical ? "grid-cols-1" : "grid-cols-2 lg:grid-cols-4"
    }`}>
      {cards.map((card, i) => {
        const Icon = card.icon;
        return (
          <div
            key={i}
            className={`h-[74px] p-3 rounded-[12px] border transition-all duration-300 relative overflow-hidden group shadow-sm hover:shadow-md hover:-translate-y-[1px] ${
              isDarkMode
                ? "bg-[#0B0D12]/90 border-[#1E293B]/60 hover:border-cyan-500/30"
                : "bg-white border-blue-100 hover:border-blue-300 text-slate-800"
            }`}
          >
            {/* Soft background pattern grid lines */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b04_1px,transparent_1px),linear-gradient(to_bottom,#1e293b04_1px,transparent_1px)] bg-[size:10px_10px] pointer-events-none"></div>
            
            {/* Ambient hover glow spot */}
            <div
              className={`absolute -right-8 -bottom-8 w-14 h-14 rounded-full bg-gradient-to-tr ${
                isDarkMode ? "from-cyan-500/10 to-blue-500/10" : "from-blue-100 to-cyan-50"
              } opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none blur-xl`}
            ></div>

            <div className="flex justify-between items-center h-full relative z-10 min-w-0 w-full">
              <div className="flex flex-col justify-center min-w-0 flex-1 pr-1">
                <span
                  className={`text-[10px] font-mono tracking-wider uppercase font-bold leading-none mb-1 ${
                    isDarkMode ? "text-cyan-400/80" : "text-blue-600/80"
                  }`}
                >
                  {card.label}
                </span>
                
                <div className="flex items-baseline gap-1 min-w-0">
                  {isDarkMode ? (
                    <strong className={`tracking-tight leading-none bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-100 to-cyan-200 truncate ${
                      typeof card.value === "string" && card.value.length > 7 && !card.value.endsWith("%")
                        ? "text-[14px] font-bold"
                        : "text-[20px] font-black"
                    }`} title={String(card.value)}>
                      {card.value}
                    </strong>
                  ) : (
                    <strong className={`tracking-tight leading-none text-slate-900 truncate ${
                      typeof card.value === "string" && card.value.length > 7 && !card.value.endsWith("%")
                        ? "text-[14px] font-bold"
                        : "text-[20px] font-extrabold"
                    }`} title={String(card.value)}>
                      {card.value}
                    </strong>
                  )}
                </div>

                <span className="text-[9px] text-slate-400 font-medium tracking-wide leading-none mt-1 truncate" title={card.desc}>
                  {card.desc}
                </span>
              </div>

              {/* Enhanced Holographic/Glow Icon Container (exactly 28px) */}
              <div
                className={`w-7 h-7 rounded-lg border flex items-center justify-center transition-all duration-300 ${card.glowColor} ${
                  isDarkMode
                    ? `bg-cyan-500/10 border-cyan-500/20 ${card.textColor}`
                    : `bg-blue-50 border-blue-200 text-blue-600`
                } group-hover:scale-105 group-hover:border-cyan-400/30`}
              >
                <Icon className="h-3.5 w-3.5" />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
