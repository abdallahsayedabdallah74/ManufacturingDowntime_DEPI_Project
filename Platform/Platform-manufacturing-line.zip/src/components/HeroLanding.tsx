import React from "react";
import { motion } from "motion/react";
import { Factory, ChevronRight, Activity, Cpu, ShieldCheck } from "lucide-react";

interface HeroLandingProps {
  onEnter: () => void;
  isDarkMode: boolean;
  totalBatches: number;
  oee: number;
}

export default function HeroLanding({ onEnter, isDarkMode, totalBatches, oee }: HeroLandingProps) {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center px-4 md:px-8 text-center overflow-hidden bg-[#0A0B0E]">
      
      {/* Background Image of the machine with sleek cybernetic overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/dark_factory_conveyor_1783059222941.jpg"
          alt="Futuristic automated factory production line"
          className="w-full h-full object-cover opacity-35 scale-105 filter brightness-[0.4] transition-all duration-1000"
          referrerPolicy="no-referrer"
        />

        {/* Backdrop glassmorphism filter layer */}
        <div className="absolute inset-0 backdrop-blur-[2px] z-10 pointer-events-none"></div>

        {/* High-tech pixel/tactical grid overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(6,182,212,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(6,182,212,0.02)_1px,transparent_1px)] bg-[size:32px_32px] z-10 pointer-events-none"></div>

        {/* Sophisticated dual gradients & radial vignette masking */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(10,11,14,0.1)_10%,#0A0B0E_90%)] z-10 pointer-events-none"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0B0E] via-[#0A0B0E]/80 to-[#0A0B0E]/40 z-10 pointer-events-none"></div>
      </div>

      {/* Hero Content */}
      <div className="relative z-20 max-w-4xl mx-auto flex flex-col items-center">
        
        {/* Subtle upper pill tag */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-5 flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 backdrop-blur-md"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
          <span>SYSTEM ONLINE • ACTIVE NODE 4.2</span>
        </motion.div>

        {/* Display Typography Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="text-4xl sm:text-6xl font-black tracking-tight text-white mb-4 uppercase"
        >
          Manufacturing<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 font-light lowercase">Line</span>
        </motion.h1>

        {/* Crisp, shorter subtitle description matching the site's sleek style */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2, delay: 0.3 }}
          className="text-gray-400 text-sm sm:text-base max-w-xl mb-8 leading-relaxed font-sans"
        >
          Real-time manufacturing execution, batch logging, and AI-powered performance diagnostics.
        </motion.p>

        {/* Interactive CTA buttons */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="flex flex-col sm:flex-row gap-4 mb-12 justify-center w-full sm:w-auto"
        >
          <button
            onClick={onEnter}
            className="group relative px-8 py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 transition-all duration-300 shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
          >
            <span>Enter Operator Workspace</span>
            <ChevronRight className="h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>

        {/* Live Factory Telemetry Stat Cards styled EXACTLY like the rest of the dark site */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-3xl"
        >
          <div className="bg-[#0F1115]/80 border border-[#22242D] p-5 rounded-2xl backdrop-blur-md text-left flex items-start gap-3.5 shadow-xl">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Activity className="h-4.5 w-4.5" />
            </div>
            <div>
              <span className="text-gray-500 text-[10px] block font-mono font-bold uppercase tracking-wider">OEE Target</span>
              <strong className="text-2xl font-black text-white">{oee}%</strong>
              <span className="text-[9px] text-emerald-400 block mt-0.5 font-medium">Optimal Parameter Zone</span>
            </div>
          </div>

          <div className="bg-[#0F1115]/80 border border-[#22242D] p-5 rounded-2xl backdrop-blur-md text-left flex items-start gap-3.5 shadow-xl">
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <Cpu className="h-4.5 w-4.5" />
            </div>
            <div>
              <span className="text-gray-500 text-[10px] block font-mono font-bold uppercase tracking-wider">Batches</span>
              <strong className="text-2xl font-black text-white">{totalBatches}</strong>
              <span className="text-[9px] text-gray-400 block mt-0.5 font-medium">Telemetry Logs Loaded</span>
            </div>
          </div>

          <div className="bg-[#0F1115]/80 border border-[#22242D] p-5 rounded-2xl backdrop-blur-md text-left flex items-start gap-3.5 shadow-xl">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="h-4.5 w-4.5" />
            </div>
            <div>
              <span className="text-gray-500 text-[10px] block font-mono font-bold uppercase tracking-wider">Status</span>
              <strong className="text-2xl font-black text-emerald-400">ONLINE</strong>
              <span className="text-[9px] text-emerald-400 block mt-0.5 font-medium">Systems Synchronized</span>
            </div>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
