import React, { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Clock, HelpCircle, Save, Calendar, AlertTriangle, UserCheck, Plus, Check, ChevronLeft, ChevronRight, ChevronDown, Trash2 } from "lucide-react";
import { Product, Factor, ProductionLog } from "../types";
import { calculateDurationMinutes } from "../supabaseClient";

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const getDeviceLocalDate = () => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const formatYYYYMMDD = (year: number, month: number, day: number) => {
  const mStr = String(month + 1).padStart(2, "0");
  const dStr = String(day).padStart(2, "0");
  return `${year}-${mStr}-${dStr}`;
};

const formatDisplayDate = (dateStr: string) => {
  if (!dateStr) return "";
  const parts = dateStr.split("-");
  if (parts.length !== 3) return dateStr;
  const [year, month, day] = parts;
  const monthNames = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];
  const mIndex = parseInt(month, 10) - 1;
  if (mIndex >= 0 && mIndex < 12) {
    return `${monthNames[mIndex]} ${parseInt(day, 10)}, ${year}`;
  }
  return dateStr;
};

const HOURS_LIST = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, "0"));
const HOURS_12_LIST = Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, "0"));
const MINUTES_LIST = Array.from({ length: 60 }, (_, i) => String(i).padStart(2, "0"));
const PERIODS_LIST = ["AM", "PM"];

const formatTimeTo12Hour = (timeStr: string) => {
  if (!timeStr) return "--:-- --";
  const parts = timeStr.split(":");
  if (parts.length !== 2) return timeStr;
  let hour = parseInt(parts[0], 10);
  const min = parts[1];
  if (isNaN(hour)) return "--:-- --";
  const ampm = hour >= 12 ? "PM" : "AM";
  hour = hour % 12;
  hour = hour ? hour : 12; // hour '0' should be '12'
  return `${String(hour).padStart(2, "0")}:${min} ${ampm}`;
};

const parseTimeTo12HourParts = (timeStr: string, defaultHour = "12", defaultMin = "00") => {
  if (!timeStr) return { hour12: defaultHour, minute: defaultMin, period: "AM" as "AM" | "PM" };
  const parts = timeStr.split(":");
  let hour = parseInt(parts[0], 10);
  const min = parts[1] || defaultMin;
  if (isNaN(hour)) return { hour12: defaultHour, minute: min, period: "AM" as "AM" | "PM" };
  const period = hour >= 12 ? "PM" : "AM";
  hour = hour % 12;
  hour = hour ? hour : 12;
  return {
    hour12: String(hour).padStart(2, "0"),
    minute: min,
    period: period as "AM" | "PM"
  };
};

const make24HourTime = (hour12Str: string, minuteStr: string, period: "AM" | "PM") => {
  let hour = parseInt(hour12Str, 10);
  if (period === "PM" && hour < 12) {
    hour += 12;
  } else if (period === "AM" && hour === 12) {
    hour = 0;
  }
  const hStr = String(hour).padStart(2, "0");
  const mStr = String(minuteStr).padStart(2, "0");
  return `${hStr}:${mStr}`;
};

interface BatchFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (log: ProductionLog) => Promise<void>;
  editingLog: ProductionLog | null;
  products: Product[];
  factors: Factor[];
  isDarkMode: boolean;
  addToast: (msg: string, type: "success" | "warning" | "error" | "info") => void;
  nextBatchNumber: number;
}

export default function BatchFormModal({
  isOpen,
  onClose,
  onSave,
  editingLog,
  products,
  factors,
  isDarkMode,
  addToast,
  nextBatchNumber,
}: BatchFormModalProps) {
  // Form fields
  const [batchNo, setBatchNo] = useState<number>(nextBatchNumber);
  const [operator, setOperator] = useState("");
  const [customOperator, setCustomOperator] = useState("");
  const [showCustomOp, setShowCustomOp] = useState(false);
  const [productId, setProductId] = useState("");
  const [date, setDate] = useState(getDeviceLocalDate());
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");

  // Downtime overrides
  const [downtimeEntries, setDowntimeEntries] = useState<{ factor_id: number; downtime_min: number; operator_error?: boolean }[]>([]);

  // Loading / Submit states
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Auto-dismiss inline error after 3 seconds
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        setError(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  // Custom Date and Time Picker States
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showStartTimePicker, setShowStartTimePicker] = useState(false);
  const [showEndTimePicker, setShowEndTimePicker] = useState(false);
  const [openFactorDropdownIdx, setOpenFactorDropdownIdx] = useState<number | null>(null);

  const [viewDate, setViewDate] = useState(() => {
    const d = new Date();
    return { year: d.getFullYear(), month: d.getMonth() };
  });

  // Keep viewDate in sync with currently selected date when opened or changed
  useEffect(() => {
    if (date) {
      const parts = date.split("-").map(Number);
      if (parts.length === 3) {
        setViewDate({ year: parts[0], month: parts[1] - 1 });
      }
    }
  }, [date, showDatePicker]);

  const handlePrevMonth = () => {
    setViewDate((prev) => {
      if (prev.month === 0) {
        return { year: prev.year - 1, month: 11 };
      }
      return { ...prev, month: prev.month - 1 };
    });
  };

  const handleNextMonth = () => {
    setViewDate((prev) => {
      if (prev.month === 11) {
        return { year: prev.year + 1, month: 0 };
      }
      return { ...prev, month: prev.month + 1 };
    });
  };

  const handleSelectDay = (day: number) => {
    setDate(formatYYYYMMDD(viewDate.year, viewDate.month, day));
    setShowDatePicker(false);
  };

  const { hour12: startHour12, minute: startMin, period: startPeriod } = parseTimeTo12HourParts(startTime, "08", "00");
  const { hour12: endHour12, minute: endMin, period: endPeriod } = parseTimeTo12HourParts(endTime, "09", "40");

  const handleSelectStartHour12 = (h12: string) => {
    const new24h = make24HourTime(h12, startMin, startPeriod);
    setStartTime(new24h);
  };

  const handleSelectStartMin = (m: string) => {
    const new24h = make24HourTime(startHour12, m, startPeriod);
    setStartTime(new24h);
  };

  const handleSelectStartPeriod = (p: "AM" | "PM") => {
    const new24h = make24HourTime(startHour12, startMin, p);
    setStartTime(new24h);
  };

  const handleSelectEndHour12 = (h12: string) => {
    const new24h = make24HourTime(h12, endMin, endPeriod);
    setEndTime(new24h);
  };

  const handleSelectEndMin = (m: string) => {
    const new24h = make24HourTime(endHour12, m, endPeriod);
    setEndTime(new24h);
  };

  const handleSelectEndPeriod = (p: "AM" | "PM") => {
    const new24h = make24HourTime(endHour12, endMin, p);
    setEndTime(new24h);
  };

  // Generate days array for calendar grid
  const monthDays = useMemo(() => {
    const daysInMonth = new Date(viewDate.year, viewDate.month + 1, 0).getDate();
    const firstDayIndex = new Date(viewDate.year, viewDate.month, 1).getDay();
    const days: (number | null)[] = [];
    for (let i = 0; i < firstDayIndex; i++) {
      days.push(null);
    }
    for (let d = 1; d <= daysInMonth; d++) {
      days.push(d);
    }
    return days;
  }, [viewDate]);

  // Sync edits when editingLog changes
  useEffect(() => {
    if (editingLog) {
      setBatchNo(editingLog.batch);
      setOperator(editingLog.operator_name);
      setProductId(editingLog.product_id);
      setDate(editingLog.date);
      setStartTime(editingLog.start_time);
      setEndTime(editingLog.end_time);

      if (editingLog.downtime_entries && editingLog.downtime_entries.length > 0) {
        setDowntimeEntries(editingLog.downtime_entries.map(e => {
          const matched = factors.find(f => f.factor_id === e.factor_id);
          return {
            factor_id: e.factor_id,
            downtime_min: e.downtime_min,
            operator_error: e.operator_error !== undefined ? e.operator_error : (matched ? matched.operator_error : false)
          };
        }));
      } else if (editingLog.downtime_min && editingLog.factor_id) {
        const matched = factors.find(f => f.factor_id === editingLog.factor_id);
        setDowntimeEntries([{
          factor_id: editingLog.factor_id,
          downtime_min: editingLog.downtime_min,
          operator_error: matched ? matched.operator_error : false
        }]);
      } else {
        setDowntimeEntries([]);
      }
      setShowCustomOp(false);
      setError(null);
    } else {
      // Reset for Adding Mode
      setBatchNo(nextBatchNumber);
      setOperator("");
      setCustomOperator("");
      setShowCustomOp(false);
      setProductId("");
      setDate(getDeviceLocalDate());
      setStartTime("");
      setEndTime("");
      setDowntimeEntries([]);
      setError(null);
    }
  }, [editingLog, isOpen, nextBatchNumber]);

  // Selected product helper
  const selectedProduct = useMemo(() => {
    return products.find((p) => p.product_id === productId) || null;
  }, [products, productId]);

  // Calculate duration instantly
  const calculatedDuration = useMemo(() => {
    return calculateDurationMinutes(startTime, endTime);
  }, [startTime, endTime]);

  // Is downtime required?
  const isDowntimeDelay = useMemo(() => {
    if (!selectedProduct) return false;
    return calculatedDuration > selectedProduct.min_batch_time;
  }, [calculatedDuration, selectedProduct]);

  // Suggested downtime
  const suggestedDowntime = useMemo(() => {
    if (!selectedProduct || !isDowntimeDelay) return 0;
    return calculatedDuration - selectedProduct.min_batch_time;
  }, [isDowntimeDelay, calculatedDuration, selectedProduct]);

  // Auto-set suggested downtime and keep in sync
  useEffect(() => {
    if (isDowntimeDelay) {
      setDowntimeEntries(prev => {
        if (prev.length === 0) {
          const matched = factors.find(f => f.factor_id === 12) || factors[0];
          return [{
            factor_id: 12,
            downtime_min: suggestedDowntime,
            operator_error: matched ? matched.operator_error : false
          }];
        } else if (prev.length === 1) {
          if (prev[0].downtime_min !== suggestedDowntime) {
            return [{
              ...prev[0],
              downtime_min: suggestedDowntime
            }];
          }
          return prev;
        } else {
          const currentSum = prev.reduce((sum, e) => sum + e.downtime_min, 0);
          if (currentSum !== suggestedDowntime) {
            const diff = suggestedDowntime - currentSum;
            const newFirstMin = Math.max(0, prev[0].downtime_min + diff);
            return prev.map((e, idx) => {
              if (idx === 0) {
                return { ...e, downtime_min: newFirstMin };
              }
              return e;
            });
          }
          return prev;
        }
      });
    } else {
      setDowntimeEntries(prev => prev.length > 0 ? [] : prev);
    }
  }, [isDowntimeDelay, suggestedDowntime]);

  // Calculated shift automatically
  const calculatedShift = useMemo(() => {
    if (!startTime) return "Morning";
    const [hour] = startTime.split(":").map(Number);
    if (hour >= 6 && hour < 14) return "Morning";
    if (hour >= 14 && hour < 22) return "Afternoon";
    return "Night";
  }, [startTime]);

  const handleAddDowntimeEntry = () => {
    const matched = factors.find(f => f.factor_id === 12) || factors[0];
    setDowntimeEntries([...downtimeEntries, { 
      factor_id: 12, 
      downtime_min: 0,
      operator_error: matched ? matched.operator_error : false
    }]);
  };

  const handleUpdateEntryFactor = (index: number, factor_id: number) => {
    const matched = factors.find(f => f.factor_id === factor_id);
    setDowntimeEntries(
      downtimeEntries.map((e, idx) => (idx === index ? { 
        ...e, 
        factor_id,
        operator_error: matched ? matched.operator_error : false
      } : e))
    );
  };

  const handleToggleEntryOperatorError = (index: number) => {
    setDowntimeEntries(
      downtimeEntries.map((e, idx) => (idx === index ? { 
        ...e, 
        operator_error: !e.operator_error 
      } : e))
    );
  };

  const handleUpdateEntryMinutes = (index: number, downtime_min: number) => {
    setDowntimeEntries(
      downtimeEntries.map((e, idx) => (idx === index ? { ...e, downtime_min } : e))
    );
  };

  const handleRemoveDowntimeEntry = (index: number) => {
    setDowntimeEntries(downtimeEntries.filter((_, idx) => idx !== index));
  };

  const handleAutoAllocateDowntime = () => {
    const matched = factors.find(f => f.factor_id === 12) || factors[0];
    if (downtimeEntries.length === 0) {
      setDowntimeEntries([{ 
        factor_id: 12, 
        downtime_min: suggestedDowntime,
        operator_error: matched ? matched.operator_error : false
      }]);
    } else {
      setDowntimeEntries(
        downtimeEntries.map((e, idx) => {
          if (idx === 0) {
            return { ...e, downtime_min: suggestedDowntime };
          }
          return { ...e, downtime_min: 0 };
        })
      );
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const activeOperator = showCustomOp ? customOperator.trim() : operator;
    if (!activeOperator) {
      setError("Please designate or enter a qualified line operator.");
      return;
    }

    if (!date) {
      setError("Please select a valid production date.");
      return;
    }

    if (!productId || !selectedProduct) {
      setError("Please select a valid product / flavor profile.");
      return;
    }

    if (!startTime || !endTime) {
      setError("Please enter valid cycle start & completion times.");
      return;
    }

    if (calculatedDuration <= 0) {
      setError("Duration must be positive. Verify shift start & end hours.");
      return;
    }

    let finalDowntimeEntries: { factor_id: number; downtime_min: number; downtime_reason?: string; operator_error?: boolean }[] = [];
    let totalDowntimeVal = 0;

    if (isDowntimeDelay) {
      if (downtimeEntries.length === 0) {
        setError("At least one downtime stoppage reason is required for a downtime delay.");
        return;
      }

      for (let i = 0; i < downtimeEntries.length; i++) {
        const entry = downtimeEntries[i];
        if (isNaN(entry.downtime_min) || entry.downtime_min < 0) {
          setError(`Please specify non-negative minutes for downtime entry #${i + 1}.`);
          return;
        }
        totalDowntimeVal += entry.downtime_min;
        
        const matchedFactor = factors.find((f) => f.factor_id === Number(entry.factor_id));
        finalDowntimeEntries.push({
          factor_id: Number(entry.factor_id),
          downtime_min: Number(entry.downtime_min),
          downtime_reason: matchedFactor ? matchedFactor.description : "Other",
          operator_error: entry.operator_error !== undefined ? entry.operator_error : (matchedFactor ? matchedFactor.operator_error : false),
        });
      }
    }

    setIsSaving(true);

    try {
      const firstEntry = finalDowntimeEntries[0];
      
      const savedLog: ProductionLog = {
        id: editingLog ? editingLog.id : `B-${batchNo}`,
        batch: batchNo,
        date,
        product_id: productId,
        flavor: selectedProduct.flavor,
        size: selectedProduct.size,
        min_batch_time: selectedProduct.min_batch_time,
        operator_name: activeOperator,
        start_time: startTime,
        end_time: endTime,
        duration: calculatedDuration,
        shift: calculatedShift,
        status: isDowntimeDelay ? "Downtime Delay" : "Optimal",
        downtime_min: isDowntimeDelay ? totalDowntimeVal : undefined,
        factor_id: isDowntimeDelay && firstEntry ? firstEntry.factor_id : undefined,
        downtime_reason: isDowntimeDelay && firstEntry ? firstEntry.downtime_reason : undefined,
        downtime_entries: isDowntimeDelay ? finalDowntimeEntries : undefined,
      };

      await onSave(savedLog);
      
      addToast(
        editingLog 
          ? `Batch #${batchNo} updated successfully.` 
          : `Batch #${batchNo} logged successfully.`, 
        "success"
      );

      if (isDowntimeDelay) {
        addToast("Downtime calculated & categorized automatically.", "info");
      }

      onClose();
    } catch (err: any) {
      setError(err.message || "An error occurred while logging the batch.");
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop glassmorphism overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
        />

        {/* Modal content cardboard wrapper */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className={`relative w-full max-w-2xl rounded-3xl border shadow-2xl p-6 overflow-y-auto max-h-[90vh] ${
            isDarkMode ? "bg-[#0F1115] border-[#22242D] text-white" : "bg-white border-slate-200 text-slate-800"
          }`}
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-lg hover:bg-white/5 text-gray-400 hover:text-gray-200 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>

          {/* Title */}
          <div className="mb-6">
            <h2 className="text-xl font-bold tracking-tight">
              {editingLog ? `Modify Batch Run #${batchNo}` : "Log New Manufacturing Batch"}
            </h2>
            <p className="text-xs text-gray-400 mt-1 font-mono">
              {editingLog ? "RE-SUBMITTING HISTORICAL CYCLE DATA" : "OPERATOR WORKSTATION DATAENTRY UNIT"}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            {error && (
              <div 
                onClick={() => setError(null)}
                className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-between gap-2 cursor-pointer hover:bg-rose-500/15 transition-all select-none"
                title="Click to dismiss error"
              >
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4.5 w-4.5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setError(null);
                  }}
                  className="p-1 rounded-lg hover:bg-rose-500/15 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                  aria-label="Dismiss error"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            {/* Inputs Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Batch Number (pre-assigned) */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-mono tracking-widest text-gray-500 uppercase font-semibold">
                  Batch ID (Sequential)
                </label>
                <input
                  type="number"
                  value={batchNo}
                  onChange={(e) => setBatchNo(Number(e.target.value))}
                  disabled={!!editingLog}
                  className={`w-full px-4 py-3 rounded-xl text-sm font-medium border outline-none font-mono ${
                    editingLog
                      ? "bg-slate-900/60 border-slate-800 text-gray-500 cursor-not-allowed"
                      : isDarkMode
                      ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500"
                      : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
                  }`}
                />
              </div>

              {/* Date */}
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-mono tracking-widest text-gray-500 uppercase font-semibold">
                    Production Date
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setDate(getDeviceLocalDate());
                      addToast("Date updated to device's current date.", "info");
                    }}
                    className="text-[10px] text-cyan-400 hover:underline font-mono font-bold cursor-pointer flex items-center gap-1"
                    title="Change back to the current device date"
                  >
                    Set to Today
                  </button>
                </div>
                <div className="relative">
                  <div
                    onClick={() => setShowDatePicker(!showDatePicker)}
                    className={`w-full pl-4 pr-4 py-3 rounded-xl text-sm font-medium border outline-none cursor-pointer flex items-center justify-between select-none ${
                      isDarkMode
                        ? "bg-slate-950 border-slate-800 text-white focus-within:border-cyan-500"
                        : "bg-slate-50 border-slate-200 text-slate-900 focus-within:border-blue-500"
                    }`}
                  >
                    <span className="font-mono">{formatDisplayDate(date) || "Select Date"}</span>
                    <Calendar className="h-4.5 w-4.5 text-gray-500" />
                  </div>

                  <input
                    type="hidden"
                    name="date"
                    required
                    value={date}
                  />

                  {showDatePicker && (
                    <>
                      {/* Click outside backdrop */}
                      <div className="fixed inset-0 z-40" onClick={() => setShowDatePicker(false)} />
                      
                      {/* Popover */}
                      <div className={`absolute left-0 top-full mt-2 z-50 w-72 rounded-2xl border shadow-2xl p-4 flex flex-col gap-3 ${
                        isDarkMode ? "bg-[#141722] border-slate-800 text-white shadow-black/55" : "bg-white border-slate-200 text-slate-800 shadow-slate-300"
                      }`}>
                        {/* Header: Month and Year */}
                        <div className="flex justify-between items-center">
                          <button
                            type="button"
                            onClick={handlePrevMonth}
                            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                              isDarkMode ? "border-slate-800 hover:bg-slate-800/80 text-gray-300" : "border-slate-200 hover:bg-slate-100 text-gray-600"
                            }`}
                          >
                            <ChevronLeft className="h-4 w-4" />
                          </button>
                          <span className="text-sm font-semibold font-mono tracking-wide">
                            {MONTHS[viewDate.month]} {viewDate.year}
                          </span>
                          <button
                            type="button"
                            onClick={handleNextMonth}
                            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                              isDarkMode ? "border-slate-800 hover:bg-slate-800/80 text-gray-300" : "border-slate-200 hover:bg-slate-100 text-gray-600"
                            }`}
                          >
                            <ChevronRight className="h-4 w-4" />
                          </button>
                        </div>

                        {/* Days of week */}
                        <div className="grid grid-cols-7 text-center text-[10px] font-mono tracking-widest text-gray-500 uppercase font-semibold">
                          <span>Su</span>
                          <span>Mo</span>
                          <span>Tu</span>
                          <span>We</span>
                          <span>Th</span>
                          <span>Fr</span>
                          <span>Sa</span>
                        </div>

                        {/* Days Grid */}
                        <div className="grid grid-cols-7 gap-1">
                          {monthDays.map((day, idx) => {
                            if (day === null) {
                              return <div key={`empty-${idx}`} />;
                            }
                            const currentDayStr = formatYYYYMMDD(viewDate.year, viewDate.month, day);
                            const isSelected = date === currentDayStr;
                            const isToday = getDeviceLocalDate() === currentDayStr;

                            return (
                              <button
                                key={`day-${day}`}
                                type="button"
                                onClick={() => handleSelectDay(day)}
                                className={`h-8 w-8 text-xs font-mono font-medium rounded-lg transition-all cursor-pointer flex items-center justify-center ${
                                  isSelected
                                    ? isDarkMode
                                      ? "bg-cyan-500 text-slate-950 font-bold shadow-[0_0_12px_rgba(6,182,212,0.4)]"
                                      : "bg-blue-600 text-white font-bold"
                                    : isToday
                                    ? isDarkMode
                                      ? "border border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/10"
                                      : "border border-blue-600/40 text-blue-600 hover:bg-blue-50"
                                    : isDarkMode
                                    ? "hover:bg-slate-800 text-gray-300 hover:text-white"
                                    : "hover:bg-slate-100 text-slate-700 hover:text-slate-900"
                                }`}
                              >
                                {day}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Product ID (Flavor selection) */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-mono tracking-widest text-gray-500 uppercase font-semibold">
                  Product / Flavor Profile
                </label>
                <div className="relative">
                  <select
                    value={productId}
                    onChange={(e) => setProductId(e.target.value)}
                    required
                    className={`w-full pl-4 pr-10 py-3 rounded-xl text-sm font-medium border outline-none appearance-none transition-all cursor-pointer ${
                      isDarkMode ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500" : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
                    }`}
                  >
                    <option value="" disabled hidden>-- Select Product --</option>
                    {products.map((p) => (
                      <option key={p.product_id} value={p.product_id}>
                        {p.flavor} ({p.size}) &bull; Target {p.min_batch_time}m
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 h-4.5 w-4.5 text-gray-400 pointer-events-none" />
                </div>
              </div>

              {/* Operator */}
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-mono tracking-widest text-gray-500 uppercase font-semibold">
                    Qualified Operator
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowCustomOp(!showCustomOp)}
                    className="text-[10px] text-cyan-400 hover:underline font-mono font-bold cursor-pointer"
                  >
                    {showCustomOp ? "Select Predefined" : "+ Custom Operator"}
                  </button>
                </div>

                {showCustomOp ? (
                  <input
                    type="text"
                    required
                    placeholder="Enter operator name..."
                    value={customOperator}
                    onChange={(e) => setCustomOperator(e.target.value)}
                    className={`w-full px-4 py-3 rounded-xl text-sm font-medium border outline-none ${
                      isDarkMode
                        ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500"
                        : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
                    }`}
                  />
                ) : (
                  <div className="relative">
                    <select
                      value={operator}
                      onChange={(e) => setOperator(e.target.value)}
                      required
                      className={`w-full pl-4 pr-10 py-3 rounded-xl text-sm font-medium border outline-none appearance-none transition-all cursor-pointer ${
                        isDarkMode ? "bg-slate-950 border-slate-800 text-white focus:border-cyan-500" : "bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500"
                      }`}
                    >
                      <option value="" disabled hidden>-- Select Operator --</option>
                      <option value="Mac">Mac</option>
                      <option value="Charlie">Charlie</option>
                      <option value="Dee">Dee</option>
                      <option value="Dennis">Dennis</option>
                    </select>
                    <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 h-4.5 w-4.5 text-gray-400 pointer-events-none" />
                  </div>
                )}
              </div>

              {/* Start Time */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-mono tracking-widest text-gray-500 uppercase font-semibold">
                  Batch Cycle Start
                </label>
                <div className="relative">
                  <div
                    onClick={() => {
                      setShowStartTimePicker(!showStartTimePicker);
                      setShowDatePicker(false);
                      setShowEndTimePicker(false);
                    }}
                    className={`w-full pl-4 pr-4 py-3 rounded-xl text-sm font-medium border outline-none cursor-pointer flex items-center justify-between select-none ${
                      isDarkMode
                        ? "bg-slate-950 border-slate-800 text-white focus-within:border-cyan-500"
                        : "bg-slate-50 border-slate-200 text-slate-900 focus-within:border-blue-500"
                    }`}
                  >
                    <span className="font-mono">{startTime ? formatTimeTo12Hour(startTime) : "-- : --"}</span>
                    <Clock className="h-4.5 w-4.5 text-gray-500" />
                  </div>

                  <input
                    type="hidden"
                    name="startTime"
                    required
                    value={startTime}
                  />

                  {showStartTimePicker && (
                    <>
                      {/* Click outside backdrop */}
                      <div className="fixed inset-0 z-40" onClick={() => setShowStartTimePicker(false)} />
                      
                      {/* Popover opening upward */}
                      <div className={`absolute left-0 bottom-full mb-2 z-50 w-64 rounded-2xl border shadow-2xl p-4 flex flex-col gap-2.5 ${
                        isDarkMode ? "bg-[#0F1115] border-[#22242D] text-white shadow-black/80" : "bg-white border-slate-200 text-slate-800 shadow-slate-300/60"
                      }`}>
                        <div className="flex gap-3 h-44">
                          {/* Hour list */}
                          <div className="flex flex-col flex-1 min-w-0">
                            <span className="text-[9px] font-mono tracking-wider text-gray-500 uppercase font-bold text-center mb-1.5">Hour</span>
                            <div className="flex-1 overflow-y-auto flex flex-col gap-0.5 pr-1 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                              {HOURS_12_LIST.map((h) => {
                                const isSelected = startHour12 === h;
                                return (
                                  <button
                                    key={`sh-${h}`}
                                    type="button"
                                    onClick={() => handleSelectStartHour12(h)}
                                    className={`py-1 text-center font-mono text-xs rounded-lg transition-all cursor-pointer ${
                                      isSelected
                                        ? isDarkMode
                                          ? "bg-cyan-500 text-slate-950 font-bold shadow-[0_0_8px_rgba(6,182,212,0.4)]"
                                          : "bg-blue-600 text-white font-bold"
                                        : isDarkMode
                                        ? "hover:bg-slate-800 text-gray-300 hover:text-white"
                                        : "hover:bg-slate-100 text-slate-700 hover:text-slate-900"
                                    }`}
                                  >
                                    {h}
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* Divider */}
                          <div className="self-center font-mono text-gray-600 font-bold">:</div>

                          {/* Minute list */}
                          <div className="flex flex-col flex-1 min-w-0">
                            <span className="text-[9px] font-mono tracking-wider text-gray-500 uppercase font-bold text-center mb-1.5">Min</span>
                            <div className="flex-1 overflow-y-auto flex flex-col gap-0.5 pr-1 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                              {MINUTES_LIST.map((m) => {
                                const isSelected = startMin === m;
                                return (
                                  <button
                                    key={`sm-${m}`}
                                    type="button"
                                    onClick={() => handleSelectStartMin(m)}
                                    className={`py-1 text-center font-mono text-xs rounded-lg transition-all cursor-pointer ${
                                      isSelected
                                        ? isDarkMode
                                          ? "bg-cyan-500 text-slate-950 font-bold shadow-[0_0_8px_rgba(6,182,212,0.4)]"
                                          : "bg-blue-600 text-white font-bold"
                                        : isDarkMode
                                        ? "hover:bg-slate-800 text-gray-300 hover:text-white"
                                        : "hover:bg-slate-100 text-slate-700 hover:text-slate-900"
                                    }`}
                                  >
                                    {m}
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* Divider */}
                          <div className="self-center font-mono text-gray-600 font-bold"> </div>

                          {/* Period List */}
                          <div className="flex flex-col flex-1 min-w-0">
                            <span className="text-[9px] font-mono tracking-wider text-gray-500 uppercase font-bold text-center mb-1.5">AM/PM</span>
                            <div className="flex-1 flex flex-col gap-1 pr-1 justify-center">
                              {PERIODS_LIST.map((p) => {
                                const isSelected = startPeriod === p;
                                return (
                                  <button
                                    key={`sp-${p}`}
                                    type="button"
                                    onClick={() => handleSelectStartPeriod(p as "AM" | "PM")}
                                    className={`py-2 text-center font-mono text-xs rounded-lg transition-all cursor-pointer font-bold ${
                                      isSelected
                                        ? isDarkMode
                                          ? "bg-cyan-500 text-slate-950 font-bold shadow-[0_0_8px_rgba(6,182,212,0.4)]"
                                          : "bg-blue-600 text-white font-bold"
                                        : isDarkMode
                                        ? "hover:bg-slate-800 text-gray-300 hover:text-white"
                                        : "hover:bg-slate-100 text-slate-700 hover:text-slate-900"
                                    }`}
                                  >
                                    {p}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>

                        {/* Done/Confirm button */}
                        <button
                          type="button"
                          onClick={() => setShowStartTimePicker(false)}
                          className={`w-full mt-1.5 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer ${
                            isDarkMode
                              ? "bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold shadow-[0_0_12px_rgba(6,182,212,0.25)]"
                              : "bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-md shadow-blue-500/15"
                          }`}
                        >
                          Confirm
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* End Time */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-mono tracking-widest text-gray-500 uppercase font-semibold">
                  Batch Cycle Completion
                </label>
                <div className="relative">
                  <div
                    onClick={() => {
                      setShowEndTimePicker(!showEndTimePicker);
                      setShowDatePicker(false);
                      setShowStartTimePicker(false);
                    }}
                    className={`w-full pl-4 pr-4 py-3 rounded-xl text-sm font-medium border outline-none cursor-pointer flex items-center justify-between select-none ${
                      isDarkMode
                        ? "bg-slate-950 border-slate-800 text-white focus-within:border-cyan-500"
                        : "bg-slate-50 border-slate-200 text-slate-900 focus-within:border-blue-500"
                    }`}
                  >
                    <span className="font-mono">{endTime ? formatTimeTo12Hour(endTime) : "-- : --"}</span>
                    <Clock className="h-4.5 w-4.5 text-gray-500" />
                  </div>

                  <input
                    type="hidden"
                    name="endTime"
                    required
                    value={endTime}
                  />

                  {showEndTimePicker && (
                    <>
                      {/* Click outside backdrop */}
                      <div className="fixed inset-0 z-40" onClick={() => setShowEndTimePicker(false)} />
                      
                      {/* Popover opening upward, right-aligned to input */}
                      <div className={`absolute right-0 bottom-full mb-2 z-50 w-64 rounded-2xl border shadow-2xl p-4 flex flex-col gap-2.5 ${
                        isDarkMode ? "bg-[#0F1115] border-[#22242D] text-white shadow-black/80" : "bg-white border-slate-200 text-slate-800 shadow-slate-300/60"
                      }`}>
                        <div className="flex gap-3 h-44">
                          {/* Hour list */}
                          <div className="flex flex-col flex-1 min-w-0">
                            <span className="text-[9px] font-mono tracking-wider text-gray-500 uppercase font-bold text-center mb-1.5">Hour</span>
                            <div className="flex-1 overflow-y-auto flex flex-col gap-0.5 pr-1 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                              {HOURS_12_LIST.map((h) => {
                                const isSelected = endHour12 === h;
                                return (
                                  <button
                                    key={`eh-${h}`}
                                    type="button"
                                    onClick={() => handleSelectEndHour12(h)}
                                    className={`py-1 text-center font-mono text-xs rounded-lg transition-all cursor-pointer ${
                                      isSelected
                                        ? isDarkMode
                                          ? "bg-cyan-500 text-slate-950 font-bold shadow-[0_0_8px_rgba(6,182,212,0.4)]"
                                          : "bg-blue-600 text-white font-bold"
                                        : isDarkMode
                                        ? "hover:bg-slate-800 text-gray-300 hover:text-white"
                                        : "hover:bg-slate-100 text-slate-700 hover:text-slate-900"
                                    }`}
                                  >
                                    {h}
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* Divider */}
                          <div className="self-center font-mono text-gray-600 font-bold">:</div>

                          {/* Minute list */}
                          <div className="flex flex-col flex-1 min-w-0">
                            <span className="text-[9px] font-mono tracking-wider text-gray-500 uppercase font-bold text-center mb-1.5">Min</span>
                            <div className="flex-1 overflow-y-auto flex flex-col gap-0.5 pr-1 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                              {MINUTES_LIST.map((m) => {
                                const isSelected = endMin === m;
                                return (
                                  <button
                                    key={`em-${m}`}
                                    type="button"
                                    onClick={() => handleSelectEndMin(m)}
                                    className={`py-1 text-center font-mono text-xs rounded-lg transition-all cursor-pointer ${
                                      isSelected
                                        ? isDarkMode
                                          ? "bg-cyan-500 text-slate-950 font-bold shadow-[0_0_8px_rgba(6,182,212,0.4)]"
                                          : "bg-blue-600 text-white font-bold"
                                        : isDarkMode
                                        ? "hover:bg-slate-800 text-gray-300 hover:text-white"
                                        : "hover:bg-slate-100 text-slate-700 hover:text-slate-900"
                                    }`}
                                  >
                                    {m}
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* Divider */}
                          <div className="self-center font-mono text-gray-600 font-bold"> </div>

                          {/* Period List */}
                          <div className="flex flex-col flex-1 min-w-0">
                            <span className="text-[9px] font-mono tracking-wider text-gray-500 uppercase font-bold text-center mb-1.5">AM/PM</span>
                            <div className="flex-1 flex flex-col gap-1 pr-1 justify-center">
                              {PERIODS_LIST.map((p) => {
                                const isSelected = endPeriod === p;
                                return (
                                  <button
                                    key={`ep-${p}`}
                                    type="button"
                                    onClick={() => handleSelectEndPeriod(p as "AM" | "PM")}
                                    className={`py-2 text-center font-mono text-xs rounded-lg transition-all cursor-pointer font-bold ${
                                      isSelected
                                        ? isDarkMode
                                          ? "bg-cyan-500 text-slate-950 font-bold shadow-[0_0_8px_rgba(6,182,212,0.4)]"
                                          : "bg-blue-600 text-white font-bold"
                                        : isDarkMode
                                        ? "hover:bg-slate-800 text-gray-300 hover:text-white"
                                        : "hover:bg-slate-100 text-slate-700 hover:text-slate-900"
                                    }`}
                                  >
                                    {p}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>

                        {/* Done/Confirm button */}
                        <button
                          type="button"
                          onClick={() => setShowEndTimePicker(false)}
                          className={`w-full mt-1.5 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer ${
                            isDarkMode
                              ? "bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold shadow-[0_0_12px_rgba(6,182,212,0.25)]"
                              : "bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-md shadow-blue-500/15"
                          }`}
                        >
                          Confirm
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* AUTOMATIC CALCULATIONS PREVIEW AREA */}
            <div className={`p-4 rounded-2xl border ${
              isDarkMode ? "bg-slate-950/60 border-slate-800" : "bg-slate-50 border-slate-200"
            }`}>
              <span className="text-[10px] font-mono tracking-widest text-gray-500 uppercase font-semibold block mb-2.5">
                Real-Time Automation Telemetry
              </span>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-semibold">
                <div>
                  <span className="text-gray-400 block font-light">Calculated Duration</span>
                  <strong className="text-base text-cyan-400 font-mono">{calculatedDuration} mins</strong>
                </div>
                <div>
                  <span className="text-gray-400 block font-light">Product Target Standard</span>
                  <strong className="text-base text-gray-400 font-mono">
                    {selectedProduct ? `${selectedProduct.min_batch_time} mins` : "--"}
                  </strong>
                </div>
                <div>
                  <span className="text-gray-400 block font-light">Designated Shift</span>
                  <strong className="text-base text-indigo-400 font-mono">{calculatedShift}</strong>
                </div>
                <div>
                  <span className="text-gray-400 block font-light">Status Deviation</span>
                  <strong className={`text-base font-bold uppercase font-mono ${isDowntimeDelay ? "text-rose-400" : "text-emerald-400"}`}>
                    {isDowntimeDelay ? "Downtime Delay" : "Optimal"}
                  </strong>
                </div>
              </div>
            </div>

            {/* AUTOMATIC DOWNTIME SELECTOR (Renders conditionally if exceeds normal limit) */}
            <AnimatePresence>
              {isDowntimeDelay && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden flex flex-col gap-4"
                >
                  <div className={`p-5 rounded-3xl border shadow-lg ${
                    isDarkMode 
                      ? "bg-[#0B0D12] border-rose-500/15 text-gray-200" 
                      : "bg-[#FFFDFB] border-rose-500/20 text-slate-800"
                  }`}>
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="h-5 w-5 text-rose-400 mt-0.5 flex-shrink-0 animate-pulse" />
                      <div className="flex-1">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-rose-400">Downtime Delay Detected!</h4>
                        <p className="text-[11px] leading-relaxed text-gray-400 mt-1">
                          The actual batch duration of <strong>{calculatedDuration} minutes</strong> exceeds the allowed optimal target benchmark limit of <strong>{selectedProduct.min_batch_time} minutes</strong> by <strong>{suggestedDowntime} minutes</strong>. Please allocate the stoppage reasons below.
                        </p>
                      </div>
                    </div>

                    {/* Dynamic Downtime Entries List */}
                    <div className="flex flex-col gap-4 mt-4">
                      <div className="flex justify-between items-center pb-1.5 border-b border-rose-500/10">
                        <span className="text-[10px] font-mono tracking-widest text-rose-400 uppercase font-bold">
                          Stoppage Factors Allocation
                        </span>
                      </div>

                      {downtimeEntries.map((entry, index) => (
                        <div key={`entry-${index}`} className="flex flex-col sm:flex-row gap-4 items-end sm:items-start p-3.5 rounded-2xl bg-slate-900/40 dark:bg-slate-950/40 border border-slate-800/50">
                          {/* Stoppage Reason */}
                          <div className="flex-1 w-full flex flex-col gap-1.5">
                            <span className="text-[9px] font-mono text-gray-400 font-bold uppercase tracking-wide">Reason Factor #{index + 1}</span>
                            
                            <div className="relative">
                              <div
                                onClick={() => {
                                  setOpenFactorDropdownIdx(openFactorDropdownIdx === index ? null : index);
                                  setShowDatePicker(false);
                                  setShowStartTimePicker(false);
                                  setShowEndTimePicker(false);
                                }}
                                className={`w-full pl-3 pr-3 py-2.5 rounded-xl text-xs font-semibold border outline-none cursor-pointer flex items-center justify-between select-none transition-all ${
                                  isDarkMode
                                    ? "bg-slate-950 border-slate-800 text-white focus-within:border-rose-400 hover:border-rose-500/50"
                                    : "bg-white border-slate-200 text-slate-900 focus-within:border-rose-500 hover:border-rose-500/50"
                                }`}
                              >
                                <span>
                                  {factors.find((f) => f.factor_id === entry.factor_id)?.description || "Select Factor"}
                                </span>
                                <ChevronDown className="h-4 w-4 text-gray-400" />
                              </div>

                              {openFactorDropdownIdx === index && (
                                <>
                                  {/* Back drop to close */}
                                  <div className="fixed inset-0 z-40" onClick={() => setOpenFactorDropdownIdx(null)} />
                                  
                                  {/* Popover */}
                                  <div className={`absolute left-0 bottom-full mb-2 z-50 w-full max-h-56 overflow-y-auto rounded-2xl border shadow-2xl p-2.5 flex flex-col gap-1 ${
                                    isDarkMode ? "bg-[#0F1115] border-[#22242D] text-white shadow-black/80" : "bg-white border-slate-200 text-slate-800 shadow-slate-300/60"
                                  }`}>
                                    <div className="text-[9px] font-mono tracking-wider text-gray-500 uppercase font-bold px-2 pb-1.5 border-b border-rose-500/15 mb-1 flex items-center justify-between">
                                      <span>Select Stoppage Factor</span>
                                      <span className="text-rose-400">Fault List</span>
                                    </div>
                                    <div className="flex flex-col gap-0.5 max-h-40 overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                                      {factors.map((f) => {
                                        const isSelected = entry.factor_id === f.factor_id;
                                        return (
                                          <button
                                            key={`fopt-${f.factor_id}`}
                                            type="button"
                                            onClick={() => {
                                              handleUpdateEntryFactor(index, f.factor_id);
                                              setOpenFactorDropdownIdx(null);
                                            }}
                                            className={`w-full text-left px-3 py-2 rounded-xl text-[11px] font-medium font-sans transition-all cursor-pointer flex items-center justify-between ${
                                              isSelected
                                                ? isDarkMode
                                                  ? "bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30"
                                                  : "bg-rose-50 text-rose-900 font-bold border border-rose-200"
                                                : isDarkMode
                                                ? "hover:bg-slate-800 text-gray-300 hover:text-white"
                                                : "hover:bg-slate-100 text-slate-700 hover:text-slate-900"
                                            }`}
                                          >
                                            <span className="truncate">{f.description}</span>
                                            {f.operator_error ? (
                                              <span className="text-[8px] font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 px-1 py-0.2 rounded shrink-0">Operator</span>
                                            ) : (
                                              <span className="text-[8px] font-mono font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20 px-1 py-0.2 rounded shrink-0">System</span>
                                            )}
                                          </button>
                                        );
                                      })}
                                    </div>
                                  </div>
                                </>
                              )}
                            </div>

                            {/* Operator Malfunction Indicator & Toggle Switch */}
                            <div className="mt-1 flex items-center justify-between bg-slate-900/10 dark:bg-slate-950/20 p-2 rounded-xl border border-slate-800/10">
                              <div className="flex items-center gap-1.5">
                                <span className="text-[9px] font-mono text-gray-400">Type:</span>
                                {entry.operator_error ? (
                                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold font-mono bg-amber-500/10 text-amber-400 border border-amber-500/20">
                                    Operator
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold font-mono bg-blue-500/10 text-blue-400 border border-blue-500/20">
                                    System
                                  </span>
                                )}
                              </div>
                              <label className="flex items-center gap-1.5 cursor-pointer select-none">
                                <input
                                  type="checkbox"
                                  checked={!!entry.operator_error}
                                  onChange={() => handleToggleEntryOperatorError(index)}
                                  className="rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-0 h-3.5 w-3.5 cursor-pointer"
                                />
                                <span className="text-[9px] font-mono font-bold text-gray-400 hover:text-gray-200 transition-colors">
                                  Operator-caused?
                                </span>
                              </label>
                            </div>
                          </div>

                          {/* Minutes */}
                          <div className="w-full sm:w-28 flex flex-col gap-1.5 shrink-0">
                            <span className="text-[9px] font-mono text-gray-400 font-bold uppercase tracking-wide">Downtime (Mins)</span>
                            <input
                              type="number"
                              readOnly
                              disabled
                              required
                              min="0"
                              value={entry.downtime_min}
                              className={`w-full px-3 py-2.5 rounded-xl text-xs font-semibold font-mono border outline-none cursor-not-allowed opacity-60 ${
                                isDarkMode
                                  ? "bg-slate-950 border-slate-800 text-gray-400"
                                  : "bg-slate-100 border-slate-200 text-gray-500"
                              }`}
                            />
                          </div>

                          {/* Remove button */}
                          {downtimeEntries.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveDowntimeEntry(index)}
                              className="p-2.5 rounded-xl bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 hover:text-rose-300 transition-colors cursor-pointer self-end sm:self-start mt-[19px]"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      ))}

                      {/* Add Button & Telemetry Summary */}
                      <div className="flex flex-col gap-3 mt-2 pt-3 border-t border-rose-500/10">
                        <div className="flex flex-col sm:flex-row justify-end items-start sm:items-center gap-3">
                          <div className="text-[11px] font-mono text-gray-400 flex flex-col sm:items-end gap-1">
                            <div>
                              Total Logged:{" "}
                              <strong className="text-emerald-400 font-bold">
                                {downtimeEntries.reduce((s, e) => s + e.downtime_min, 0)} mins
                              </strong>{" "}
                              / Target: <strong className="text-rose-400 font-bold">{suggestedDowntime} mins</strong>
                            </div>
                          </div>
                        </div>

                        {/* Real-time Operator-caused downtime calculation breakdown */}
                        <div className="flex flex-wrap items-center gap-4 bg-slate-900/20 dark:bg-slate-950/20 px-3 py-2 rounded-xl border border-slate-800/30 text-[10px] font-mono text-gray-400">
                          <span className="font-bold text-[9px] uppercase tracking-wider text-rose-400/80">Real-time Calculation:</span>
                          <span className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                            Operator Downtime: <strong className="text-amber-400">{downtimeEntries.filter(e => e.operator_error).reduce((s, e) => s + e.downtime_min, 0)} mins</strong>
                          </span>
                          <span className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                            System Downtime: <strong className="text-blue-400">{downtimeEntries.filter(e => !e.operator_error).reduce((s, e) => s + e.downtime_min, 0)} mins</strong>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Modal Actions */}
            <div className="flex justify-end gap-3 border-t pt-5 border-gray-800/10 dark:border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className={`px-5 py-2.5 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                  isDarkMode ? "border-slate-800 hover:bg-white/5 text-gray-400" : "border-slate-200 hover:bg-slate-100 text-slate-700"
                }`}
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 transition-all shadow-md shadow-cyan-500/10 flex items-center gap-1.5 cursor-pointer"
              >
                {isSaving ? (
                  <>
                    <span className="w-3.5 h-3.5 rounded-full border-2 border-white/20 border-t-white animate-spin"></span>
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    <span>Save Batch Record</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
