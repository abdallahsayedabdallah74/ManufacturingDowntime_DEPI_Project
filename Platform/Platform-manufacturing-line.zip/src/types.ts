export interface Product {
  product_id: string;
  flavor: string;
  size: string;
  min_batch_time: number; // in minutes
}

export interface Factor {
  factor_id: number;
  description: string;
  operator_error: boolean;
}

export interface ProductionLog {
  id: string; // matches batch in SQL
  batch: number; // sequential ID
  date: string;
  product_id: string;
  flavor: string; // joined or cached
  size: string; // joined or cached
  min_batch_time: number; // joined or cached
  operator_name: string;
  start_time: string; // 'HH:MM'
  end_time: string; // 'HH:MM'
  duration: number; // calculated in minutes
  shift: string; // 'Day', 'Evening', 'Night'
  status: "Optimal" | "Downtime Delay";
  downtime_min?: number;
  factor_id?: number;
  downtime_reason?: string;
  ai_analysis?: string;
  downtime_entries?: {
    factor_id: number;
    downtime_min: number;
    downtime_reason?: string;
    operator_error?: boolean;
  }[];
}

export interface DowntimeDetail {
  downtime_id: number;
  batch: number;
  fact_id: number;
  downtime_min: number;
}
