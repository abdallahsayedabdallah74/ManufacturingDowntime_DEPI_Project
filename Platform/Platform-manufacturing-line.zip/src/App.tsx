import React, { useState, useEffect, useMemo } from "react";
import {
  Factory,
  Layers,
  TrendingUp,
  FileSpreadsheet,
  Settings as SettingsIcon,
  ChevronRight,
  Sparkles,
  AlertOctagon,
  RefreshCw,
  Cpu,
  CheckCircle2,
  Trash2,
  Edit,
  User,
  Plus,
  Play,
  Clock,
  Gauge,
  HelpCircle,
  Lightbulb,
  Award,
  Database
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Product, Factor, ProductionLog } from "./types";
import {
  fetchProducts,
  fetchFactors,
  saveProductionLog,
  deleteProductionLog,
  clearAllProductionData,
  fetchProductionLogs,
  calculateDurationMinutes,
  seedDatabaseWithDefaults
} from "./supabaseClient";
import { PRODUCTS, FACTORS, getFullProductionLogs } from "./initialData";
import HeroLanding from "./components/HeroLanding";
import TransitionOverlay from "./components/TransitionOverlay";
import Navigation from "./components/Navigation";
import KPIStats from "./components/KPIStats";
import LogsTable from "./components/LogsTable";
import ChartsSection from "./components/ChartsSection";
import BatchFormModal from "./components/BatchFormModal";
import ReportsPanel from "./components/ReportsPanel";
import ToastNotifications, { Toast } from "./components/ToastNotifications";

export default function App() {
  // Navigation & UI States
  const [showLanding, setShowLanding] = useState<boolean>(true);
  const [isEntering, setIsEntering] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [dashboardView, setDashboardView] = useState<"overview" | "analysis">("overview");
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);

  // Authenticated operator profile state (can toggle in settings)
  const [activeOperator, setActiveOperator] = useState<string>("Mac");

  // Database States
  const [products, setProducts] = useState<Product[]>(PRODUCTS);
  const [factors, setFactors] = useState<Factor[]>([]);
  const [logs, setLogs] = useState<ProductionLog[]>([]);
  const [isDbSynced, setIsDbSynced] = useState<boolean>(false);
  const [isLoadingLogs, setIsLoadingLogs] = useState<boolean>(true);

  // Forms and Modals State
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);
  const [editingLog, setEditingLog] = useState<ProductionLog | null>(null);
  const [isAnalysisModalOpen, setIsAnalysisModalOpen] = useState<boolean>(false);

  // Gemini API analysis state
  const [selectedLogForAnalysis, setSelectedLogForAnalysis] = useState<ProductionLog | null>(null);
  const [activeAnalysis, setActiveAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

  // Toast Notifications list
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Shared Filter States for Dashboard and Logs List
  const [search, setSearch] = useState("");
  const [selectedOperator, setSelectedOperator] = useState("All");
  const [selectedProduct, setSelectedProduct] = useState("All");
  const [selectedShift, setSelectedShift] = useState("All");
  const [selectedStatus, setSelectedStatus] = useState("All");
  const [selectedFactor, setSelectedFactor] = useState("All");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [selectedBatch, setSelectedBatch] = useState("All");

  // Compute Filtered Logs dynamically
  const filteredLogs = useMemo(() => {
    let result = [...logs];

    // 1. Search filter (by batch sequential ID, operator, product ID, or flavor)
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (l) =>
          l.batch.toString().includes(q) ||
          l.operator_name.toLowerCase().includes(q) ||
          l.product_id.toLowerCase().includes(q) ||
          (l.flavor && l.flavor.toLowerCase().includes(q))
      );
    }

    // 2. Operator Filter
    if (selectedOperator !== "All") {
      result = result.filter((l) => l.operator_name === selectedOperator);
    }

    // 3. Product Filter (by flavor)
    if (selectedProduct !== "All") {
      result = result.filter((l) => l.flavor === selectedProduct);
    }

    // 4. Shift Filter
    if (selectedShift !== "All") {
      result = result.filter((l) => l.shift === selectedShift);
    }

    // 5. Status Filter
    if (selectedStatus !== "All") {
      result = result.filter((l) => l.status === selectedStatus);
    }

    // 6. Downtime Factor Filter
    if (selectedFactor !== "All") {
      result = result.filter((l) => {
        if (l.downtime_entries && l.downtime_entries.length > 0) {
          return l.downtime_entries.some((entry) => {
            const f = factors.find((fac) => fac.factor_id === entry.factor_id);
            const reason = entry.downtime_reason || (f ? f.description : "Other");
            return reason === selectedFactor;
          });
        } else {
          const f = factors.find((fac) => fac.factor_id === l.factor_id);
          const reason = l.downtime_reason || (f ? f.description : "Other");
          return reason === selectedFactor;
        }
      });
    }

    // 7. Date Range Filter
    if (startDate) {
      result = result.filter((l) => l.date >= startDate);
    }
    if (endDate) {
      result = result.filter((l) => l.date <= endDate);
    }

    // 8. Batch Filter
    if (selectedBatch !== "All") {
      result = result.filter((l) => l.batch.toString() === selectedBatch);
    }

    return result;
  }, [logs, factors, search, selectedOperator, selectedProduct, selectedShift, selectedStatus, selectedFactor, startDate, endDate, selectedBatch]);

  // Add toast helper
  const addToast = (message: string, type: "success" | "warning" | "error" | "info" = "success") => {
    const id = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    // Auto-remove after 3 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Load initial DB logs
  useEffect(() => {
    async function loadData() {
      setIsLoadingLogs(true);
      
      let loadedProducts = await fetchProducts();
      const localProducts = localStorage.getItem("manufacturing_products_v1");
      if (localProducts) {
        try {
          loadedProducts = JSON.parse(localProducts);
        } catch (_) {}
      }

      const allowedIds = ["OR-600", "LE-600", "CO-600", "DC-600", "RB-600", "CO-2L"];
      loadedProducts = loadedProducts.filter((p) => allowedIds.includes(p.product_id.toUpperCase()));

      let loadedFactors = await fetchFactors();
      const localFactors = localStorage.getItem("manufacturing_factors_v1");
      if (localFactors) {
        try {
          loadedFactors = JSON.parse(localFactors);
        } catch (_) {}
      }

      setProducts(loadedProducts);
      setFactors(loadedFactors);

      const { logs: loadedLogs, isSynced } = await fetchProductionLogs(loadedProducts, loadedFactors);
      
      // Merge with localStorage to preserve offline-first customizations, local operator error overrides, and AI analyses
      let finalLogs = loadedLogs;
      const localLogsStr = localStorage.getItem("manufacturing_logs_v1");
      if (localLogsStr) {
        try {
          const localLogs: ProductionLog[] = JSON.parse(localLogsStr);
          const localLogsMap = new Map<number, ProductionLog>(localLogs.map((l) => [l.batch, l]));
          
          finalLogs = loadedLogs.map((l) => {
            const localLog = localLogsMap.get(l.batch);
            if (localLog) {
              const mergedEntries = l.downtime_entries?.map((entry) => {
                const localEntry = localLog.downtime_entries?.find((le) => le.factor_id === entry.factor_id);
                return {
                  ...entry,
                  operator_error: localEntry && localEntry.operator_error !== undefined
                    ? localEntry.operator_error
                    : entry.operator_error
                };
              }) || l.downtime_entries;

              return {
                ...l,
                ai_analysis: localLog.ai_analysis || l.ai_analysis,
                downtime_entries: mergedEntries
              };
            }
            return l;
          });

          // Keep any local logs that are not present in Supabase yet (unsynced additions)
          const dbBatches = new Set(loadedLogs.map((l) => l.batch));
          localLogs.forEach((localLog) => {
            if (!dbBatches.has(localLog.batch)) {
              finalLogs.push(localLog);
            }
          });

          finalLogs.sort((a, b) => b.batch - a.batch);
        } catch (e) {
          console.error("Failed to merge database logs with localStorage:", e);
        }
      }

      setLogs(finalLogs);
      localStorage.setItem("manufacturing_logs_v1", JSON.stringify(finalLogs));
      setIsDbSynced(isSynced);
      setIsLoadingLogs(false);

      addToast("Production logs loaded successfully.", "success");
    }
    loadData();
  }, []);

  // Sync isDarkMode to html tags
  useEffect(() => {
    const root = window.document.documentElement;
    if (isDarkMode) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [isDarkMode]);

  // Next sequential batch ID
  const nextBatchNumber = useMemo(() => {
    if (logs.length === 0) return 422149;
    return Math.max(...logs.map((l) => l.batch)) + 1;
  }, [logs]);

  // Overall statistics
  const oeeRate = useMemo(() => {
    if (logs.length === 0) return 0;
    const total = logs.length;
    const optimal = logs.filter((l) => l.status === "Optimal").length;
    return Math.round((optimal / total) * 100);
  }, [logs]);

  // Add or Edit batch save trigger
  const handleSaveBatch = async (savedLog: ProductionLog) => {
    let updatedLogs: ProductionLog[];
    
    if (editingLog) {
      // Editing Mode
      updatedLogs = logs.map((l) => (l.id === savedLog.id ? savedLog : l));
      addToast(`Batch #${savedLog.batch} updated successfully.`, "success");
    } else {
      // Adding Mode
      updatedLogs = [savedLog, ...logs];
      addToast(`Batch #${savedLog.batch} added successfully.`, "success");
    }

    setLogs(updatedLogs);
    localStorage.setItem("manufacturing_logs_v1", JSON.stringify(updatedLogs));

    // Try sync to Supabase asynchronously
    const res = await saveProductionLog(savedLog);
    if (res.success) {
      setIsDbSynced(true);
    } else {
      setIsDbSynced(false);
    }

    // Automatically prompt Gemini analysis on saving single batch
    triggerBatchAnalysis(savedLog);
  };

  // Trigger Gemini API individual batch telemetry evaluation
  const triggerBatchAnalysis = async (batchLog: ProductionLog) => {
    setIsAnalyzing(true);
    setSelectedLogForAnalysis(batchLog);
    setActiveAnalysis(null);
    setIsAnalysisModalOpen(true);

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ batchData: batchLog, isGlobal: false }),
      });
      const data = await response.json();
      if (data.success) {
        setActiveAnalysis(data.analysis);
        addToast("Analysis generated successfully.", "success");
        
        // Save analysis to log state using a functional state update to prevent deleting newly created batches due to stale state closure
        setLogs((prevLogs) => {
          const updated = prevLogs.map((l) => (l.id === batchLog.id ? { ...l, ai_analysis: data.analysis } : l));
          localStorage.setItem("manufacturing_logs_v1", JSON.stringify(updated));
          return updated;
        });

        // Also update selectedLogForAnalysis in real-time so the analytics panel reflects the loaded analysis
        setSelectedLogForAnalysis((prev) => prev && prev.id === batchLog.id ? { ...prev, ai_analysis: data.analysis } : prev);
      } else {
        addToast("Failed to compile analysis.", "warning");
      }
    } catch (err) {
      console.warn("API Analysis failed or disconnected:", err);
      addToast("Failed to compile analysis.", "warning");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Delete production log
  const handleDeleteLog = async (id: string) => {
    const target = logs.find((l) => l.id === id);
    const filtered = logs.filter((l) => l.id !== id);
    setLogs(filtered);
    localStorage.setItem("manufacturing_logs_v1", JSON.stringify(filtered));
    addToast(`Batch #${target ? target.batch : id} deleted successfully.`, "error");

    if (selectedLogForAnalysis?.id === id) {
      setSelectedLogForAnalysis(null);
      setActiveAnalysis(null);
    }

    if (target) {
      const res = await deleteProductionLog(target.batch);
      if (res.success) {
        setIsDbSynced(true);
      } else {
        setIsDbSynced(false);
      }
    }
  };

  // Import production logs from CSV
  const handleImportLogs = async (importedLogs: ProductionLog[]) => {
    if (importedLogs.length === 0) return;

    setLogs((prevLogs) => {
      const existingLogsMap = new Map<number, ProductionLog>(prevLogs.map((l) => [l.batch, l]));
      let overwriteCount = 0;
      let newCount = 0;

      importedLogs.forEach((newLog) => {
        if (existingLogsMap.has(newLog.batch)) {
          overwriteCount++;
        } else {
          newCount++;
        }
        existingLogsMap.set(newLog.batch, newLog);
      });

      const mergedLogs = Array.from(existingLogsMap.values()).sort((a, b) => b.batch - a.batch);
      localStorage.setItem("manufacturing_logs_v1", JSON.stringify(mergedLogs));
      
      addToast(
        `Import summary: ${newCount} new batches added, ${overwriteCount} existing batches updated.`,
        "success"
      );
      
      return mergedLogs;
    });

    // Try to sync to Supabase in background
    let syncError = false;
    for (const log of importedLogs) {
      try {
        const res = await saveProductionLog(log);
        if (!res.success) {
          syncError = true;
        }
      } catch (err) {
        syncError = true;
      }
    }

    if (syncError) {
      setIsDbSynced(false);
      addToast("Some logs failed to sync to the Cloud database (saved locally).", "warning");
    } else {
      setIsDbSynced(true);
      addToast("All imported logs synced to Supabase successfully.", "success");
    }
  };

  // Import products from CSV
  const handleImportProducts = (importedProducts: Product[]) => {
    if (importedProducts.length === 0) return;

    const allowedIds = ["OR-600", "LE-600", "CO-600", "DC-600", "RB-600", "CO-2L"];
    const filteredImports = importedProducts.filter((p) => allowedIds.includes(p.product_id.toUpperCase()));

    if (filteredImports.length === 0) {
      addToast("None of the imported flavors/products are in the allowed product list.", "warning");
      return;
    }

    setProducts((prev) => {
      const existingProductsMap = new Map<string, Product>(prev.map((p) => [p.product_id.toLowerCase(), p]));
      let overwriteCount = 0;
      let newCount = 0;

      filteredImports.forEach((p) => {
        const key = p.product_id.toLowerCase();
        if (existingProductsMap.has(key)) {
          overwriteCount++;
        } else {
          newCount++;
        }
        existingProductsMap.set(key, p);
      });

      const merged = Array.from(existingProductsMap.values()).filter((p) => allowedIds.includes(p.product_id.toUpperCase()));
      localStorage.setItem("manufacturing_products_v1", JSON.stringify(merged));
      
      addToast(
        `Flavor import summary: ${newCount} new flavors added, ${overwriteCount} existing flavors updated.`,
        "success"
      );
      
      return merged;
    });
  };

  // Import factors from CSV
  const handleImportFactors = (importedFactors: Factor[]) => {
    if (importedFactors.length === 0) return;

    setFactors((prev) => {
      const existingFactorsMap = new Map<number, Factor>(prev.map((f) => [f.factor_id, f]));
      let overwriteCount = 0;
      let newCount = 0;

      importedFactors.forEach((f) => {
        if (existingFactorsMap.has(f.factor_id)) {
          overwriteCount++;
        } else {
          newCount++;
        }
        existingFactorsMap.set(f.factor_id, f);
      });

      const merged = Array.from(existingFactorsMap.values());
      localStorage.setItem("manufacturing_factors_v1", JSON.stringify(merged));
      
      addToast(
        `Factor import summary: ${newCount} new stoppage reasons added, ${overwriteCount} existing reasons updated.`,
        "success"
      );
      
      return merged;
    });
  };

  // Import downtime details from CSV
  const handleImportDowntimes = async (importedDowntimes: { batch: number; factor_id: number; downtime_min: number }[]) => {
    if (importedDowntimes.length === 0) return;

    setLogs((prevLogs) => {
      const logsMap = new Map<number, ProductionLog>(prevLogs.map((l) => [l.batch, l]));
      let matchCount = 0;

      importedDowntimes.forEach((dt) => {
        const log = logsMap.get(dt.batch);
        if (log) {
          matchCount++;
          const currentEntries = log.downtime_entries ? [...log.downtime_entries] : [];
          
          // Overwrite or add
          const existingIdx = currentEntries.findIndex((e) => e.factor_id === dt.factor_id);
          const matchedFactor = factors.find((f) => f.factor_id === dt.factor_id);
          const reasonText = matchedFactor ? matchedFactor.description : "Other";

          const newEntry = {
            factor_id: dt.factor_id,
            downtime_min: dt.downtime_min,
            downtime_reason: reasonText
          };

          if (existingIdx >= 0) {
            currentEntries[existingIdx] = newEntry;
          } else {
            currentEntries.push(newEntry);
          }

          const totalDowntimeMin = currentEntries.reduce((sum, e) => sum + e.downtime_min, 0);
          const status = totalDowntimeMin > 0 ? "Downtime Delay" : "Optimal";
          const firstEntry = currentEntries[0];

          logsMap.set(dt.batch, {
            ...log,
            status,
            downtime_min: totalDowntimeMin > 0 ? totalDowntimeMin : undefined,
            factor_id: firstEntry ? firstEntry.factor_id : undefined,
            downtime_reason: firstEntry ? firstEntry.downtime_reason : undefined,
            downtime_entries: currentEntries,
          });
        }
      });

      const updatedLogs = Array.from(logsMap.values()).sort((a, b) => b.batch - a.batch);
      localStorage.setItem("manufacturing_logs_v1", JSON.stringify(updatedLogs));

      addToast(
        `Downtime details import summary: Successfully matched and updated ${matchCount} records.`,
        "success"
      );

      // Save matched updated logs to Supabase
      const matchedLogsToSync = updatedLogs.filter((l) => 
        importedDowntimes.some((dt) => dt.batch === l.batch)
      );
      if (matchedLogsToSync.length > 0) {
        Promise.all(matchedLogsToSync.map(saveProductionLog))
          .then((results) => {
            const hasErr = results.some((r) => !r.success);
            if (hasErr) {
              setIsDbSynced(false);
              addToast("Some database updates failed to sync.", "warning");
            } else {
              setIsDbSynced(true);
              addToast("All database records synchronized successfully.", "success");
            }
          })
          .catch(() => {
            setIsDbSynced(false);
          });
      }

      return updatedLogs;
    });
  };

  // Restore all factory sample data (re-seeds localStorage & Supabase)
  const handleRestoreDefaults = async () => {
    try {
      addToast("Restoring default dataset and seeding database...", "info");
      
      // Clear localStorage so we don't have stale cache
      localStorage.removeItem("manufacturing_factors_v1");
      localStorage.removeItem("manufacturing_products_v1");
      localStorage.removeItem("manufacturing_logs_v1");

      const defaultFactors = FACTORS;
      const defaultProducts = PRODUCTS;
      const defaultLogs = getFullProductionLogs();

      // Sync state instantly
      setFactors(defaultFactors);
      setProducts(defaultProducts);
      setLogs(defaultLogs);

      // Save to localStorage
      localStorage.setItem("manufacturing_factors_v1", JSON.stringify(defaultFactors));
      localStorage.setItem("manufacturing_products_v1", JSON.stringify(defaultProducts));
      localStorage.setItem("manufacturing_logs_v1", JSON.stringify(defaultLogs));

      // Attempt Supabase database seeding
      const { success, error } = await seedDatabaseWithDefaults(defaultProducts, defaultFactors, defaultLogs);
      if (success) {
        setIsDbSynced(true);
        addToast("Pristine 12-factor sample dataset successfully restored & synchronized with cloud database.", "success");
      } else {
        setIsDbSynced(false);
        addToast("Data reset locally, but database synchronization failed.", "warning");
      }
    } catch (err: any) {
      console.error("Manual restore failed:", err);
      addToast(`Restore failed: ${err.message}`, "error");
    }
  };

  // Erase all production log data
  const handleClearAllData = async () => {
    try {
      addToast("Clearing all log entries...", "info");
      
      // Update states and storage
      setLogs([]);
      localStorage.setItem("manufacturing_logs_v1", JSON.stringify([]));
      
      const { success, error } = await clearAllProductionData();
      if (success) {
        setIsDbSynced(true);
        addToast("All database logs and stoppage details have been wiped.", "success");
      } else {
        setIsDbSynced(false);
        addToast("Local data cleared, but database failed to update.", "warning");
      }
    } catch (err: any) {
      console.error("Clear all data failed:", err);
      addToast(`Clear failed: ${err.message}`, "error");
    }
  };

  // Pre-fill log state for editing
  const handleEditTrigger = (log: ProductionLog) => {
    setEditingLog(log);
    setIsFormOpen(true);
  };

  // Trigger empty add form modal
  const handleAddTrigger = () => {
    setEditingLog(null);
    setIsFormOpen(true);
  };

  // Show welcome page or full platform dashboard
  if (showLanding) {
    return (
      <div className={isDarkMode ? "dark" : ""}>
        {isEntering ? (
          <TransitionOverlay
            onComplete={() => {
              setShowLanding(false);
              setIsEntering(false);
            }}
            isDarkMode={isDarkMode}
          />
        ) : (
          <HeroLanding
            onEnter={() => setIsEntering(true)}
            isDarkMode={isDarkMode}
            totalBatches={logs.length}
            oee={oeeRate}
          />
        )}
      </div>
    );
  }

  const operatorInitials = activeOperator
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <div className={`min-h-screen font-sans flex flex-col md:pl-[120px] transition-all duration-300 relative ${
      isDarkMode ? "bg-[#0A0B0E] text-[#E4E6EB]" : "bg-slate-50 text-slate-900"
    }`}>
      {/* Toast alert system floating */}
      <ToastNotifications toasts={toasts} removeToast={removeToast} />

      {/* TOP/SIDE NAVIGATION BAR */}
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        isDbSynced={isDbSynced}
        operator={activeOperator}
      />

      {/* FRAME LAYOUT DESIGN */}
      <div className="flex flex-1 overflow-hidden relative">
        
        {/* MAIN OPERATIONS WORKSPACE */}
        <main className="flex-1 overflow-y-auto relative z-10 w-full py-[28px]">
          <div className="max-w-[1600px] mx-auto px-8 flex flex-col gap-[28px] w-full">
            
            {/* HEADING ACCENT ROW */}
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 border-b border-slate-800/20 dark:border-slate-800/40 pb-6">
              <div className="flex flex-col gap-1.5">
                <span className="text-[12px] font-mono tracking-widest text-cyan-400 uppercase font-bold">
                  Smart Manufacturing Execution Control Panel
                </span>
                <h2 className="text-[38px] font-extrabold tracking-tight text-slate-900 dark:text-white leading-tight">
                  {activeTab === "dashboard" && (
                    dashboardView === "overview" 
                      ? "Line Operations Dashboard" 
                      : "BI Telemetry Analytics"
                  )}
                  {activeTab === "reports" && "Compliance Reports Panel"}
                  {activeTab === "settings" && "MES Node Configuration"}
                </h2>
                <p className="text-[14px] text-gray-500 font-medium">
                  {activeTab === "dashboard" && (
                    dashboardView === "overview"
                      ? "Real-time production tracking, quality metrics, and batch lifecycle administration."
                      : "Advanced SCADA telemetry charting, operator performance trends, and downtime analysis."
                  )}
                  {activeTab === "reports" && "Comprehensive shift compliance summary documents, CSV/JSON backups, and audit registers."}
                  {activeTab === "settings" && "System configurations, active operator terminal profile, and local database sync presets."}
                </p>
              </div>

              {/* Quick add button & DOWN / AO Controls - Primary Button 44px height */}
              <div className="flex items-center gap-4 self-end lg:self-center">
                
                {/* Cloud Sync Status Icon ("DOWN") - Desktop Only */}
                <div
                  className={`hidden md:flex px-3 py-1.5 h-[44px] rounded-xl items-center gap-2 border text-[10px] font-mono uppercase font-bold tracking-wider transition-all cursor-pointer relative group ${
                    isDbSynced
                      ? isDarkMode
                        ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                        : "bg-emerald-50 border-emerald-200 text-emerald-600"
                      : isDarkMode
                      ? "bg-amber-500/10 border-amber-500/20 text-amber-400"
                      : "bg-amber-50 border-amber-200 text-amber-600"
                  }`}
                >
                  <Database className="w-4 h-4 text-emerald-400" />
                  <span>{isDbSynced ? "Live Sync" : "Buffer"}</span>
                  <span className="flex h-1.5 w-1.5 relative">
                    <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isDbSynced ? "bg-emerald-400" : "bg-amber-400"}`}></span>
                    <span className={`relative inline-flex rounded-full h-1.5 w-1.5 ${isDbSynced ? "bg-emerald-500" : "bg-amber-500"}`}></span>
                  </span>
                </div>

                {/* User initials bubble ("AO") - Desktop Only */}
                <div className="hidden md:flex items-center gap-2.5 h-[44px] border-r border-l px-4 border-slate-800/10 dark:border-slate-800/30">
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold border transition-all ${
                      isDarkMode ? "bg-slate-800 border-slate-700 text-white" : "bg-slate-200 border-slate-300 text-slate-800"
                    }`}
                  >
                    {operatorInitials}
                  </div>
                  <span className="text-xs font-semibold">{activeOperator}</span>
                </div>

                <button
                  onClick={handleAddTrigger}
                  className="h-[44px] bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs px-5 rounded-xl shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-2 cursor-pointer hover:scale-[1.02] hover:shadow-cyan-500/35 active:scale-[0.98]"
                >
                  <Plus className="h-4.5 w-4.5" />
                  <span>Log Batch Run</span>
                </button>
              </div>
            </div>

            {/* TOP LAYOUT COMBINING KPIS (4 CARDS) AND CONTROLS (RIGHT) */}
            <div className="flex flex-col xl:flex-row gap-6 w-full items-start">
              {/* Left Side: 4 KPI Cards */}
              <div className="flex-1 w-full">
                <KPIStats logs={filteredLogs} isDarkMode={isDarkMode} />
              </div>

              {/* Right Side: Tab Buttons / Controls (Overview / Downtime) */}
              {activeTab === "dashboard" && (
                <div className="flex flex-row xl:flex-col gap-2 w-full xl:w-64 xl:h-[74px] shrink-0 overflow-x-auto pb-1 xl:pb-0 justify-between">
                  <button
                    onClick={() => setDashboardView("overview")}
                    className={`flex-1 xl:w-full h-[33px] px-3.5 rounded-[10px] border transition-all duration-300 relative overflow-hidden cursor-pointer flex items-center justify-between text-left ${
                      dashboardView === "overview"
                        ? isDarkMode
                          ? "bg-[#0B0D12]/90 border-cyan-500/40 shadow-[0_0_12px_rgba(6,182,212,0.15)] text-cyan-400"
                          : "bg-cyan-50 border-cyan-300 text-cyan-950 font-extrabold"
                        : isDarkMode
                        ? "bg-[#0B0D12]/90 border-[#1E293B]/60 hover:border-slate-800 text-slate-400"
                        : "bg-white border-blue-100 hover:border-blue-200 text-slate-600"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono tracking-wider uppercase font-bold leading-none">
                        Overview
                      </span>
                    </div>

                    {/* Icon container */}
                    <div
                      className={`w-5 h-5 rounded-md flex items-center justify-center border transition-all duration-300 ${
                        dashboardView === "overview"
                          ? isDarkMode
                            ? "bg-cyan-500/15 border-cyan-500/30 text-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.2)]"
                            : "bg-cyan-100 border-cyan-200 text-cyan-700"
                          : isDarkMode
                          ? "bg-slate-900 border-slate-800 text-slate-500"
                          : "bg-slate-100 border-slate-200 text-slate-400"
                      }`}
                    >
                      <Layers className="h-3 w-3" />
                    </div>
                  </button>

                  <button
                    onClick={() => setDashboardView("analysis")}
                    className={`flex-1 xl:w-full h-[33px] px-3.5 rounded-[10px] border transition-all duration-300 relative overflow-hidden cursor-pointer flex items-center justify-between text-left ${
                      dashboardView === "analysis"
                        ? isDarkMode
                          ? "bg-[#0B0D12]/90 border-cyan-500/40 shadow-[0_0_12px_rgba(6,182,212,0.15)] text-cyan-400"
                          : "bg-cyan-50 border-cyan-300 text-cyan-950 font-extrabold"
                        : isDarkMode
                        ? "bg-[#0B0D12]/90 border-[#1E293B]/60 hover:border-slate-800 text-slate-400"
                        : "bg-white border-blue-100 hover:border-blue-200 text-slate-600"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono tracking-wider uppercase font-bold leading-none">
                        Downtime
                      </span>
                    </div>

                    {/* Icon container */}
                    <div
                      className={`w-5 h-5 rounded-md flex items-center justify-center border transition-all duration-300 ${
                        dashboardView === "analysis"
                          ? isDarkMode
                            ? "bg-cyan-500/15 border-cyan-500/30 text-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.25)]"
                            : "bg-cyan-100 border-cyan-200 text-cyan-700"
                          : isDarkMode
                          ? "bg-slate-900 border-slate-800 text-slate-500"
                          : "bg-slate-100 border-slate-200 text-slate-400"
                      }`}
                    >
                      <TrendingUp className="h-3 w-3" />
                    </div>
                  </button>
                </div>
              )}
            </div>

            {/* TAB CONTENTS */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.25 }}
                className="flex flex-col gap-[28px]"
              >
                {/* 1. Dashboard Tab */}
                {activeTab === "dashboard" && (
                  <div className="flex flex-col gap-[28px] w-full">
                    <ChartsSection 
                      logs={filteredLogs} 
                      factors={factors} 
                      isDarkMode={isDarkMode} 
                      activeTab={activeTab} 
                      setActiveTab={setActiveTab} 
                      currentDashboard={dashboardView}
                      selectedFactor={selectedFactor}
                    />
                    <LogsTable
                      logs={filteredLogs}
                      unfilteredLogs={logs}
                      products={products}
                      factors={factors}
                      isDarkMode={isDarkMode}
                      onView={triggerBatchAnalysis}
                      onEdit={handleEditTrigger}
                      onDelete={handleDeleteLog}
                      addToast={addToast}
                      onImportLogs={handleImportLogs}
                      onImportProducts={handleImportProducts}
                      onImportFactors={handleImportFactors}
                      onImportDowntimes={handleImportDowntimes}
                      onRestoreDefaults={handleRestoreDefaults}
                      onClearAll={handleClearAllData}
                      
                      search={search}
                      setSearch={setSearch}
                      selectedOperator={selectedOperator}
                      setSelectedOperator={setSelectedOperator}
                      selectedProduct={selectedProduct}
                      setSelectedProduct={setSelectedProduct}
                      selectedShift={selectedShift}
                      setSelectedShift={setSelectedShift}
                      selectedStatus={selectedStatus}
                      setSelectedStatus={setSelectedStatus}
                      selectedFactor={selectedFactor}
                      setSelectedFactor={setSelectedFactor}
                      startDate={startDate}
                      setStartDate={setStartDate}
                      endDate={endDate}
                      setEndDate={setEndDate}
                      selectedBatch={selectedBatch}
                      setSelectedBatch={setSelectedBatch}
                    />
                  </div>
                )}

                {/* 3. Reports Compliance Tab */}
                {activeTab === "reports" && (
                  <div className="flex flex-col gap-[28px]">
                    <ReportsPanel logs={logs} factors={factors} isDarkMode={isDarkMode} addToast={addToast} />
                  </div>
                )}

                {/* 5. Settings Configuration Tab */}
                {activeTab === "settings" && (
                  <div className="max-w-xl mx-auto w-full">
                    {/* Operator config */}
                    <div className={`p-6 rounded-3xl border shadow-xl flex flex-col gap-4 ${
                      isDarkMode ? "bg-[#0F1115]/80 border-[#22242D]" : "bg-white border-slate-200"
                    }`}>
                      <h3 className="text-sm font-bold tracking-tight">Active Operator Workspace</h3>
                      <p className="text-xs text-gray-400">
                        Configure your local terminal operator profile to personalize database logs
                      </p>

                      <div className="flex flex-col gap-4 mt-2">
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-gray-500 uppercase font-semibold">Active Operator Profile</label>
                          <select
                            value={activeOperator}
                            onChange={(e) => {
                              setActiveOperator(e.target.value);
                              addToast(`Switched terminal profile to ${e.target.value}.`, "info");
                            }}
                            className={`px-4 py-3 rounded-xl border outline-none text-xs font-semibold ${
                              isDarkMode ? "bg-slate-950 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-800"
                            }`}
                          >
                            <option value="Mac">Mac</option>
                            <option value="Charlie">Charlie</option>
                            <option value="Dee">Dee</option>
                            <option value="Dennis">Dennis</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* DIALOG FORMS POPUP MODAL */}
      <BatchFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSave={handleSaveBatch}
        editingLog={editingLog}
        products={products}
        factors={factors}
        isDarkMode={isDarkMode}
        addToast={addToast}
        nextBatchNumber={nextBatchNumber}
      />

      {/* GEMINI DIAGNOSTICS MODAL */}
      <AnimatePresence>
        {isAnalysisModalOpen && selectedLogForAnalysis && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAnalysisModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            
            {/* Modal Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ type: "spring", duration: 0.3 }}
              className={`relative w-full max-w-2xl rounded-3xl border shadow-2xl p-6 flex flex-col gap-4 overflow-hidden z-10 ${
                isDarkMode ? "bg-[#0F1115] border-[#22242D] text-[#E4E6EB]" : "bg-white border-slate-200 text-slate-800"
              }`}
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-lg bg-cyan-400/10 text-cyan-400 animate-pulse">
                    <Sparkles className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold tracking-tight">
                      Gemini AI Diagnostics
                    </h3>
                    <p className="text-[11px] text-gray-500 font-medium">Batch Run Constraint Evaluation</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-500/10 px-2.5 py-1 rounded-lg">
                    Batch #{selectedLogForAnalysis.batch}
                  </span>
                  <button
                    onClick={() => setIsAnalysisModalOpen(false)}
                    className="text-gray-400 hover:text-white transition-colors p-1 text-xl font-bold cursor-pointer"
                  >
                    &times;
                  </button>
                </div>
              </div>

              {/* Quick Info Grid */}
              <div className="grid grid-cols-3 gap-3 text-[10px] font-mono">
                <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/80">
                  <span className="text-gray-500 block mb-1">Operator</span>
                  <strong className="text-gray-300 block text-xs truncate">{selectedLogForAnalysis.operator_name}</strong>
                </div>
                <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/80">
                  <span className="text-gray-500 block mb-1">Flavor Run</span>
                  <strong className="text-gray-300 block text-xs truncate">{selectedLogForAnalysis.flavor}</strong>
                </div>
                <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/80">
                  <span className="text-gray-500 block mb-1">Deviation</span>
                  <strong className={`block text-xs truncate ${selectedLogForAnalysis.downtime_min ? "text-rose-400" : "text-emerald-400"}`}>
                    {selectedLogForAnalysis.downtime_min ? `+${selectedLogForAnalysis.downtime_min}m loss` : "Perfect On-Time"}
                  </strong>
                </div>
              </div>

              {/* Analysis Text Body */}
              <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-sm leading-relaxed text-gray-300 max-h-[350px] overflow-y-auto font-sans">
                {isAnalyzing ? (
                  <div className="flex flex-col items-center justify-center py-12 gap-3">
                    <RefreshCw className="h-7 w-7 text-cyan-400 animate-spin" />
                    <span className="text-[11px] font-mono text-gray-400 animate-pulse">
                      Running LLM model evaluation on line constraints...
                    </span>
                  </div>
                ) : activeAnalysis || selectedLogForAnalysis.ai_analysis ? (
                  <p className="whitespace-pre-wrap font-sans text-gray-300">
                    {activeAnalysis || selectedLogForAnalysis.ai_analysis}
                  </p>
                ) : (
                  <div className="text-center py-10 flex flex-col items-center gap-2">
                    <Lightbulb className="h-6 w-6 text-cyan-400" />
                    <span className="text-xs text-gray-400">No analytical insights generated for this run.</span>
                  </div>
                )}
              </div>

              {/* Footer Actions */}
              <div className="flex items-center justify-end gap-3 border-t border-slate-800/40 pt-4 mt-1">
                <button
                  onClick={() => setIsAnalysisModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-800 text-xs font-semibold text-gray-400 hover:text-white hover:bg-slate-900 transition-colors cursor-pointer"
                >
                  Close
                </button>
                {!isAnalyzing && (
                  <button
                    onClick={() => triggerBatchAnalysis(selectedLogForAnalysis)}
                    className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-lg shadow-cyan-500/25 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Sparkles className="h-4 w-4" />
                    <span>Re-run Diagnostics</span>
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FOOTER ACCENT FOOT */}
      <footer className="mt-12 border-t border-slate-800/40 dark:border-slate-800 py-8 text-center text-xs text-gray-500 w-full px-8 font-mono">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <Factory className="h-4 w-4 text-cyan-400 animate-pulse" />
            <span className="font-bold text-gray-200">Manufacturing Line BI Dashboard</span>
          </div>
          <div>
            Built with Gemini 3.5 &amp; Supabase Cloud Analytics
          </div>
          <div>
            &copy; 2026 Manufacturing Line Inc. All telemetry monitored and logged.
          </div>
        </div>
      </footer>

    </div>
  );
}
