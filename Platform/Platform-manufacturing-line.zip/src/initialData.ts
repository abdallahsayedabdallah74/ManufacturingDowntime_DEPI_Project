import { Product, Factor, ProductionLog } from "./types";

export const PRODUCTS: Product[] = [
  { product_id: "OR-600", flavor: "Orange", size: "600 ml", min_batch_time: 60 },
  { product_id: "LE-600", flavor: "Lemon lime", size: "600 ml", min_batch_time: 60 },
  { product_id: "CO-600", flavor: "Cola", size: "600 ml", min_batch_time: 60 },
  { product_id: "DC-600", flavor: "Diet Cola", size: "600 ml", min_batch_time: 60 },
  { product_id: "RB-600", flavor: "Root Berry", size: "600 ml", min_batch_time: 60 },
  { product_id: "CO-2L", flavor: "Cola", size: "2 L", min_batch_time: 98 }
];

export const FACTORS: Factor[] = [
  { factor_id: 1, description: "Emergency stop", operator_error: false },
  { factor_id: 2, description: "Batch change", operator_error: true },
  { factor_id: 3, description: "Labeling error", operator_error: false },
  { factor_id: 4, description: "Inventory shortage", operator_error: false },
  { factor_id: 5, description: "Product spill", operator_error: true },
  { factor_id: 6, description: "Machine adjustment", operator_error: true },
  { factor_id: 7, description: "Machine failure", operator_error: false },
  { factor_id: 8, description: "Batch coding error", operator_error: true },
  { factor_id: 9, description: "Conveyor belt jam", operator_error: false },
  { factor_id: 10, description: "Calibration error", operator_error: true },
  { factor_id: 11, description: "Label switch", operator_error: true },
  { factor_id: 12, description: "Other", operator_error: false }
];

export interface DowntimeItem {
  batch: number;
  factor_id: number;
  minutes: number;
}

export const DOWNTIMES: DowntimeItem[] = [
  { batch: 422111, factor_id: 2, minutes: 60 },
  { batch: 422111, factor_id: 7, minutes: 15 },
  { batch: 422112, factor_id: 2, minutes: 20 },
  { batch: 422112, factor_id: 8, minutes: 20 },
  { batch: 422113, factor_id: 2, minutes: 50 },
  { batch: 422114, factor_id: 4, minutes: 25 },
  { batch: 422114, factor_id: 6, minutes: 15 },
  { batch: 422115, factor_id: 10, minutes: 24 },
  { batch: 422117, factor_id: 2, minutes: 10 },
  { batch: 422117, factor_id: 6, minutes: 5 },
  { batch: 422118, factor_id: 6, minutes: 14 },
  { batch: 422118, factor_id: 7, minutes: 16 },
  { batch: 422118, factor_id: 11, minutes: 10 },
  { batch: 422118, factor_id: 12, minutes: 20 },
  { batch: 422119, factor_id: 4, minutes: 25 },
  { batch: 422120, factor_id: 4, minutes: 20 },
  { batch: 422120, factor_id: 5, minutes: 15 },
  { batch: 422120, factor_id: 9, minutes: 17 },
  { batch: 422121, factor_id: 7, minutes: 15 },
  { batch: 422122, factor_id: 7, minutes: 25 },
  { batch: 422123, factor_id: 4, minutes: 43 },
  { batch: 422123, factor_id: 7, minutes: 30 },
  { batch: 422124, factor_id: 5, minutes: 20 },
  { batch: 422124, factor_id: 6, minutes: 20 },
  { batch: 422125, factor_id: 11, minutes: 10 },
  { batch: 422125, factor_id: 12, minutes: 10 },
  { batch: 422126, factor_id: 8, minutes: 44 },
  { batch: 422127, factor_id: 6, minutes: 23 },
  { batch: 422128, factor_id: 5, minutes: 22 },
  { batch: 422128, factor_id: 7, minutes: 30 },
  { batch: 422129, factor_id: 12, minutes: 15 },
  { batch: 422130, factor_id: 2, minutes: 20 },
  { batch: 422131, factor_id: 4, minutes: 20 },
  { batch: 422131, factor_id: 10, minutes: 10 },
  { batch: 422133, factor_id: 7, minutes: 20 },
  { batch: 422134, factor_id: 7, minutes: 30 },
  { batch: 422134, factor_id: 8, minutes: 20 },
  { batch: 422135, factor_id: 4, minutes: 30 },
  { batch: 422135, factor_id: 12, minutes: 15 },
  { batch: 422137, factor_id: 8, minutes: 30 },
  { batch: 422137, factor_id: 10, minutes: 15 },
  { batch: 422138, factor_id: 3, minutes: 20 },
  { batch: 422139, factor_id: 4, minutes: 20 },
  { batch: 422139, factor_id: 6, minutes: 15 },
  { batch: 422140, factor_id: 6, minutes: 50 },
  { batch: 422140, factor_id: 11, minutes: 13 },
  { batch: 422141, factor_id: 12, minutes: 7 },
  { batch: 422142, factor_id: 6, minutes: 30 },
  { batch: 422143, factor_id: 6, minutes: 40 },
  { batch: 422143, factor_id: 7, minutes: 18 },
  { batch: 422144, factor_id: 6, minutes: 30 },
  { batch: 422144, factor_id: 8, minutes: 24 },
  { batch: 422145, factor_id: 3, minutes: 22 },
  { batch: 422146, factor_id: 6, minutes: 30 },
  { batch: 422146, factor_id: 7, minutes: 25 },
  { batch: 422146, factor_id: 12, minutes: 7 },
  { batch: 422147, factor_id: 4, minutes: 17 },
  { batch: 422147, factor_id: 6, minutes: 60 },
  { batch: 422147, factor_id: 7, minutes: 30 },
  { batch: 422148, factor_id: 4, minutes: 25 },
  { batch: 422148, factor_id: 8, minutes: 7 }
];

export const RAW_BATCHES = [
  { batch: 422111, date: "2024-08-29", product_id: "OR-600", operator_name: "Mac", start_time: "11:50", end_time: "14:05", duration: 135, shift: "Morning", status: "Downtime Delay" },
  { batch: 422112, date: "2024-08-29", product_id: "LE-600", operator_name: "Mac", start_time: "14:05", end_time: "15:45", duration: 100, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422113, date: "2024-08-29", product_id: "LE-600", operator_name: "Mac", start_time: "15:45", end_time: "17:35", duration: 110, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422114, date: "2024-08-29", product_id: "LE-600", operator_name: "Mac", start_time: "17:35", end_time: "19:15", duration: 100, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422115, date: "2024-08-29", product_id: "LE-600", operator_name: "Charlie", start_time: "19:15", end_time: "20:39", duration: 84, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422116, date: "2024-08-29", product_id: "LE-600", operator_name: "Charlie", start_time: "20:39", end_time: "21:39", duration: 60, shift: "Afternoon", status: "Optimal" },
  { batch: 422117, date: "2024-08-29", product_id: "LE-600", operator_name: "Charlie", start_time: "21:39", end_time: "22:54", duration: 75, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422118, date: "2024-08-30", product_id: "CO-600", operator_name: "Dee", start_time: "04:05", end_time: "06:05", duration: 120, shift: "Night", status: "Downtime Delay" },
  { batch: 422119, date: "2024-08-30", product_id: "CO-600", operator_name: "Dee", start_time: "06:05", end_time: "07:30", duration: 85, shift: "Morning", status: "Downtime Delay" },
  { batch: 422120, date: "2024-08-30", product_id: "CO-600", operator_name: "Dee", start_time: "07:30", end_time: "09:22", duration: 112, shift: "Morning", status: "Downtime Delay" },
  { batch: 422121, date: "2024-08-30", product_id: "CO-600", operator_name: "Dennis", start_time: "09:22", end_time: "10:37", duration: 75, shift: "Morning", status: "Downtime Delay" },
  { batch: 422122, date: "2024-08-30", product_id: "CO-600", operator_name: "Dennis", start_time: "10:37", end_time: "12:02", duration: 85, shift: "Morning", status: "Downtime Delay" },
  { batch: 422123, date: "2024-08-30", product_id: "CO-600", operator_name: "Dennis", start_time: "12:02", end_time: "14:15", duration: 133, shift: "Morning", status: "Downtime Delay" },
  { batch: 422124, date: "2024-08-30", product_id: "CO-600", operator_name: "Dennis", start_time: "14:15", end_time: "15:55", duration: 100, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422125, date: "2024-08-30", product_id: "CO-600", operator_name: "Charlie", start_time: "15:55", end_time: "17:15", duration: 80, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422126, date: "2024-08-30", product_id: "CO-600", operator_name: "Charlie", start_time: "17:15", end_time: "18:59", duration: 104, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422127, date: "2024-08-30", product_id: "CO-600", operator_name: "Charlie", start_time: "18:59", end_time: "20:22", duration: 83, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422128, date: "2024-08-30", product_id: "CO-600", operator_name: "Charlie", start_time: "20:22", end_time: "22:14", duration: 112, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422129, date: "2024-08-30", product_id: "CO-600", operator_name: "Charlie", start_time: "22:14", end_time: "23:29", duration: 75, shift: "Night", status: "Downtime Delay" },
  { batch: 422130, date: "2024-08-31", product_id: "CO-600", operator_name: "Dee", start_time: "07:45", end_time: "09:05", duration: 80, shift: "Morning", status: "Downtime Delay" },
  { batch: 422131, date: "2024-08-31", product_id: "CO-600", operator_name: "Dee", start_time: "09:05", end_time: "10:35", duration: 90, shift: "Morning", status: "Downtime Delay" },
  { batch: 422132, date: "2024-08-31", product_id: "CO-600", operator_name: "Dee", start_time: "10:35", end_time: "11:35", duration: 60, shift: "Morning", status: "Optimal" },
  { batch: 422133, date: "2024-08-31", product_id: "DC-600", operator_name: "Dee", start_time: "11:35", end_time: "12:55", duration: 80, shift: "Morning", status: "Downtime Delay" },
  { batch: 422134, date: "2024-08-31", product_id: "DC-600", operator_name: "Mac", start_time: "12:55", end_time: "14:45", duration: 110, shift: "Morning", status: "Downtime Delay" },
  { batch: 422135, date: "2024-08-31", product_id: "DC-600", operator_name: "Mac", start_time: "14:45", end_time: "16:30", duration: 105, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422136, date: "2024-08-31", product_id: "DC-600", operator_name: "Mac", start_time: "16:30", end_time: "17:30", duration: 60, shift: "Afternoon", status: "Optimal" },
  { batch: 422137, date: "2024-09-02", product_id: "RB-600", operator_name: "Dee", start_time: "01:00", end_time: "02:45", duration: 105, shift: "Night", status: "Downtime Delay" },
  { batch: 422138, date: "2024-09-02", product_id: "RB-600", operator_name: "Dee", start_time: "02:45", end_time: "04:05", duration: 80, shift: "Night", status: "Downtime Delay" },
  { batch: 422139, date: "2024-09-02", product_id: "RB-600", operator_name: "Dee", start_time: "04:05", end_time: "05:40", duration: 95, shift: "Night", status: "Downtime Delay" },
  { batch: 422140, date: "2024-09-02", product_id: "RB-600", operator_name: "Dee", start_time: "05:40", end_time: "07:43", duration: 123, shift: "Night", status: "Downtime Delay" },
  { batch: 422141, date: "2024-09-02", product_id: "RB-600", operator_name: "Dennis", start_time: "07:43", end_time: "08:50", duration: 67, shift: "Morning", status: "Downtime Delay" },
  { batch: 422142, date: "2024-09-02", product_id: "RB-600", operator_name: "Dennis", start_time: "08:50", end_time: "10:20", duration: 90, shift: "Morning", status: "Downtime Delay" },
  { batch: 422143, date: "2024-09-02", product_id: "RB-600", operator_name: "Dennis", start_time: "10:20", end_time: "12:18", duration: 118, shift: "Morning", status: "Downtime Delay" },
  { batch: 422144, date: "2024-09-02", product_id: "CO-2L", operator_name: "Dennis", start_time: "12:18", end_time: "14:50", duration: 152, shift: "Morning", status: "Downtime Delay" },
  { batch: 422145, date: "2024-09-02", product_id: "CO-2L", operator_name: "Charlie", start_time: "24:50", end_time: "16:50", duration: 120, shift: "Afternoon", status: "Downtime Delay" }, // Fix 14:50 - 16:50
  { batch: 422146, date: "2024-09-02", product_id: "CO-2L", operator_name: "Charlie", start_time: "16:50", end_time: "19:30", duration: 160, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422147, date: "2024-09-02", product_id: "CO-2L", operator_name: "Charlie", start_time: "19:30", end_time: "22:55", duration: 205, shift: "Afternoon", status: "Downtime Delay" },
  { batch: 422148, date: "2024-09-03", product_id: "CO-2L", operator_name: "Mac", start_time: "22:55", end_time: "01:05", duration: 130, shift: "Night", status: "Downtime Delay" }
];

export function getFullProductionLogs(): ProductionLog[] {
  return RAW_BATCHES.map((b) => {
    const prod = PRODUCTS.find((p) => p.product_id === b.product_id);
    const btDowntimes = DOWNTIMES.filter((d) => d.batch === b.batch);
    const totalDowntimeMin = btDowntimes.reduce((acc, curr) => acc + curr.minutes, 0);

    let factorId: number | undefined = undefined;
    let downtimeReason: string | undefined = undefined;

    if (btDowntimes.length > 0) {
      factorId = btDowntimes[0].factor_id;
      const factor = FACTORS.find((f) => f.factor_id === factorId);
      downtimeReason = factor ? factor.description : "Other";
    }

    // Fix some start_time values if they have typos or 24-hour wrap
    let cleanedStart = b.start_time;
    if (cleanedStart === "24:50") cleanedStart = "14:50";

    return {
      id: `B-${b.batch}`,
      batch: b.batch,
      date: b.date,
      product_id: b.product_id,
      flavor: prod ? prod.flavor : "Unknown",
      size: prod ? prod.size : "N/A",
      min_batch_time: prod ? prod.min_batch_time : 60,
      operator_name: b.operator_name,
      start_time: cleanedStart,
      end_time: b.end_time,
      duration: b.duration,
      shift: b.shift,
      status: b.status as "Optimal" | "Downtime Delay",
      downtime_min: totalDowntimeMin > 0 ? totalDowntimeMin : undefined,
      factor_id: factorId,
      downtime_reason: downtimeReason,
      // Create detailed downtime list
      downtime_details: btDowntimes.map((d) => {
        const fac = FACTORS.find((f) => f.factor_id === d.factor_id);
        return {
          factor_id: d.factor_id,
          minutes: d.minutes,
          description: fac ? fac.description : "Other",
          operator_error: fac ? fac.operator_error : false
        };
      })
    } as any;
  });
}
