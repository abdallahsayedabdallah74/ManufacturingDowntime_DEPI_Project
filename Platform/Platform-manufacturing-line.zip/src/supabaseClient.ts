import { createClient } from "@supabase/supabase-js";
import { Product, Factor, ProductionLog } from "./types";
import { PRODUCTS, FACTORS, DOWNTIMES, getFullProductionLogs } from "./initialData";

// Supabase configuration
const SUPABASE_URL = "https://qaebjsesbxgqgyjblcay.supabase.co";
const SUPABASE_KEY = "sb_publishable_izEup8TC3MbEuQHjVaPrSw_ksat4XHW";

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// Default starting data for ultra-resilient fallback
export const DEFAULT_PRODUCTS: Product[] = PRODUCTS;

export const DEFAULT_FACTORS: Factor[] = FACTORS;

// Helper to check if database tables exist and are queries
export async function fetchProducts(): Promise<Product[]> {
  try {
    const { data, error } = await supabase.from("products").select("*");
    if (error) throw error;
    if (data && data.length > 0) {
      const allowedIds = ["OR-600", "LE-600", "CO-600", "DC-600", "RB-600", "CO-2L"];
      return (data as Product[]).filter((p) => allowedIds.includes(p.product_id.toUpperCase()));
    }
  } catch (err) {
    console.warn("Supabase products fetch failed or table doesn't exist, using defaults:", err);
  }
  return DEFAULT_PRODUCTS;
}

export async function fetchFactors(): Promise<Factor[]> {
  try {
    const { data, error } = await supabase.from("factors").select("*");
    if (error) throw error;
    if (data && data.length > 0) {
      return data as Factor[];
    } else {
      // Seed factors in background if table is empty but exists
      console.info("Factors table is empty in database, seeding default 12 factors...");
      const rows = DEFAULT_FACTORS.map(f => ({
        Factor_id: f.factor_id,
        Description: f.description,
        Operator_Error: f.operator_error
      }));
      supabase.from("factors").insert(rows).then(({ error }) => {
        if (error) {
          const lowercaseRows = DEFAULT_FACTORS.map(f => ({
            factor_id: f.factor_id,
            description: f.description,
            operator_error: f.operator_error
          }));
          supabase.from("factors").insert(lowercaseRows);
        }
      });
    }
  } catch (err) {
    console.warn("Supabase factors fetch failed or table doesn't exist, using defaults:", err);
  }
  return DEFAULT_FACTORS;
}

// Helper to normalize and correct logs dynamically, healing any calculation issues
export function normalizeProductionLogs(
  rawLogs: any[],
  products: Product[],
  factors: Factor[]
): ProductionLog[] {
  return rawLogs.map((row) => {
    const prod = products.find((p) => p.product_id.toLowerCase() === row.product_id?.toLowerCase()) || 
                 products.find((p) => p.flavor.toLowerCase() === row.flavor?.toLowerCase() && p.size.toLowerCase() === row.size?.toLowerCase());
    
    // Recalculate duration dynamically to fix any past calculation bugs
    const duration = calculateDurationMinutes(row.start_time, row.end_time);
    const min_batch_time = prod ? prod.min_batch_time : (row.min_batch_time || 60);

    const status = duration > min_batch_time ? "Downtime Delay" : "Optimal";

    // Dynamically calculate shift based on the strict shift schedule:
    // - Morning: 6 AM to 2 PM (06:00 to 14:00)
    // - Afternoon: 2 PM to 10 PM (14:00 to 22:00)
    // - Night: 10 PM to 6 AM (22:00 to 06:00)
    const startTimeStr = row.start_time || "06:00";
    const [hour] = startTimeStr.split(":").map(Number);
    let shift = "Morning";
    if (hour >= 6 && hour < 14) {
      shift = "Morning";
    } else if (hour >= 14 && hour < 22) {
      shift = "Afternoon";
    } else {
      shift = "Night";
    }

    // Handle downtime entries mapping
    let downtime_entries = row.downtime_entries || (row.downtime_details ? row.downtime_details.map((d: any) => ({
      factor_id: d.factor_id,
      downtime_min: d.minutes !== undefined ? d.minutes : (d.downtime_min || 0),
      downtime_reason: d.description || d.downtime_reason || "Other"
    })) : []);

    // If there are no downtime entries but this is a downtime delay, or if we have legacy columns:
    if (status === "Downtime Delay") {
      if (downtime_entries.length === 0) {
        let legacyMin = row.downtime_min;
        if (legacyMin === undefined || legacyMin === null || legacyMin <= 0) {
          legacyMin = duration - min_batch_time;
        }
        let legacyFactorId = row.factor_id || 12;
        const matchedFactor = factors.find((f) => f.factor_id === Number(legacyFactorId));
        downtime_entries = [{
          factor_id: Number(legacyFactorId),
          downtime_min: Number(legacyMin),
          downtime_reason: matchedFactor ? matchedFactor.description : "Other"
        }];
      }
    } else {
      downtime_entries = [];
    }

    // Resolve factor description dynamically for all entries
    downtime_entries = downtime_entries.map((entry: any) => {
      const matchedFactor = factors.find((f) => f.factor_id === Number(entry.factor_id));
      return {
        ...entry,
        downtime_reason: matchedFactor ? matchedFactor.description : (entry.downtime_reason || "Other"),
        operator_error: entry.operator_error !== undefined ? entry.operator_error : (matchedFactor ? matchedFactor.operator_error : false)
      };
    });

    const totalDowntimeMin = downtime_entries.reduce((sum: number, entry: any) => sum + entry.downtime_min, 0);
    const firstEntry = downtime_entries[0];

    return {
      ...row,
      id: row.id || `B-${row.batch}`,
      shift,
      flavor: prod ? prod.flavor : (row.flavor || "Unknown Flavor"),
      size: prod ? prod.size : (row.size || "N/A"),
      min_batch_time,
      duration,
      status,
      downtime_min: totalDowntimeMin > 0 ? totalDowntimeMin : undefined,
      factor_id: firstEntry ? firstEntry.factor_id : undefined,
      downtime_reason: firstEntry ? firstEntry.downtime_reason : undefined,
      downtime_entries,
    };
  });
}

export async function saveProductionLog(log: ProductionLog): Promise<{ success: boolean; error?: any }> {
  // Try with mixed case columns (from screenshots)
  try {
    const { error: logError } = await supabase.from("production_logs").upsert([
      {
        Batch: log.batch,
        Date: log.date,
        Product_id: log.product_id,
        Operator_name: log.operator_name,
        Start_time: log.start_time,
        End_time: log.end_time,
        Shift: log.shift,
        P_Status: log.status === "Downtime Delay" ? "DELAY" : "ON TIME",
        productin_Duration: log.duration,
      },
    ]);

    if (logError) throw logError;

    // Delete old downtime details for this batch first
    await supabase.from("downtime_details").delete().eq("Batch", log.batch);

    // If there is downtime, log to downtime_details
    if (log.status === "Downtime Delay" || (log.downtime_min && log.downtime_min > 0)) {
      const entriesToSave = log.downtime_entries && log.downtime_entries.length > 0 
        ? log.downtime_entries 
        : (log.factor_id ? [{ factor_id: log.factor_id, downtime_min: log.downtime_min || 0, operator_error: false }] : []);

      if (entriesToSave.length > 0) {
        // Try with Operator_Error column first
        try {
          const rowsToInsert = entriesToSave.map((entry) => ({
            Batch: log.batch,
            Factor_ID: entry.factor_id,
            Downtime_Min: entry.downtime_min,
            Operator_Error: entry.operator_error !== undefined ? entry.operator_error : false,
          }));
          const { error: downError } = await supabase.from("downtime_details").insert(rowsToInsert);
          if (downError) throw downError;
        } catch (downErr) {
          console.warn("Failed to insert downtime_details with Operator_Error column, falling back to basic columns...", downErr);
          const rowsToInsertBasic = entriesToSave.map((entry) => ({
            Batch: log.batch,
            Factor_ID: entry.factor_id,
            Downtime_Min: entry.downtime_min,
          }));
          const { error: basicError } = await supabase.from("downtime_details").insert(rowsToInsertBasic);
          if (basicError) throw basicError;
        }
      }
    }

    return { success: true };
  } catch (err: any) {
    console.warn("Saving with mixed-case columns failed, retrying with lowercase columns...", err);
    
    // Fallback: Retry with lowercase columns
    try {
      const { error: logError } = await supabase.from("production_logs").upsert([
        {
          batch: log.batch,
          date: log.date,
          product_id: log.product_id,
          operator_name: log.operator_name,
          start_time: log.start_time,
          end_time: log.end_time,
          shift: log.shift,
          production_status: log.status,
        },
      ]);

      if (logError) throw logError;

      await supabase.from("downtime_details").delete().eq("batch", log.batch);

      if (log.status === "Downtime Delay" || (log.downtime_min && log.downtime_min > 0)) {
        const entriesToSave = log.downtime_entries && log.downtime_entries.length > 0 
          ? log.downtime_entries 
          : (log.factor_id ? [{ factor_id: log.factor_id, downtime_min: log.downtime_min || 0, operator_error: false }] : []);

        if (entriesToSave.length > 0) {
          // Try with lowercase operator_error column first
          try {
            const rowsToInsert = entriesToSave.map((entry) => ({
              batch: log.batch,
              factor_id: entry.factor_id,
              downtime_min: entry.downtime_min,
              operator_error: entry.operator_error !== undefined ? entry.operator_error : false,
            }));
            const { error: downError } = await supabase.from("downtime_details").insert(rowsToInsert);
            if (downError) throw downError;
          } catch (downErr) {
            console.warn("Failed to insert downtime_details with operator_error lowercase column, falling back to basic columns...", downErr);
            const rowsToInsertBasic = entriesToSave.map((entry) => ({
              batch: log.batch,
              factor_id: entry.factor_id,
              downtime_min: entry.downtime_min,
            }));
            const { error: basicError } = await supabase.from("downtime_details").insert(rowsToInsertBasic);
            if (basicError) throw basicError;
          }
        }
      }

      return { success: true };
    } catch (fallbackErr: any) {
      console.error("Failed to save to Supabase even with lowercase retry:", fallbackErr);
      return { success: false, error: fallbackErr };
    }
  }
}

export async function deleteProductionLog(batchNumber: number): Promise<{ success: boolean; error?: any }> {
  try {
    // Delete from downtime_details first (referential integrity)
    try {
      await supabase.from("downtime_details").delete().eq("Batch", batchNumber);
    } catch (_) {}
    try {
      await supabase.from("downtime_details").delete().eq("batch", batchNumber);
    } catch (_) {}

    // Delete from production_logs
    let { error: err1 } = await supabase.from("production_logs").delete().eq("Batch", batchNumber);
    if (err1) {
      // Fallback lowercase
      let { error: err2 } = await supabase.from("production_logs").delete().eq("batch", batchNumber);
      if (err2) throw err2;
    }

    return { success: true };
  } catch (err: any) {
    console.error("Failed to delete production log from Supabase:", err);
    return { success: false, error: err };
  }
}

export async function clearAllProductionData(): Promise<{ success: boolean; error?: any }> {
  try {
    // We clean existing logs in all relevant logs tables
    try { await supabase.from("downtime_details").delete().neq("batch", 0); } catch (_) {}
    try { await supabase.from("downtime_details").delete().neq("Batch", 0); } catch (_) {}
    try { await supabase.from("production_logs").delete().neq("batch", 0); } catch (_) {}
    try { await supabase.from("production_logs").delete().neq("Batch", 0); } catch (_) {}
    return { success: true };
  } catch (err: any) {
    console.error("Failed to clear production logs from Supabase:", err);
    return { success: false, error: err };
  }
}

export async function fetchProductionLogs(
  products: Product[],
  factors: Factor[]
): Promise<{ logs: ProductionLog[]; isSynced: boolean }> {
  try {
    const { data: logData, error: logError } = await supabase
      .from("production_logs")
      .select("*");

    if (logError) throw logError;

    if (logData) {
      // Fetch downtime details to attach reasons
      let { data: downData } = await supabase.from("downtime_details").select("*");

      // Self-healing: if downtime_details table is completely empty, use DOWNTIMES preloaded defaults
      const hasNoDbDowntimes = !downData || downData.length === 0;
      if (hasNoDbDowntimes && logData.length > 0) {
        console.info("downtime_details table is empty in database, using preloaded fallback DOWNTIMES and seeding in background...");
        
        downData = DOWNTIMES.map(d => ({
          Batch: d.batch,
          batch: d.batch,
          Factor_ID: d.factor_id,
          factor_id: d.factor_id,
          Downtime_Min: d.minutes,
          downtime_min: d.minutes
        }));

        // Back-populate database with default downtimes
        try {
          const rowsToInsert = DOWNTIMES.map(d => ({
            Batch: d.batch,
            Factor_ID: d.factor_id,
            Downtime_Min: d.minutes
          }));
          supabase.from("downtime_details").insert(rowsToInsert).then(({ error }) => {
            if (error) {
              const lowercaseRows = DOWNTIMES.map(d => ({
                batch: d.batch,
                factor_id: d.factor_id,
                downtime_min: d.minutes
              }));
              supabase.from("downtime_details").insert(lowercaseRows);
            }
          });
        } catch (e) {
          console.error("Failed to seed default downtime_details in background:", e);
        }
      }

      const logs = logData.map((row: any) => {
        const batchVal = row.Batch !== undefined ? row.Batch : (row.batch !== undefined ? row.batch : 0);
        const dateVal = row.Date || row.date || "";
        const productIdVal = row.Product_id || row.product_id || "";
        const operatorNameVal = row.Operator_name || row.operator_name || "";
        const startTimeVal = row.Start_time || row.start_time || "";
        const endTimeVal = row.End_time || row.end_time || "";
        const shiftVal = row.Shift || row.shift || "";
        const durationVal = row.productin_Duration !== undefined ? row.productin_Duration : (row.duration !== undefined ? row.duration : 0);
        
        // Find all downtime details for this batch
        const batchDownDetails = downData ? downData.filter((d: any) => {
          const dbBatch = d.Batch !== undefined ? d.Batch : d.batch;
          return Number(dbBatch) === Number(batchVal);
        }) : [];

        const downtimeEntries = batchDownDetails.map((d: any) => {
          const factId = d.Factor_ID !== undefined ? d.Factor_ID : (d.fact_id !== undefined ? d.fact_id : 12);
          const minutes = d.Downtime_Min !== undefined ? d.Downtime_Min : (d.downtime_min !== undefined ? d.downtime_min : 0);
          const matchedFactor = factors.find((f) => f.factor_id === Number(factId));
          return {
            factor_id: Number(factId),
            downtime_min: Number(minutes),
            downtime_reason: matchedFactor ? matchedFactor.description : "Other",
            operator_error: d.operator_error !== undefined 
              ? d.operator_error 
              : d.Operator_Error !== undefined 
              ? d.Operator_Error 
              : (matchedFactor ? matchedFactor.operator_error : false)
          };
        });

        // Compute total downtime minutes
        const totalDowntimeMin = downtimeEntries.reduce((sum, entry) => sum + entry.downtime_min, 0);

        // Get first downtime entry's factor_id and reason for backward compatibility
        const firstEntry = downtimeEntries[0];

        return {
          id: `B-${batchVal}`,
          batch: Number(batchVal),
          date: dateVal,
          product_id: productIdVal,
          operator_name: operatorNameVal,
          start_time: startTimeVal,
          end_time: endTimeVal,
          shift: shiftVal,
          duration: Number(durationVal),
          downtime_min: totalDowntimeMin > 0 ? totalDowntimeMin : undefined,
          factor_id: firstEntry ? firstEntry.factor_id : undefined,
          downtime_reason: firstEntry ? firstEntry.downtime_reason : undefined,
          downtime_entries: downtimeEntries,
        };
      });

      const normalizedLogs = normalizeProductionLogs(logs, products, factors);
      return { logs: normalizedLogs, isSynced: true };
    }
  } catch (err) {
    console.warn("Failed to fetch production logs from Supabase, loading from localStorage:", err);
  }

  // Load from localStorage as safe fallback
  const local = localStorage.getItem("manufacturing_logs_v1");
  const fallbackLogs: ProductionLog[] = local ? JSON.parse(local) : getFullProductionLogs();
  const normalizedFallback = normalizeProductionLogs(fallbackLogs, products, factors);
  return { logs: normalizedFallback, isSynced: false };
}

// Hard seed utility for pristine manual recovery / restoration
export async function seedDatabaseWithDefaults(
  products: Product[],
  factors: Factor[],
  logs: ProductionLog[]
): Promise<{ success: boolean; error?: any }> {
  try {
    // 1. Clean existing records in all tables
    try { await supabase.from("downtime_details").delete().neq("batch", 0); } catch (_) {}
    try { await supabase.from("downtime_details").delete().neq("Batch", 0); } catch (_) {}
    try { await supabase.from("production_logs").delete().neq("batch", 0); } catch (_) {}
    try { await supabase.from("production_logs").delete().neq("Batch", 0); } catch (_) {}
    try { await supabase.from("products").delete().neq("product_id", ""); } catch (_) {}
    try { await supabase.from("factors").delete().neq("factor_id", 0); } catch (_) {}
    try { await supabase.from("factors").delete().neq("Factor_id", 0); } catch (_) {}

    // 2. Seed factors
    const factorRows = factors.map(f => ({
      Factor_id: f.factor_id,
      Description: f.description,
      Operator_Error: f.operator_error
    }));
    const { error: fErr } = await supabase.from("factors").insert(factorRows);
    if (fErr) {
      const lowercaseFactors = factors.map(f => ({
        factor_id: f.factor_id,
        description: f.description,
        operator_error: f.operator_error
      }));
      await supabase.from("factors").insert(lowercaseFactors);
    }

    // 3. Seed products
    const productRows = products.map(p => ({
      Product_id: p.product_id,
      Flavor: p.flavor,
      Size: p.size,
      Min_batch_time: p.min_batch_time
    }));
    const { error: pErr } = await supabase.from("products").insert(productRows);
    if (pErr) {
      const lowercaseProducts = products.map(p => ({
        product_id: p.product_id,
        flavor: p.flavor,
        size: p.size,
        min_batch_time: p.min_batch_time
      }));
      await supabase.from("products").insert(lowercaseProducts);
    }

    // 4. Seed production logs
    const logRows = logs.map(l => ({
      Batch: l.batch,
      Date: l.date,
      Product_id: l.product_id,
      Operator_name: l.operator_name,
      Start_time: l.start_time,
      End_time: l.end_time,
      Shift: l.shift,
      P_Status: l.status === "Downtime Delay" ? "DELAY" : "ON TIME",
      productin_Duration: l.duration,
    }));
    const { error: lErr } = await supabase.from("production_logs").insert(logRows);
    if (lErr) {
      const lowercaseLogs = logs.map(l => ({
        batch: l.batch,
        date: l.date,
        product_id: l.product_id,
        operator_name: l.operator_name,
        start_time: l.start_time,
        end_time: l.end_time,
        shift: l.shift,
        production_status: l.status,
        duration: l.duration
      }));
      await supabase.from("production_logs").insert(lowercaseLogs);
    }

    // 5. Seed downtime details
    const downtimeRows: any[] = [];
    logs.forEach(l => {
      if (l.downtime_entries && l.downtime_entries.length > 0) {
        l.downtime_entries.forEach(entry => {
          downtimeRows.push({
            Batch: l.batch,
            Factor_ID: entry.factor_id,
            Downtime_Min: entry.downtime_min
          });
        });
      }
    });

    if (downtimeRows.length > 0) {
      const { error: dErr } = await supabase.from("downtime_details").insert(downtimeRows);
      if (dErr) {
        const lowercaseDowntimes = downtimeRows.map(dr => ({
          batch: dr.Batch,
          factor_id: dr.Factor_ID,
          downtime_min: dr.Downtime_Min
        }));
        await supabase.from("downtime_details").insert(lowercaseDowntimes);
      }
    }

    return { success: true };
  } catch (err: any) {
    console.error("Database hard seed failed:", err);
    return { success: false, error: err };
  }
}

// Helper to calculate minutes between 'HH:MM' or 'HH:MM:SS AM/PM' times
export function calculateDurationMinutes(start: string, end: string): number {
  if (!start || !end) return 0;

  const parseTimeToMinutes = (timeStr: string): number => {
    const str = timeStr.trim().toLowerCase();
    
    // Check for am/pm
    const isPM = str.includes("pm");
    const isAM = str.includes("am");
    
    // Strip out am/pm and keep digits, colons
    const cleanStr = str.replace(/(am|pm)/g, "").trim();
    const parts = cleanStr.split(":");
    if (parts.length === 0) return 0;
    
    let hours = parseInt(parts[0], 10) || 0;
    let minutes = parts.length > 1 ? parseInt(parts[1], 10) || 0 : 0;
    
    if (isPM || isAM) {
      if (isPM && hours < 12) {
        hours += 12;
      }
      if (isAM && hours === 12) {
        hours = 0;
      }
    }
    
    return hours * 60 + minutes;
  };

  let totalStart = parseTimeToMinutes(start);
  let totalEnd = parseTimeToMinutes(end);

  // Handle midnight wrap-around
  if (totalEnd < totalStart) {
    totalEnd += 24 * 60;
  }

  return totalEnd - totalStart;
}
