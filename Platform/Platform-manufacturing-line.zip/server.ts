import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client
let ai: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  } else {
    console.warn("GEMINI_API_KEY is not defined. AI analysis will run in fallback rule mode.");
  }
} catch (err) {
  console.error("Failed to initialize GoogleGenAI:", err);
}

// API endpoint for batch / global analysis
app.post("/api/analyze", async (req, res) => {
  const { batchData, isGlobal, allBatches } = req.body;

  if (!ai) {
    // Graceful fallback if no Gemini key is configured
    return res.json({
      success: true,
      isFallback: true,
      analysis: generateRuleBasedAnalysis(batchData, isGlobal, allBatches)
    });
  }

  try {
    let prompt = "";
    if (isGlobal) {
      prompt = `You are a professional Manufacturing Operations and BI Data Analyst. 
Analyze the following overall production data of multiple batches on the conveyor line.
Provide a concise, highly insightful executive summary.
For key performance, focus on:
- Production efficiency (total batch duration vs expected min times)
- Downtime analysis (total downtime, key downtime factors, operator error vs mechanical factors)
- Process optimization suggestions (1-2 clear, actionable bullets)

Production Batches Data:
${JSON.stringify(allBatches, null, 2)}

Provide your output in Markdown format. Keep it concise, professional, and visually engaging. Use bolding and structured sections. Avoid marketing fluff or self-praise. Use natural human labels.`;
    } else {
      prompt = `You are a professional Manufacturing Operations Analyst.
Analyze this single production batch on the conveyor line:
Batch Details:
- ID: ${batchData.id}
- Date: ${batchData.date}
- Product Flavor: ${batchData.flavor} (Size: ${batchData.size})
- Operator: ${batchData.operator_name || batchData.operator}
- Shift: ${batchData.shift}
- Duration: ${batchData.duration} minutes
- Expected Normal Min Time: ${batchData.min_batch_time} minutes
- Downtime: ${batchData.downtime_min || batchData.downtime || 0} minutes
- Downtime Reasons Breakdown: ${batchData.downtime_entries && batchData.downtime_entries.length > 0 
    ? batchData.downtime_entries.map((e: any) => `${e.downtime_reason || "Other"} (${e.downtime_min}m)`).join(", ") 
    : batchData.downtime_reason || "None"}
- Production Status: ${batchData.status}

Provide a short, 3-4 sentence analytical insight for this batch. Suggest why downtime might have occurred if applicable, and if the operator met the standard min time. Focus purely on operational fact-based analysis. Output in plain Markdown.`;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    res.json({
      success: true,
      analysis: response.text || generateRuleBasedAnalysis(batchData, isGlobal, allBatches)
    });

  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.json({
      success: true,
      isFallback: true,
      analysis: generateRuleBasedAnalysis(batchData, isGlobal, allBatches),
      error: error.message
    });
  }
});

// Rule-based fallback analysis in case Gemini API is not available or errors out
function generateRuleBasedAnalysis(batchData: any, isGlobal: boolean, allBatches: any[]): string {
  if (isGlobal) {
    if (!allBatches || allBatches.length === 0) {
      return "No production batches available for aggregate analysis. Please add batches to see trends.";
    }

    const totalBatches = allBatches.length;
    const totalDuration = allBatches.reduce((acc, b) => acc + (b.duration || 0), 0);
    const totalDowntime = allBatches.reduce((acc, b) => acc + (b.downtime_min || b.downtime || 0), 0);
    const successfulBatches = allBatches.filter(b => b.status === "Success" || b.status === "Optimal").length;
    const downtimeBatchesCount = allBatches.filter(b => (b.downtime_min || b.downtime || 0) > 0).length;

    const downtimeReasonsMap: Record<string, number> = {};
    allBatches.forEach(b => {
      if (b.downtime_entries && b.downtime_entries.length > 0) {
        b.downtime_entries.forEach((e: any) => {
          const r = e.downtime_reason || "Other";
          downtimeReasonsMap[r] = (downtimeReasonsMap[r] || 0) + (e.downtime_min || 0);
        });
      } else if (b.downtime_reason) {
        const r = b.downtime_reason;
        downtimeReasonsMap[r] = (downtimeReasonsMap[r] || 0) + (b.downtime_min || b.downtime || 0);
      }
    });

    let mainReasonStr = "None";
    let maxDowntime = 0;
    Object.entries(downtimeReasonsMap).forEach(([reason, mins]) => {
      if (mins > maxDowntime) {
        maxDowntime = mins;
        mainReasonStr = reason;
      }
    });

    return `### 📊 Aggregate Production Operations Analysis (Fallback Model)

**Executive Performance Summary:**
- **Total Line Throughput:** ${totalBatches} batches processed successfully.
- **Operational Efficiency:** Average batch duration is **${(totalDuration / totalBatches).toFixed(1)} minutes**.
- **Line Availability:** Total logged line downtime is **${totalDowntime} minutes** across **${downtimeBatchesCount} batches** (${((downtimeBatchesCount / totalBatches) * 100).toFixed(0)}% of total batches experienced delays).

**Key Bottlenecks Detected:**
- ${totalDowntime > 0 ? `The primary driver of line delay is **${mainReasonStr}**, responsible for **${maxDowntime} minutes** of downtime.` : "The line is currently operating within standard optimal parameters with zero downtime recorded."}

**Actionable Optimization Recommendations:**
1. **Targeted Preventive Maintenance:** Establish quick checks for frequent downtime reasons to avoid conveyor friction.
2. **Standard Operating Procedures:** Optimize operator schedules to maintain batch consistency across shifts.`;
  } else {
    if (!batchData) return "No batch data provided for individual analysis.";

    const downtimeVal = batchData.downtime_min || batchData.downtime || 0;
    const exceedsLimit = downtimeVal > 0;
    const duration = batchData.duration || 0;
    const minTime = batchData.min_batch_time || 0;
    const operatorName = batchData.operator_name || batchData.operator || "Mac";

    if (exceedsLimit) {
      const breakdownStr = batchData.downtime_entries && batchData.downtime_entries.length > 0
        ? batchData.downtime_entries.map((e: any) => `"${e.downtime_reason || 'Other'}" (${e.downtime_min} mins)`).join(", ")
        : `"${batchData.downtime_reason || 'Other'}"`;

      return `### 🔍 Batch #${batchData.id} Analytical Insight
The line duration was **${duration} minutes**, exceeding the target optimal standard of **${minTime} minutes** by **${downtimeVal} minutes**. 
The reported delay breakdown: ${breakdownStr}. 
*Recommendation:* Operator **${operatorName}** should review safety clearances and coordinate with the maintenance team to prevent recursive issues on this flavor line.`;
    } else {
      return `### 🔍 Batch #${batchData.id} Analytical Insight
Excellent operational compliance! Batch #${batchData.id} for flavor **${batchData.flavor}** was completed in **${duration} minutes**, which meets the target optimal threshold of **${minTime} minutes**. 
Operator **${operatorName}** maintained excellent line speed during the ${batchData.shift} shift with zero recorded downtime.`;
    }
  }
}

// Vite integration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Manufacturing Line] Server running on http://localhost:${PORT}`);
  });
}

startServer();
